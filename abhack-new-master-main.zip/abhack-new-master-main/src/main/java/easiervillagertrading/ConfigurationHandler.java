
package easiervillagertrading;

import net.minecraftforge.common.config.*;
import java.io.*;
import net.minecraftforge.fml.client.event.*;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraftforge.fml.common.*;

public class ConfigurationHandler
{
    private static ConfigurationHandler instance;
    private Configuration config;
    private String configFileName;
    private boolean showLeft;
    private int leftPixelOffset;
    private boolean autoFocusSearch;
    
    public static ConfigurationHandler getInstance() {
        if (ConfigurationHandler.instance == null) {
            ConfigurationHandler.instance = new ConfigurationHandler();
        }
        return ConfigurationHandler.instance;
    }
    
    public static Configuration getConfig() {
        return getInstance().config;
    }
    
    public static String getConfigFileName() {
        return getInstance().configFileName;
    }
    
    public static boolean showLeft() {
        return getInstance().showLeft;
    }
    
    public static int leftPixelOffset() {
        return getInstance().leftPixelOffset;
    }
    
    public static boolean autoFocusSearch() {
        return getInstance().autoFocusSearch;
    }
    
    public void load(final File configFile) {
        if (this.config == null) {
            this.config = new Configuration(configFile);
            this.configFileName = configFile.getPath();
            this.loadConfig();
        }
    }
    
    @SubscribeEvent
    public void onConfigChanged(final ConfigChangedEvent.OnConfigChangedEvent event) {
        if (event.getModID().equalsIgnoreCase("easiervillagertrading")) {
            this.loadConfig();
        }
    }
    
    private void loadConfig() {
        this.showLeft = this.config.getBoolean("Trades list left", "client", Loader.isModLoaded("jei"), "Show trades list to the left, for Just Enough Items compatibility");
        this.leftPixelOffset = this.config.getInt("Trades left pixel offset", "client", 0, 0, Integer.MAX_VALUE, "How many pixels left of the GUI the trades list will be shown. Use 0 for auto detect. Only used if Trades list left is true.");
        if (this.config.hasChanged()) {
            this.config.save();
        }
    }
}
