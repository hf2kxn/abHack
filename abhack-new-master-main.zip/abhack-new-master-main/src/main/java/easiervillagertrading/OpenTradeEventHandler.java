

package easiervillagertrading;

import net.minecraft.client.*;
import net.minecraftforge.client.event.*;
import net.minecraft.world.*;
import net.minecraft.client.gui.*;
import net.minecraftforge.fml.common.eventhandler.*;

public class OpenTradeEventHandler
{
    private static OpenTradeEventHandler instance;
    private Minecraft mc;
    
    public static OpenTradeEventHandler getInstance() {
        if (OpenTradeEventHandler.instance == null) {
            OpenTradeEventHandler.instance = new OpenTradeEventHandler();
            OpenTradeEventHandler.instance.mc = Minecraft.getMinecraft();
        }
        return OpenTradeEventHandler.instance;
    }
    
    @SubscribeEvent
    public void guiOpenEvent(final GuiOpenEvent event) {
        if (event.getGui() instanceof GuiMerchant) {
            event.setGui((GuiScreen)new BetterGuiMerchant(this.mc.player.inventory, (GuiMerchant)event.getGui(), (World)this.mc.world));
        }
    }
}
