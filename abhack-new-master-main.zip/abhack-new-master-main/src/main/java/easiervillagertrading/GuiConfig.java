

package easiervillagertrading;

import net.minecraft.client.gui.*;
import net.minecraftforge.common.config.*;

public class GuiConfig extends net.minecraftforge.fml.client.config.GuiConfig
{
    public GuiConfig(final GuiScreen parent) {
        super(parent, new ConfigElement(ConfigurationHandler.getConfig().getCategory("client")).getChildElements(), "easiervillagertrading", false, false, "Easier Villager Trading configuration");
    }
}
