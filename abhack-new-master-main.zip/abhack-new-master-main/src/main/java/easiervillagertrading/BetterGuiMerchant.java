
package easiervillagertrading;

import net.minecraft.util.*;
import net.minecraft.world.*;
import net.minecraft.entity.player.*;
import net.minecraft.enchantment.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.resources.*;
import net.minecraft.village.*;
import net.minecraft.item.*;
import net.minecraft.nbt.*;
import net.minecraft.client.gui.*;
import java.io.*;
import org.lwjgl.input.*;
import net.minecraft.inventory.*;

public class BetterGuiMerchant extends GuiMerchant
{
    private static final ResourceLocation icons;
    private final int lineHeight = 18;
    private final int titleDistance = 20;
    private final int firstBuyItemXpos = 0;
    private final int secondBuyItemXpos = 18;
    private final int okNokXpos = 40;
    private final int sellItemXpos = 60;
    private final int textXpos = 85;
    private int xBase;
    private int scrollCount;
    private int frames;
    
    BetterGuiMerchant(final InventoryPlayer inv, final GuiMerchant template, final World world) {
        super(inv, template.getMerchant(), world);
        this.xBase = 0;
        this.scrollCount = 0;
        if (ConfigurationHandler.showLeft()) {
            this.xBase = -ConfigurationHandler.leftPixelOffset();
            if (this.xBase == 0) {
                this.xBase = -this.getXSize();
            }
        }
        else {
            this.xBase = this.getXSize() + 5;
        }
    }
    
    protected void drawGuiContainerBackgroundLayer(final float partialTicks, final int mouseX, final int mouseY) {
        super.drawGuiContainerBackgroundLayer(partialTicks, mouseX, mouseY);
    }
    
    public void drawScreen(final int mouseX, final int mouseY, final float partialTicks) {
        super.drawScreen(mouseX, mouseY, partialTicks);
    }
    
    protected void drawGuiContainerForegroundLayer(final int mouseX, final int mouseY) {
        if (++this.frames % 300 == 0) {}
        super.drawGuiContainerForegroundLayer(mouseX, mouseY);
        final MerchantRecipeList trades = this.getMerchant().getRecipes((EntityPlayer)this.mc.player);
        if (trades == null) {
            return;
        }
        final int topAdjust = this.getTopAdjust(trades.size());
        final String s = trades.size() + " trades";
        this.fontRenderer.drawString(s, this.xBase + 40, -topAdjust, 16711935);
        if (this.frames % 300 == 0) {}
        RenderHelper.enableGUIStandardItemLighting();
        for (int i = 0; i < trades.size() - this.scrollCount; ++i) {
            final MerchantRecipe trade = (MerchantRecipe)trades.get(i + this.scrollCount);
            final ItemStack i2 = trade.getItemToBuy();
            final ItemStack i3 = trade.hasSecondItemToBuy() ? trade.getSecondItemToBuy() : null;
            final ItemStack o1 = trade.getItemToSell();
            if (this.frames % 300 == 0) {}
            this.drawItem(i2, this.xBase + 0, i * 18 - topAdjust + 20);
            this.drawItem(i3, this.xBase + 18, i * 18 - topAdjust + 20);
            this.drawItem(o1, this.xBase + 60, i * 18 - topAdjust + 20);
            NBTTagList enchantments;
            if (o1.getItem() instanceof ItemEnchantedBook) {
                final ItemEnchantedBook itemEnchantedBook = (ItemEnchantedBook)o1.getItem();
                enchantments = ItemEnchantedBook.getEnchantments(o1);
            }
            else {
                enchantments = o1.getEnchantmentTagList();
            }
            if (enchantments != null) {
                final StringBuilder enchants = new StringBuilder();
                for (int t = 0; t < enchantments.tagCount(); ++t) {
                    final int j = enchantments.getCompoundTagAt(t).getShort("id");
                    final int k = enchantments.getCompoundTagAt(t).getShort("lvl");
                    final Enchantment enchant = Enchantment.getEnchantmentByID(j);
                    if (enchant != null) {
                        if (t > 0) {
                            enchants.append(", ");
                        }
                        enchants.append(enchant.getTranslatedName(k));
                    }
                }
                String shownEnchants = enchants.toString();
                if (this.xBase < 0) {
                    shownEnchants = this.fontRenderer.trimStringToWidth(shownEnchants, -this.xBase - 85 - 5);
                }
                if (this.frames % 300 == 0) {}
                this.fontRenderer.drawString(shownEnchants, this.xBase + 85, i * 18 - topAdjust + 24, 16776960);
            }
        }
        RenderHelper.disableStandardItemLighting();
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.enableBlend();
        this.mc.getTextureManager().bindTexture(BetterGuiMerchant.icons);
        final int arrowX = this.xBase + 40;
        final int[] tradeState = new int[trades.size()];
        for (int l = 0; l < trades.size() - this.scrollCount; ++l) {
            final int y = l * 18 - topAdjust + 20;
            final MerchantRecipe trade2 = (MerchantRecipe)trades.get(l + this.scrollCount);
            if (!trade2.isRecipeDisabled() && this.inputSlotsAreEmpty() && this.hasEnoughItemsInInventory(trade2) && this.canReceiveOutput(trade2.getItemToSell())) {
                this.drawTexturedModalRect(arrowX, y, 108, 36, 18, 18);
                tradeState[l] = 0;
            }
            else if (!trade2.isRecipeDisabled()) {
                this.drawTexturedModalRect(arrowX, y, 90, 54, 18, 18);
                tradeState[l] = 1;
            }
            else {
                this.drawTexturedModalRect(arrowX, y, 216, 54, 18, 18);
                tradeState[l] = 2;
            }
        }
        if (this.scrollCount > 0) {
            this.drawTexturedModalRect(this.xBase + 0, -topAdjust - 3, 162, 36, 18, 18);
        }
        if ((trades.size() - 1 - this.scrollCount) * 18 + 40 >= this.height) {
            if (this.frames % 300 == 0) {}
            this.drawTexturedModalRect(this.xBase + 18, -topAdjust - 3, 18, 36, 18, 18);
        }
        for (int l = 0; l < trades.size(); ++l) {
            final int y = l * 18 - topAdjust + 20;
            final MerchantRecipe trade2 = (MerchantRecipe)trades.get(l);
            final ItemStack i4 = trade2.getItemToBuy();
            final ItemStack i5 = trade2.hasSecondItemToBuy() ? trade2.getSecondItemToBuy() : null;
            final ItemStack o2 = trade2.getItemToSell();
            this.drawTooltip(i4, this.xBase + 0, y, mouseX, mouseY);
            this.drawTooltip(i5, this.xBase + 18, y, mouseX, mouseY);
            this.drawTooltip(o2, this.xBase + 60, y, mouseX, mouseY);
            switch (tradeState[l]) {
                case 0: {
                    this.drawTooltip(I18n.format("msg.cantrade", (Object[])null), arrowX, y, mouseX, mouseY);
                    break;
                }
                case 1: {
                    this.drawTooltip(I18n.format("msg.notradeinv", (Object[])null), arrowX, y, mouseX, mouseY);
                    break;
                }
                case 2: {
                    this.drawTooltip(I18n.format("msg.tradelocked", (Object[])null), arrowX, y, mouseX, mouseY);
                    break;
                }
            }
        }
    }
    
    private int getTopAdjust(final int numTrades) {
        int topAdjust = (numTrades * 18 + 20 - this.ySize) / 2;
        if (topAdjust < 0) {
            topAdjust = 0;
        }
        final int n = topAdjust;
        final int guiTop = this.guiTop;
        this.getClass();
        if (n > guiTop - 20 / 2) {
            final int guiTop2 = this.guiTop;
            this.getClass();
            topAdjust = guiTop2 - 20 / 2;
        }
        return topAdjust;
    }
    
    private void drawItem(final ItemStack stack, final int x, final int y) {
        if (stack == null) {
            return;
        }
        this.itemRender.renderItemAndEffectIntoGUI(stack, x, y);
        this.itemRender.renderItemOverlays(this.fontRenderer, stack, x, y);
    }
    
    private void drawTooltip(final ItemStack stack, final int x, final int y, int mousex, int mousey) {
        if (stack == null) {
            return;
        }
        mousex -= this.guiLeft;
        mousey -= this.guiTop;
        if (mousex >= x && mousex <= x + 16 && mousey >= y && mousey <= y + 16) {
            this.renderToolTip(stack, mousex, mousey);
        }
    }
    
    private void drawTooltip(final String s, final int x, final int y, int mousex, int mousey) {
        mousex -= this.guiLeft;
        mousey -= this.guiTop;
        if (mousex >= x && mousex <= x + 16 && mousey >= y && mousey <= y + 16) {
            this.drawHoveringText(s, mousex, mousey);
        }
    }
    
    protected void mouseClicked(final int mouseX, final int mouseY, final int mouseButton) throws IOException {
        if (mouseButton == 0 && mouseX - this.guiLeft >= this.xBase && mouseX - this.guiLeft <= this.xBase + 85) {
            final MerchantRecipeList trades = this.getMerchant().getRecipes((EntityPlayer)this.mc.player);
            if (trades == null) {
                return;
            }
            final int numTrades = trades.size();
            final int topAdjust = this.getTopAdjust(numTrades);
            final int yPixel = mouseY + topAdjust - this.guiTop - 20;
            if (yPixel >= 0) {
                final int tradeIndex = yPixel / 18 + this.scrollCount;
                if (tradeIndex >= 0 && tradeIndex < numTrades) {
                    final GuiButton myNextButton = this.buttonList.get(0);
                    final GuiButton myPrevButton = this.buttonList.get(1);
                    for (int i = 0; i < numTrades; ++i) {
                        this.actionPerformed(myPrevButton);
                    }
                    for (int i = 0; i < tradeIndex; ++i) {
                        this.actionPerformed(myNextButton);
                    }
                    final MerchantRecipe recipe = (MerchantRecipe)trades.get(tradeIndex);
                    while (!recipe.isRecipeDisabled() && this.inputSlotsAreEmpty() && this.hasEnoughItemsInInventory(recipe) && this.canReceiveOutput(recipe.getItemToSell())) {
                        this.transact(recipe);
                        if (!isShiftKeyDown()) {
                            break;
                        }
                    }
                }
            }
            else if (mouseX - this.guiLeft < this.xBase + 18) {
                this.mouseScrolled(1);
            }
            else if (mouseX - this.guiLeft < this.xBase + 40) {
                this.mouseScrolled(-1);
            }
        }
        else {
            super.mouseClicked(mouseX, mouseY, mouseButton);
        }
    }
    
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        final int i = Mouse.getEventDWheel();
        if (i != 0) {
            this.mouseScrolled((i < 0) ? -1 : 1);
        }
    }
    
    public void mouseScrolled(final int delta) {
        final MerchantRecipeList trades;
        if ((trades = this.getMerchant().getRecipes((EntityPlayer)this.mc.player)) != null) {
            this.scrollCount -= delta;
            while ((trades.size() - this.scrollCount) * 18 + 40 < this.height) {
                --this.scrollCount;
            }
            if (this.scrollCount < 0) {
                this.scrollCount = 0;
            }
        }
    }
    
    private boolean inputSlotsAreEmpty() {
        return !this.inventorySlots.getSlot(0).getHasStack() && !this.inventorySlots.getSlot(1).getHasStack() && !this.inventorySlots.getSlot(2).getHasStack();
    }
    
    private boolean hasEnoughItemsInInventory(final MerchantRecipe recipe) {
        return this.hasEnoughItemsInInventory(recipe.getItemToBuy()) && (!recipe.hasSecondItemToBuy() || this.hasEnoughItemsInInventory(recipe.getSecondItemToBuy()));
    }
    
    private boolean hasEnoughItemsInInventory(final ItemStack stack) {
        int remaining = stack.getCount();
        for (int i = this.inventorySlots.inventorySlots.size() - 36; i < this.inventorySlots.inventorySlots.size(); ++i) {
            final ItemStack invstack = this.inventorySlots.getSlot(i).getStack();
            if (invstack != null) {
                if (this.areItemStacksMergable(stack, invstack)) {
                    remaining -= invstack.getCount();
                }
                if (remaining <= 0) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private boolean canReceiveOutput(final ItemStack stack) {
        int remaining = stack.getCount();
        for (int i = this.inventorySlots.inventorySlots.size() - 36; i < this.inventorySlots.inventorySlots.size(); ++i) {
            final ItemStack invstack = this.inventorySlots.getSlot(i).getStack();
            if (invstack == null || invstack.isEmpty()) {
                return true;
            }
            if (this.areItemStacksMergable(stack, invstack) && stack.getMaxStackSize() >= stack.getCount() + invstack.getCount()) {
                remaining -= invstack.getMaxStackSize() - invstack.getCount();
            }
            if (remaining <= 0) {
                return true;
            }
        }
        return false;
    }
    
    private void transact(final MerchantRecipe recipe) {
        int putback1 = -1;
        final int putback2 = this.fillSlot(0, recipe.getItemToBuy());
        if (recipe.hasSecondItemToBuy()) {
            putback1 = this.fillSlot(1, recipe.getSecondItemToBuy());
        }
        this.getslot(2, recipe.getItemToSell(), putback2, putback1);
        if (putback2 != -1) {
            this.slotClick(0);
            this.slotClick(putback2);
        }
        if (putback1 != -1) {
            this.slotClick(1);
            this.slotClick(putback1);
        }
    }
    
    private int fillSlot(final int slot, final ItemStack stack) {
        int remaining = stack.getCount();
        for (int i = this.inventorySlots.inventorySlots.size() - 36; i < this.inventorySlots.inventorySlots.size(); ++i) {
            final ItemStack invstack = this.inventorySlots.getSlot(i).getStack();
            if (invstack != null) {
                boolean needPutBack = false;
                if (this.areItemStacksMergable(stack, invstack)) {
                    if (stack.getCount() + invstack.getCount() > stack.getMaxStackSize()) {
                        needPutBack = true;
                    }
                    remaining -= invstack.getCount();
                    this.slotClick(i);
                    this.slotClick(slot);
                }
                if (needPutBack) {
                    this.slotClick(i);
                }
                if (remaining <= 0) {
                    return (remaining < 0) ? i : -1;
                }
            }
        }
        return -1;
    }
    
    private boolean areItemStacksMergable(final ItemStack a, final ItemStack b) {
        return a != null && b != null && a.getItem() == b.getItem() && (!a.getHasSubtypes() || a.getItemDamage() == b.getItemDamage()) && ItemStack.areItemStackTagsEqual(a, b);
    }
    
    private void getslot(final int slot, final ItemStack stack, final int... forbidden) {
        int remaining = stack.getCount();
        this.slotClick(slot);
        for (int i = this.inventorySlots.inventorySlots.size() - 36; i < this.inventorySlots.inventorySlots.size(); ++i) {
            final ItemStack invstack = this.inventorySlots.getSlot(i).getStack();
            if (invstack != null) {
                if (!invstack.isEmpty()) {
                    if (this.areItemStacksMergable(stack, invstack) && invstack.getCount() < invstack.getMaxStackSize()) {
                        remaining -= invstack.getMaxStackSize() - invstack.getCount();
                        this.slotClick(i);
                    }
                    if (remaining <= 0) {
                        return;
                    }
                }
            }
        }
        for (int i = this.inventorySlots.inventorySlots.size() - 36; i < this.inventorySlots.inventorySlots.size(); ++i) {
            boolean isForbidden = false;
            for (final int f : forbidden) {
                if (i == f) {
                    isForbidden = true;
                }
            }
            if (!isForbidden) {
                final ItemStack invstack2 = this.inventorySlots.getSlot(i).getStack();
                if (invstack2 == null || invstack2.isEmpty()) {
                    this.slotClick(i);
                    return;
                }
            }
        }
    }
    
    private void slotClick(final int slot) {
        this.mc.playerController.windowClick(this.mc.player.openContainer.windowId, slot, 0, ClickType.PICKUP, (EntityPlayer)this.mc.player);
    }
    
    static {
        icons = new ResourceLocation("easiervillagertrading", "textures/icons.png");
    }
}
