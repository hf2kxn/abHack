

package easiervillagertrading;

import net.minecraftforge.fml.client.*;
import net.minecraft.client.*;
import net.minecraft.client.gui.*;
import java.util.*;

public class GuiFactory implements IModGuiFactory
{
    public boolean hasConfigGui() {
        return true;
    }
    
    public void initialize(final Minecraft minecraftInstance) {
    }
    
    public GuiScreen createConfigGui(final GuiScreen parentScreen) {
        return (GuiScreen)new GuiConfig(parentScreen);
    }
    
    public Set<IModGuiFactory.RuntimeOptionCategoryElement> runtimeGuiCategories() {
        return null;
    }
}
