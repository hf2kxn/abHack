//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "E:\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package me.abHack.manager;

import me.abHack.features.*;
import me.abHack.features.modules.*;
import me.abHack.features.modules.client.*;
import me.abHack.features.modules.combat.*;
import me.abHack.features.modules.misc.*;
import me.abHack.features.modules.render.*;
import me.abHack.features.modules.player.*;
import me.abHack.features.modules.movement.*;
import net.minecraftforge.common.*;
import java.util.function.*;
import me.abHack.event.events.*;
import java.util.stream.*;
import java.util.*;
import org.lwjgl.input.*;
import me.abHack.features.gui.*;
import com.mojang.realmsclient.gui.*;
import me.abHack.*;
import java.util.concurrent.*;

public class ModuleManager extends Feature
{
    public ArrayList<Module> modules;
    public List<Module> sortedModules;
    public List<String> sortedModulesABC;
    public Animation animationThread;
    
    public ModuleManager() {
        this.modules = new ArrayList<Module>();
        this.sortedModules = new ArrayList<Module>();
        this.sortedModulesABC = new ArrayList<String>();
    }
    
    public void init() {
        this.modules.add((Module)new ClickGui());
        this.modules.add((Module)new FontMod());
        this.modules.add((Module)new HUD());
        this.modules.add((Module)new Capes());
        this.modules.add((Module)new WaterMark());
        this.modules.add((Module)new Offhand());
        this.modules.add((Module)new Surround());
        this.modules.add((Module)new AutoTrap());
        this.modules.add((Module)new AutoCity());
        this.modules.add((Module)new AutoCev());
        this.modules.add((Module)new AutoTotem());
        this.modules.add((Module)new AutoWeb());
        this.modules.add((Module)new AntiBurrow());
        this.modules.add((Module)new AntiCity());
        this.modules.add((Module)new AutoCrystal());
        this.modules.add((Module)new HFAura());
        this.modules.add((Module)new BedAura());
        this.modules.add((Module)new Killaura());
        this.modules.add((Module)new Criticals());
        this.modules.add((Module)new HoleFiller());
        this.modules.add((Module)new AutoArmor());
        this.modules.add((Module)new Selftrap());
        this.modules.add((Module)new FastBow());
        this.modules.add((Module)new Flatten());
        this.modules.add((Module)new BowAim());
        this.modules.add((Module)new Quiver());
        this.modules.add((Module)new AntiCev());
        this.modules.add((Module)new TrapHead());
        this.modules.add((Module)new TrapSelf());
        this.modules.add((Module)new PistonCrystal());
        this.modules.add((Module)new AutoPush());
        this.modules.add((Module)new BedCity());
        this.modules.add((Module)new KeyCity());
        this.modules.add((Module)new Timer());
        this.modules.add((Module)new ShulkerViewer());
        this.modules.add((Module)new Interact());
        this.modules.add((Module)new MiddleFriend());
        this.modules.add((Module)new PopCounter());
        this.modules.add((Module)new OffhandCrash());
        this.modules.add((Module)new Message());
        this.modules.add((Module)new AntiPackets());
        this.modules.add((Module)new NoEntityTrace());
        this.modules.add((Module)new ChatSuffix());
        this.modules.add((Module)new AutoRespawn());
        this.modules.add((Module)new BowGod());
        this.modules.add((Module)new AntiWeb());
        this.modules.add((Module)new ChestStealer());
        this.modules.add((Module)new CrashSeries());
        this.modules.add((Module)new NoRotate());
        this.modules.add((Module)new Gamemode());
        this.modules.add((Module)new AntiCrash());
        this.modules.add((Module)new Spammer());
        this.modules.add((Module)new NoteBot());
        this.modules.add((Module)new SkinFlicker());
        this.modules.add((Module)new AutoReconnect());
        this.modules.add((Module)new VillagerNotifier());
        this.modules.add((Module)new AutoGG());
        this.modules.add((Module)new AntiAim());
        this.modules.add((Module)new AutoBanxxs());
        this.modules.add((Module)new ColorSigns());
        this.modules.add((Module)new Ghost());
        this.modules.add((Module)new BlockHighlight());
        this.modules.add((Module)new BreakingESP());
        this.modules.add((Module)new HoleESP());
        this.modules.add((Module)new Skeleton());
        this.modules.add((Module)new Trajectories());
        this.modules.add((Module)new NoRender());
        this.modules.add((Module)new NameTags());
        this.modules.add((Module)new Particles());
        this.modules.add((Module)new ESP());
        this.modules.add((Module)new ItemPhysics());
        this.modules.add((Module)new Fullbright());
        this.modules.add((Module)new CameraClip());
        this.modules.add((Module)new LogoutSpots());
        this.modules.add((Module)new PopChams());
        this.modules.add((Module)new BreadCrumbs());
        this.modules.add((Module)new SkyColor());
        this.modules.add((Module)new ViewModel());
        this.modules.add((Module)new ChestESP());
        this.modules.add((Module)new Chams());
        this.modules.add((Module)new PortalESP());
        this.modules.add((Module)new BurrowESP());
        this.modules.add((Module)new CityRender());
        this.modules.add((Module)new Target());
        this.modules.add((Module)new Ranges());
        this.modules.add((Module)new VoidESP());
        this.modules.add((Module)new ExplosionChams());
        this.modules.add((Module)new CrystalScale());
        this.modules.add((Module)new BedCityRender());
        this.modules.add((Module)new BreadCrums());
        this.modules.add((Module)new BreakRender());
        this.modules.add((Module)new EntityInfo());
        this.modules.add((Module)new Replenish());
        this.modules.add((Module)new FakePlayer());
        this.modules.add((Module)new TpsSync());
        this.modules.add((Module)new MultiTask());
        this.modules.add((Module)new Speedmine());
        this.modules.add((Module)new FastPlace());
        this.modules.add((Module)new InstantMine());
        this.modules.add((Module)new Phase());
        this.modules.add((Module)new Reach());
        this.modules.add((Module)new PortalGodMode());
        this.modules.add((Module)new AntiHunger());
        this.modules.add((Module)new XCarry());
        this.modules.add((Module)new Anti32k());
        this.modules.add((Module)new AutoXP());
        this.modules.add((Module)new AutoEat());
        this.modules.add((Module)new Blink());
        this.modules.add((Module)new Burrow());
        this.modules.add((Module)new BurrowX());
        this.modules.add((Module)new PacketEat());
        this.modules.add((Module)new TickShift());
        this.modules.add((Module)new Swing());
        this.modules.add((Module)new tp());
        this.modules.add((Module)new ChestSwap());
        this.modules.add((Module)new BlockTweaks());
        this.modules.add((Module)new AntiContainer());
        this.modules.add((Module)new AntiShulkerBox());
        this.modules.add((Module)new AutoDupe());
        this.modules.add((Module)new AutoBuilder());
        this.modules.add((Module)new AutoTool());
        this.modules.add((Module)new FastBreak());
        this.modules.add((Module)new Nuker());
        this.modules.add((Module)new Strafe());
        this.modules.add((Module)new Step());
        this.modules.add((Module)new Flight());
        this.modules.add((Module)new Scaffold());
        this.modules.add((Module)new ReverseStep());
        this.modules.add((Module)new AntiLevitate());
        this.modules.add((Module)new AutoWalk());
        this.modules.add((Module)new BoatFly());
        this.modules.add((Module)new ElytraFlight());
        this.modules.add((Module)new EntityControl());
        this.modules.add((Module)new NoFall());
        this.modules.add((Module)new PlayerTweaks());
        this.modules.add((Module)new Sprint());
        this.modules.add((Module)new HoleTP());
        this.modules.add((Module)new AirJump());
        this.modules.add((Module)new AntiVoid());
        this.modules.add((Module)new FastSwim());
        this.modules.add((Module)new KeyPearl());
        this.modules.add((Module)new NoWeb());
        this.modules.add((Module)new Spider());
    }
    
    public Module getModuleByName(final String name) {
        for (final Module module : this.modules) {
            if (!module.getName().equalsIgnoreCase(name)) {
                continue;
            }
            return module;
        }
        return null;
    }
    
    public <T extends Module> T getModuleByClass(final Class<T> clazz) {
        for (final Module module : this.modules) {
            if (!clazz.isInstance(module)) {
                continue;
            }
            return (T)module;
        }
        return null;
    }
    
    public void enableModule(final Class<Module> clazz) {
        final Module module = this.getModuleByClass(clazz);
        if (module != null) {
            module.enable();
        }
    }
    
    public void disableModule(final Class<Module> clazz) {
        final Module module = this.getModuleByClass(clazz);
        if (module != null) {
            module.disable();
        }
    }
    
    public void enableModule(final String name) {
        final Module module = this.getModuleByName(name);
        if (module != null) {
            module.enable();
        }
    }
    
    public void disableModule(final String name) {
        final Module module = this.getModuleByName(name);
        if (module != null) {
            module.disable();
        }
    }
    
    public boolean isModuleEnabled(final String name) {
        final Module module = this.getModuleByName(name);
        return module != null && module.isOn();
    }
    
    public boolean isModuleEnabled(final Class<Module> clazz) {
        final Module module = this.getModuleByClass(clazz);
        return module != null && module.isOn();
    }
    
    public Module getModuleByDisplayName(final String displayName) {
        for (final Module module : this.modules) {
            if (!module.getDisplayName().equalsIgnoreCase(displayName)) {
                continue;
            }
            return module;
        }
        return null;
    }
    
    public ArrayList<Module> getEnabledModules() {
        final ArrayList<Module> enabledModules = new ArrayList<Module>();
        for (final Module module : this.modules) {
            if (!module.isEnabled()) {
                continue;
            }
            enabledModules.add(module);
        }
        return enabledModules;
    }
    
    public ArrayList<String> getEnabledModulesName() {
        final ArrayList<String> enabledModules = new ArrayList<String>();
        for (final Module module : this.modules) {
            if (module.isEnabled()) {
                if (!module.isDrawn()) {
                    continue;
                }
                enabledModules.add(module.getFullArrayString());
            }
        }
        return enabledModules;
    }
    
    public ArrayList<Module> getModulesByCategory(final Module.Category category) {
        final ArrayList<Module> modulesCategory = new ArrayList<Module>();
        final ArrayList<Module> list;
        this.modules.forEach(module -> {
            if (module.getCategory() == category) {
                list.add(module);
            }
            return;
        });
        return modulesCategory;
    }
    
    public List<Module.Category> getCategories() {
        return Arrays.asList(Module.Category.values());
    }
    
    public void onLoad() {
        this.modules.stream().filter(Module::listening).forEach(MinecraftForge.EVENT_BUS::register);
        this.modules.forEach(Module::onLoad);
    }
    
    public void onUpdate() {
        this.modules.stream().filter(Feature::isEnabled).forEach(Module::onUpdate);
    }
    
    public void onTick() {
        this.modules.stream().filter(Feature::isEnabled).forEach(Module::onTick);
    }
    
    public void onRender2D(final Render2DEvent event) {
        this.modules.stream().filter(Feature::isEnabled).forEach(module -> module.onRender2D(event));
    }
    
    public void onRender3D(final Render3DEvent event) {
        this.modules.stream().filter(Feature::isEnabled).forEach(module -> module.onRender3D(event));
    }
    
    public void sortModules(final boolean reverse) {
        this.sortedModules = this.getEnabledModules().stream().filter(Module::isDrawn).sorted(Comparator.comparing(module -> this.renderer.getStringWidth(module.getFullArrayString()) * (reverse ? -1 : 1))).collect((Collector<? super Object, ?, List<Module>>)Collectors.toList());
    }
    
    public void sortModulesABC() {
        (this.sortedModulesABC = new ArrayList<String>(this.getEnabledModulesName())).sort(String.CASE_INSENSITIVE_ORDER);
    }
    
    public void onLogout() {
        this.modules.forEach(Module::onLogout);
    }
    
    public void onLogin() {
        this.modules.forEach(Module::onLogin);
    }
    
    public void onUnload() {
        this.modules.forEach(MinecraftForge.EVENT_BUS::unregister);
        this.modules.forEach(Module::onUnload);
    }
    
    public void onUnloadPost() {
        for (final Module module : this.modules) {
            module.enabled.setValue((Object)false);
        }
    }
    
    public void onKeyPressed(final int eventKey) {
        if (eventKey == 0 || !Keyboard.getEventKeyState() || ModuleManager.mc.currentScreen instanceof OyVeyGui) {
            return;
        }
        this.modules.forEach(module -> {
            if (module.getBind().getKey() == eventKey) {
                module.toggle();
            }
        });
    }
    
    private class Animation extends Thread
    {
        public Module module;
        public float offset;
        public float vOffset;
        ScheduledExecutorService service;
        
        public Animation() {
            super("Animation");
            this.service = Executors.newSingleThreadScheduledExecutor();
        }
        
        @Override
        public void run() {
            if (HUD.getInstance().renderingMode.getValue() == HUD.RenderingMode.Length) {
                for (final Module module : ModuleManager.this.sortedModules) {
                    final String text = module.getDisplayName() + ChatFormatting.GRAY + ((module.getDisplayInfo() != null) ? (" [" + ChatFormatting.WHITE + module.getDisplayInfo() + ChatFormatting.GRAY + "]") : "");
                    module.offset = ModuleManager.this.renderer.getStringWidth(text) / 1.0f;
                    module.vOffset = ModuleManager.this.renderer.getFontHeight() / 1.0f;
                    if (module.isEnabled()) {}
                    if (module.isDisabled()) {
                        continue;
                    }
                }
            }
            else {
                for (final String e : ModuleManager.this.sortedModulesABC) {
                    final Module module2 = OyVey.moduleManager.getModuleByName(e);
                    final String text2 = module2.getDisplayName() + ChatFormatting.GRAY + ((module2.getDisplayInfo() != null) ? (" [" + ChatFormatting.WHITE + module2.getDisplayInfo() + ChatFormatting.GRAY + "]") : "");
                    module2.offset = ModuleManager.this.renderer.getStringWidth(text2) / 1.0f;
                    module2.vOffset = ModuleManager.this.renderer.getFontHeight() / 1.0f;
                    if (module2.isEnabled()) {}
                    if (module2.isDisabled()) {
                        continue;
                    }
                }
            }
        }
        
        @Override
        public void start() {
            System.out.println("Starting animation thread.");
            this.service.scheduleAtFixedRate(this, 0L, 1L, TimeUnit.MILLISECONDS);
        }
    }
}
