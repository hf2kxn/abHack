//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "E:\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package me.abHack.manager;

import me.abHack.util.*;
import java.util.*;

public class VerificationManager
{
    public static final String checkURL = "https://pastebin.com/raw/2Mk5bQdd";
    public static List<String> hwids;
    
    public static void hwidCheck() {
        VerificationManager.hwids = VerificationUtil.readURL();
        final boolean isHwidPresent = VerificationManager.hwids.contains(SystemUtil.getSystemInfo());
        final boolean All = VerificationManager.hwids.contains(SystemUtil.getAll());
        if (!isHwidPresent && !All) {
            DisplayUtil.Display();
            throw new NoStackTraceThrowable("");
        }
    }
    
    static {
        VerificationManager.hwids = new ArrayList<String>();
    }
}
