//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "E:\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package me.abHack.util;

import me.abHack.*;
import net.minecraft.client.*;

public class HudUtil implements Util
{
    public static String getPingSatus() {
        final String line = "";
        final int ping = OyVey.serverManager.getPing();
        return line + " " + ping;
    }
    
    public static String getTpsStatus() {
        final String line = "";
        final double tps = Math.ceil(OyVey.serverManager.getTPS());
        return line + " " + tps;
    }
    
    public static String getFpsStatus() {
        final String line = "";
        final int fps = Minecraft.getDebugFPS();
        return line + " " + fps;
    }
}
