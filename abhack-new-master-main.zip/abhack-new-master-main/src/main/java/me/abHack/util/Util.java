//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "E:\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package me.abHack.util;

import net.minecraft.client.*;

public interface Util
{
    public static final Minecraft mc = Minecraft.getMinecraft();
}
