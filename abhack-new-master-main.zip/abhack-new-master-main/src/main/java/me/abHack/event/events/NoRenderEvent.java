

package me.abHack.event.events;

import me.abHack.event.*;
import net.minecraftforge.fml.common.eventhandler.*;

@Cancelable
public class NoRenderEvent extends EventStage
{
    public NoRenderEvent(final int a) {
        super(a);
    }
}
