
package me.abHack.event.events;

import me.abHack.event.*;
import net.minecraft.util.math.*;

public class BlockDestructionEvent extends EventStage
{
    BlockPos nigger;
    
    public BlockDestructionEvent(BlockPos nigger) {
        nigger = nigger;
    }
    
    public BlockPos getBlockPos() {
        return this.nigger;
    }
}
