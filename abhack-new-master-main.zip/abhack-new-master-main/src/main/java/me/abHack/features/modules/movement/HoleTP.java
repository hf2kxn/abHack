//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "E:\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package me.abHack.features.modules.movement;

import me.abHack.features.modules.*;
import me.abHack.features.setting.*;
import me.abHack.*;
import net.minecraft.util.math.*;
import me.abHack.util.*;
import java.util.*;
import net.minecraft.block.state.*;
import net.minecraft.block.*;
import net.minecraft.world.*;
import net.minecraft.init.*;

public class HoleTP extends Module
{
    private static HoleTP INSTANCE;
    private final Setting<Float> range;
    private final Setting<Boolean> setY;
    private final Setting<Float> xOffset;
    private final Setting<Float> yOffset;
    private final Setting<Float> zOffset;
    private final double[] oneblockPositions;
    private final boolean jumped = false;
    private int packets;
    
    public HoleTP() {
        super("HoleTP", "Teleports you in a hole.", Module.Category.MOVEMENT, true, false, false);
        this.range = (Setting<Float>)this.register(new Setting("Range", (T)5.0f, (T)0.0f, (T)5.0f));
        this.setY = (Setting<Boolean>)this.register(new Setting("SetY", (T)false));
        this.xOffset = (Setting<Float>)this.register(new Setting("XOffset", (T)0.5f, (T)0.0f, (T)1.0f));
        this.yOffset = (Setting<Float>)this.register(new Setting("YOffset", (T)0.0f, (T)0.0f, (T)1.0f));
        this.zOffset = (Setting<Float>)this.register(new Setting("ZOffset", (T)0.5f, (T)0.0f, (T)1.0f));
        this.oneblockPositions = new double[] { 0.42, 0.75 };
        this.setInstance();
    }
    
    public static HoleTP getInstance() {
        if (HoleTP.INSTANCE == null) {
            HoleTP.INSTANCE = new HoleTP();
        }
        return HoleTP.INSTANCE;
    }
    
    private void setInstance() {
        HoleTP.INSTANCE = this;
    }
    
    public void onEnable() {
        OyVey.holeManager.update();
        final List<BlockPos> holes = OyVey.holeManager.getSortedHoles();
        if (!holes.isEmpty()) {
            final BlockPos pos = holes.get(0);
            if (HoleTP.mc.player.getDistanceSq(pos) <= MathUtil.square(this.range.getValue())) {
                OyVey.positionManager.setPositionPacket(pos.getX() + this.xOffset.getValue(), (this.setY.getValue() ? pos.getY() : HoleTP.mc.player.posY) + this.yOffset.getValue(), pos.getZ() + this.zOffset.getValue(), this.setY.getValue() && this.yOffset.getValue() == 0.0f, true, true);
            }
        }
        this.disable();
    }
    
    private boolean isInHole() {
        final BlockPos blockPos = new BlockPos(HoleTP.mc.player.posX, HoleTP.mc.player.posY, HoleTP.mc.player.posZ);
        final IBlockState blockState = HoleTP.mc.world.getBlockState(blockPos);
        return this.isBlockValid(blockState, blockPos);
    }
    
    private double getNearestBlockBelow() {
        for (double y = HoleTP.mc.player.posY; y > 0.0; y -= 0.001) {
            if (!(HoleTP.mc.world.getBlockState(new BlockPos(HoleTP.mc.player.posX, y, HoleTP.mc.player.posZ)).getBlock() instanceof BlockSlab) && HoleTP.mc.world.getBlockState(new BlockPos(HoleTP.mc.player.posX, y, HoleTP.mc.player.posZ)).getBlock().getDefaultState().getCollisionBoundingBox((IBlockAccess)HoleTP.mc.world, new BlockPos(0, 0, 0)) != null) {
                return y;
            }
        }
        return -1.0;
    }
    
    private boolean isBlockValid(final IBlockState blockState, final BlockPos blockPos) {
        return blockState.getBlock() == Blocks.AIR && HoleTP.mc.player.getDistanceSq(blockPos) >= 1.0 && HoleTP.mc.world.getBlockState(blockPos.up()).getBlock() == Blocks.AIR && HoleTP.mc.world.getBlockState(blockPos.up(2)).getBlock() == Blocks.AIR && (this.isBedrockHole(blockPos) || this.isObbyHole(blockPos) || this.isBothHole(blockPos) || this.isElseHole(blockPos));
    }
    
    private boolean isObbyHole(final BlockPos blockPos) {
        final BlockPos[] array;
        final BlockPos[] touchingBlocks = array = new BlockPos[] { blockPos.north(), blockPos.south(), blockPos.east(), blockPos.west(), blockPos.down() };
        for (final BlockPos pos : array) {
            final IBlockState touchingState = HoleTP.mc.world.getBlockState(pos);
            if (touchingState.getBlock() == Blocks.AIR || touchingState.getBlock() != Blocks.OBSIDIAN) {
                return false;
            }
        }
        return true;
    }
    
    private boolean isBedrockHole(final BlockPos blockPos) {
        final BlockPos[] array;
        final BlockPos[] touchingBlocks = array = new BlockPos[] { blockPos.north(), blockPos.south(), blockPos.east(), blockPos.west(), blockPos.down() };
        for (final BlockPos pos : array) {
            final IBlockState touchingState = HoleTP.mc.world.getBlockState(pos);
            if (touchingState.getBlock() == Blocks.AIR || touchingState.getBlock() != Blocks.BEDROCK) {
                return false;
            }
        }
        return true;
    }
    
    private boolean isBothHole(final BlockPos blockPos) {
        final BlockPos[] array;
        final BlockPos[] touchingBlocks = array = new BlockPos[] { blockPos.north(), blockPos.south(), blockPos.east(), blockPos.west(), blockPos.down() };
        for (final BlockPos pos : array) {
            final IBlockState touchingState = HoleTP.mc.world.getBlockState(pos);
            if (touchingState.getBlock() == Blocks.AIR || (touchingState.getBlock() != Blocks.BEDROCK && touchingState.getBlock() != Blocks.OBSIDIAN)) {
                return false;
            }
        }
        return true;
    }
    
    private boolean isElseHole(final BlockPos blockPos) {
        final BlockPos[] array;
        final BlockPos[] touchingBlocks = array = new BlockPos[] { blockPos.north(), blockPos.south(), blockPos.east(), blockPos.west(), blockPos.down() };
        for (final BlockPos pos : array) {
            final IBlockState touchingState = HoleTP.mc.world.getBlockState(pos);
            if (touchingState.getBlock() == Blocks.AIR || !touchingState.isFullBlock()) {
                return false;
            }
        }
        return true;
    }
    
    static {
        HoleTP.INSTANCE = new HoleTP();
    }
}
