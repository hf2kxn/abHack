//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "E:\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package me.abHack.features.modules.player;

import me.abHack.features.modules.*;
import me.abHack.features.setting.*;
import net.minecraft.util.math.*;
import net.minecraft.init.*;
import net.minecraft.block.*;
import me.abHack.util.*;
import net.minecraft.util.*;
import java.util.*;

public class AntiShulkerBox extends Module
{
    private static AntiShulkerBox INSTANCE;
    private final Setting<Integer> range;
    private final Setting<Integer> saferange;
    
    public AntiShulkerBox() {
        super("AntiShulkerBox", "Automatically dig someone else's box", Module.Category.PLAYER, true, false, false);
        this.range = (Setting<Integer>)this.register(new Setting("Range", (T)5, (T)1, (T)6));
        this.saferange = (Setting<Integer>)this.register(new Setting("SafeRange", (T)3, (T)0, (T)6));
        this.setInstance();
    }
    
    public static AntiShulkerBox getInstance() {
        if (AntiShulkerBox.INSTANCE == null) {
            AntiShulkerBox.INSTANCE = new AntiShulkerBox();
        }
        return AntiShulkerBox.INSTANCE;
    }
    
    private void setInstance() {
        AntiShulkerBox.INSTANCE = this;
    }
    
    public void onTick() {
        if (fullNullCheck()) {
            return;
        }
        final int mainSlot = AntiShulkerBox.mc.player.inventory.currentItem;
        if (InstantMine.getInstance().isOff()) {
            InstantMine.getInstance().enable();
        }
        for (final BlockPos blockPos : this.breakPos(this.range.getValue())) {
            final int slotPick = InventoryUtil.getItemHotbar(Items.DIAMOND_PICKAXE);
            if (slotPick == -1) {
                return;
            }
            if (AntiShulkerBox.mc.player.getDistanceSq(blockPos) < MathUtil.square(this.saferange.getValue())) {
                continue;
            }
            if (blockPos == null) {
                continue;
            }
            if (AntiShulkerBox.mc.world.getBlockState(blockPos).getBlock() instanceof BlockShulkerBox) {
                AntiShulkerBox.mc.player.inventory.currentItem = slotPick;
                AntiShulkerBox.mc.player.swingArm(EnumHand.MAIN_HAND);
                AntiShulkerBox.mc.playerController.onPlayerDamageBlock(blockPos, BlockUtil.getRayTraceFacing(blockPos));
            }
            else {
                AntiShulkerBox.mc.player.inventory.currentItem = mainSlot;
            }
        }
    }
    
    private NonNullList<BlockPos> breakPos(final float placeRange) {
        final NonNullList<BlockPos> positions = (NonNullList<BlockPos>)NonNullList.create();
        positions.addAll((Collection)BlockUtil.getSphere(new BlockPos(Math.floor(AntiShulkerBox.mc.player.posX), Math.floor(AntiShulkerBox.mc.player.posY), Math.floor(AntiShulkerBox.mc.player.posZ)), placeRange, 0, false, true, 0));
        return positions;
    }
    
    static {
        AntiShulkerBox.INSTANCE = new AntiShulkerBox();
    }
}
