
package me.abHack.features.modules.combat;

import me.abHack.features.modules.*;
import me.abHack.features.setting.*;
import com.google.common.util.concurrent.*;
import java.util.concurrent.atomic.*;
import net.minecraft.entity.player.*;
import com.mojang.realmsclient.gui.*;
import me.abHack.features.command.*;
import net.minecraftforge.fml.common.eventhandler.*;
import me.abHack.event.events.*;
import net.minecraft.network.play.client.*;
import net.minecraft.entity.*;
import net.minecraft.network.*;
import net.minecraft.util.*;
import net.minecraft.item.*;
import net.minecraft.inventory.*;
import net.minecraft.tileentity.*;
import net.minecraft.util.math.*;
import me.abHack.util.*;
import net.minecraft.init.*;
import java.util.*;
import me.abHack.*;
import net.minecraft.block.state.*;

public class BedAura extends Module
{
    private final Setting<Boolean> place;
    private final Setting<Integer> placeDelay;
    private final Setting<Float> placeRange;
    private final Setting<Boolean> extraPacket;
    private final Setting<Boolean> packet;
    private final Setting<Boolean> explode;
    private final Setting<BreakLogic> breakMode;
    private final Setting<Integer> breakDelay;
    private final Setting<Float> breakRange;
    private final Setting<Float> minDamage;
    private final Setting<Float> range;
    private final Setting<Boolean> suicide;
    private final Setting<Boolean> removeTiles;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> oneDot15;
    private final Setting<Boolean> dimensionCheck;
    private final Setting<SwitchModes> switchMode;
    private final Setting<Logic> logic;
    private final Timer breakTimer;
    private final Timer placeTimer;
    private final AtomicDouble yaw;
    private final AtomicDouble pitch;
    private final AtomicBoolean shouldRotate;
    private EntityPlayer target;
    private boolean sendRotationPacket;
    private boolean one;
    private boolean two;
    private boolean three;
    private boolean four;
    private boolean five;
    private boolean six;
    private BlockPos maxPos;
    private int lastHotbarSlot;
    private int bedSlot;
    private BlockPos finalPos;
    private EnumFacing finalFacing;
    
    public BedAura() {
        super("BedAura", "AutoPlace and Break for beds", Category.COMBAT, true, false, false);
        this.place = (Setting<Boolean>)this.register(new Setting("Place", true));
        this.placeDelay = (Setting<Integer>)this.register(new Setting("Placedelay", 50, 0, 500, v -> this.place.getValue()));
        this.placeRange = (Setting<Float>)this.register(new Setting("PlaceRange", 6.0f, 1.0f, 10.0f, v -> this.place.getValue()));
        this.extraPacket = (Setting<Boolean>)this.register(new Setting("InsanePacket", false, v -> this.place.getValue()));
        this.packet = (Setting<Boolean>)this.register(new Setting("Packet", false, v -> this.place.getValue()));
        this.explode = (Setting<Boolean>)this.register(new Setting("Break", true));
        this.breakMode = (Setting<BreakLogic>)this.register(new Setting("BreakMode", BreakLogic.ALL, v -> this.explode.getValue()));
        this.breakDelay = (Setting<Integer>)this.register(new Setting("Breakdelay", 50, 0, 500, v -> this.explode.getValue()));
        this.breakRange = (Setting<Float>)this.register(new Setting("BreakRange", 6.0f, 1.0f, 10.0f, v -> this.explode.getValue()));
        this.minDamage = (Setting<Float>)this.register(new Setting("MinDamage", 5.0f, 1.0f, 36.0f, v -> this.explode.getValue()));
        this.range = (Setting<Float>)this.register(new Setting("Range", 10.0f, 1.0f, 12.0f, v -> this.explode.getValue()));
        this.suicide = (Setting<Boolean>)this.register(new Setting("Suicide", false, v -> this.explode.getValue()));
        this.removeTiles = (Setting<Boolean>)this.register(new Setting("RemoveTiles", false));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", false));
        this.oneDot15 = (Setting<Boolean>)this.register(new Setting("1.15", false));
        this.dimensionCheck = (Setting<Boolean>)this.register(new Setting("Dimension Check", true));
        this.switchMode = (Setting<SwitchModes>)this.register(new Setting("Switch Mode", SwitchModes.SILENT));
        this.logic = (Setting<Logic>)this.register(new Setting("Logic", Logic.BREAKPLACE, v -> this.place.getValue() && this.explode.getValue()));
        this.breakTimer = new Timer();
        this.placeTimer = new Timer();
        this.yaw = new AtomicDouble(-1.0);
        this.pitch = new AtomicDouble(-1.0);
        this.shouldRotate = new AtomicBoolean(false);
        this.target = null;
        this.sendRotationPacket = false;
        this.maxPos = null;
        this.lastHotbarSlot = -1;
        this.bedSlot = -1;
    }
    
    @Override
    public void onEnable() {
    }
    
    @Override
    public void onDisable() {
    }
    
    @Override
    public void onUpdate() {
        if (this.dimensionCheck.getValue() && BedAura.mc.player.dimension == 0) {
            Command.sendMessage(ChatFormatting.WHITE + "<WorldCheck> You are in the Overworld! Toggling Off!");
            this.disable();
        }
    }
    
    @SubscribeEvent
    public void onPacket(final PacketEvent.Send event) {
        if (this.shouldRotate.get() && event.getPacket() instanceof CPacketPlayer) {
            final CPacketPlayer packet = (CPacketPlayer)event.getPacket();
            packet.yaw = (float)this.yaw.get();
            packet.pitch = (float)this.pitch.get();
            this.shouldRotate.set(false);
        }
    }
    
    private void switchToSlot(final int slot) {
        BedAura.mc.player.inventory.currentItem = slot;
        BedAura.mc.playerController.updateController();
    }
    
    @SubscribeEvent
    public void onUpdateWalkingPlayer(final UpdateWalkingPlayerEvent event) {
        if (event.getStage() == 0) {
            this.doBedAura();
        }
        else if (event.getStage() == 1 && this.finalPos != null) {
            final Vec3d hitVec = new Vec3d((Vec3i)this.finalPos.down()).add(0.5, 0.5, 0.5).add(new Vec3d(this.finalFacing.getOpposite().getDirectionVec()).scale(0.5));
            BedAura.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)BedAura.mc.player, CPacketEntityAction.Action.START_SNEAKING));
            switch (this.switchMode.getValue()) {
                case NORMAL: {
                    InventoryUtil.switchToHotbarSlot(this.bedSlot, false);
                    break;
                }
            }
            if (InventoryUtil.getItemHotbar(Items.BED) != -1) {
                if (this.switchMode.getValue() == SwitchModes.SILENT) {
                    final int old = BedAura.mc.player.inventory.currentItem;
                    this.switchToSlot(this.bedSlot);
                    BlockUtil.rightClickBlock(this.finalPos.down(), hitVec, (this.bedSlot == -2) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, EnumFacing.UP, this.packet.getValue());
                    BedAura.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)BedAura.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
                    this.switchToSlot(old);
                }
                else {
                    BlockUtil.rightClickBlock(this.finalPos.down(), hitVec, (this.bedSlot == -2) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, EnumFacing.UP, this.packet.getValue());
                    BedAura.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)BedAura.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
                }
            }
            this.placeTimer.reset();
            this.finalPos = null;
        }
    }
    
    public void recheckBedSlots(final int woolSlot, final int woodSlot) {
        for (int i = 1; i <= 3; ++i) {
            if (BedAura.mc.player.openContainer.getInventory().get(i) == ItemStack.EMPTY) {
                BedAura.mc.playerController.windowClick(1, woolSlot, 0, ClickType.PICKUP, (EntityPlayer)BedAura.mc.player);
                BedAura.mc.playerController.windowClick(1, i, 1, ClickType.PICKUP, (EntityPlayer)BedAura.mc.player);
                BedAura.mc.playerController.windowClick(1, woolSlot, 0, ClickType.PICKUP, (EntityPlayer)BedAura.mc.player);
            }
        }
        for (int i = 4; i <= 6; ++i) {
            if (BedAura.mc.player.openContainer.getInventory().get(i) == ItemStack.EMPTY) {
                BedAura.mc.playerController.windowClick(1, woodSlot, 0, ClickType.PICKUP, (EntityPlayer)BedAura.mc.player);
                BedAura.mc.playerController.windowClick(1, i, 1, ClickType.PICKUP, (EntityPlayer)BedAura.mc.player);
                BedAura.mc.playerController.windowClick(1, woodSlot, 0, ClickType.PICKUP, (EntityPlayer)BedAura.mc.player);
            }
        }
    }
    
    private void doBedAura() {
        switch (this.logic.getValue()) {
            case BREAKPLACE: {
                this.mapBeds();
                this.breakBeds();
                this.placeBeds();
                break;
            }
            case PLACEBREAK: {
                this.mapBeds();
                this.placeBeds();
                this.breakBeds();
                break;
            }
        }
    }
    
    private void breakBeds() {
        if (this.explode.getValue() && this.breakTimer.passedMs(this.breakDelay.getValue())) {
            if (this.breakMode.getValue() == BreakLogic.CALC) {
                if (this.maxPos != null) {
                    final Vec3d hitVec = new Vec3d((Vec3i)this.maxPos).add(0.5, 0.5, 0.5);
                    final float[] rotations = RotationUtil.getLegitRotations(hitVec);
                    this.yaw.set((double)rotations[0]);
                    if (this.rotate.getValue()) {
                        this.shouldRotate.set(true);
                        this.pitch.set((double)rotations[1]);
                    }
                    final RayTraceResult result;
                    final EnumFacing facing = ((result = BedAura.mc.world.rayTraceBlocks(new Vec3d(BedAura.mc.player.posX, BedAura.mc.player.posY + BedAura.mc.player.getEyeHeight(), BedAura.mc.player.posZ), new Vec3d(this.maxPos.getX() + 0.5, this.maxPos.getY() - 0.5, this.maxPos.getZ() + 0.5))) == null || result.sideHit == null) ? EnumFacing.UP : result.sideHit;
                    BlockUtil.rightClickBlock(this.maxPos, hitVec, EnumHand.MAIN_HAND, facing, true);
                    this.breakTimer.reset();
                }
            }
            else {
                for (final TileEntity entityBed : BedAura.mc.world.loadedTileEntityList) {
                    if (entityBed instanceof TileEntityBed) {
                        if (BedAura.mc.player.getDistanceSq(entityBed.getPos()) > MathUtil.square(this.breakRange.getValue())) {
                            continue;
                        }
                        final Vec3d hitVec2 = new Vec3d((Vec3i)entityBed.getPos()).add(0.5, 0.5, 0.5);
                        final float[] rotations2 = RotationUtil.getLegitRotations(hitVec2);
                        this.yaw.set((double)rotations2[0]);
                        if (this.rotate.getValue()) {
                            this.shouldRotate.set(true);
                            this.pitch.set((double)rotations2[1]);
                        }
                        final RayTraceResult result2;
                        final EnumFacing facing2 = ((result2 = BedAura.mc.world.rayTraceBlocks(new Vec3d(BedAura.mc.player.posX, BedAura.mc.player.posY + BedAura.mc.player.getEyeHeight(), BedAura.mc.player.posZ), new Vec3d(entityBed.getPos().getX() + 0.5, entityBed.getPos().getY() - 0.5, entityBed.getPos().getZ() + 0.5))) == null || result2.sideHit == null) ? EnumFacing.UP : result2.sideHit;
                        BlockUtil.rightClickBlock(entityBed.getPos(), hitVec2, EnumHand.MAIN_HAND, facing2, true);
                        this.breakTimer.reset();
                    }
                }
            }
        }
    }
    
    private void mapBeds() {
        this.maxPos = null;
        float maxDamage = 0.5f;
        if (this.removeTiles.getValue()) {
            final ArrayList<BedData> removedBlocks = new ArrayList<BedData>();
            for (final TileEntity tile : BedAura.mc.world.loadedTileEntityList) {
                if (!(tile instanceof TileEntityBed)) {
                    continue;
                }
                final TileEntityBed bed = (TileEntityBed)tile;
                final BedData data = new BedData(tile.getPos(), BedAura.mc.world.getBlockState(tile.getPos()), bed, bed.isHeadPiece());
                removedBlocks.add(data);
            }
            for (final BedData data2 : removedBlocks) {
                BedAura.mc.world.setBlockToAir(data2.getPos());
            }
            for (final BedData data2 : removedBlocks) {
                final BlockPos pos;
                if (data2.isHeadPiece() && BedAura.mc.player.getDistanceSq(pos = data2.getPos()) <= MathUtil.square(this.breakRange.getValue())) {
                    final float selfDamage;
                    if ((selfDamage = DamageUtil.calculateDamage(pos, (Entity)BedAura.mc.player)) + 1.0 >= EntityUtil.getHealth((Entity)BedAura.mc.player) && DamageUtil.canTakeDamage(this.suicide.getValue())) {
                        continue;
                    }
                    for (final EntityPlayer player : BedAura.mc.world.playerEntities) {
                        final float damage;
                        if (player.getDistanceSq(pos) < MathUtil.square(this.range.getValue()) && EntityUtil.isValid((Entity)player, this.range.getValue() + this.breakRange.getValue()) && ((damage = DamageUtil.calculateDamage(pos, (Entity)player)) > selfDamage || (damage > this.minDamage.getValue() && !DamageUtil.canTakeDamage(this.suicide.getValue())) || damage > EntityUtil.getHealth((Entity)player))) {
                            if (damage <= maxDamage) {
                                continue;
                            }
                            maxDamage = damage;
                            this.maxPos = pos;
                        }
                    }
                }
            }
            for (final BedData data2 : removedBlocks) {
                BedAura.mc.world.setBlockState(data2.getPos(), data2.getState());
            }
        }
        else {
            for (final TileEntity tile2 : BedAura.mc.world.loadedTileEntityList) {
                final TileEntityBed bed2;
                final BlockPos pos2;
                if (tile2 instanceof TileEntityBed && (bed2 = (TileEntityBed)tile2).isHeadPiece() && BedAura.mc.player.getDistanceSq(pos2 = bed2.getPos()) <= MathUtil.square(this.breakRange.getValue())) {
                    final float selfDamage2;
                    if ((selfDamage2 = DamageUtil.calculateDamage(pos2, (Entity)BedAura.mc.player)) + 1.0 >= EntityUtil.getHealth((Entity)BedAura.mc.player) && DamageUtil.canTakeDamage(this.suicide.getValue())) {
                        continue;
                    }
                    for (final EntityPlayer player : BedAura.mc.world.playerEntities) {
                        final float damage;
                        if (player.getDistanceSq(pos2) < MathUtil.square(this.range.getValue()) && EntityUtil.isValid((Entity)player, this.range.getValue() + this.breakRange.getValue()) && ((damage = DamageUtil.calculateDamage(pos2, (Entity)player)) > selfDamage2 || (damage > this.minDamage.getValue() && !DamageUtil.canTakeDamage(this.suicide.getValue())) || damage > EntityUtil.getHealth((Entity)player))) {
                            if (damage <= maxDamage) {
                                continue;
                            }
                            maxDamage = damage;
                            this.maxPos = pos2;
                        }
                    }
                }
            }
        }
    }
    
    private void placeBeds() {
        if (this.place.getValue() && this.placeTimer.passedMs(this.placeDelay.getValue()) && this.maxPos == null) {
            this.bedSlot = this.findBedSlot();
            if (this.bedSlot == -1 && BedAura.mc.player.getHeldItemOffhand().getItem() == Items.BED) {
                this.bedSlot = -2;
            }
            this.lastHotbarSlot = BedAura.mc.player.inventory.currentItem;
            this.target = EntityUtil.getClosestEnemy(this.placeRange.getValue());
            if (this.target != null) {
                final BlockPos targetPos = new BlockPos(this.target.getPositionVector());
                this.placeBed(targetPos, true);
            }
        }
    }
    
    private void placeBed(final BlockPos pos, final boolean firstCheck) {
        if (BedAura.mc.world.getBlockState(pos).getBlock() == Blocks.BED) {
            return;
        }
        final float damage = DamageUtil.calculateDamage(pos, (Entity)BedAura.mc.player);
        if (damage > EntityUtil.getHealth((Entity)BedAura.mc.player) + 0.5) {
            if (firstCheck && this.oneDot15.getValue()) {
                this.placeBed(pos.up(), false);
            }
            return;
        }
        if (!BedAura.mc.world.getBlockState(pos).getMaterial().isReplaceable()) {
            if (firstCheck && this.oneDot15.getValue()) {
                this.placeBed(pos.up(), false);
            }
            return;
        }
        final ArrayList<BlockPos> positions = new ArrayList<BlockPos>();
        final HashMap<BlockPos, EnumFacing> facings = new HashMap<BlockPos, EnumFacing>();
        for (final EnumFacing facing : EnumFacing.values()) {
            final BlockPos position;
            if (facing != EnumFacing.DOWN && facing != EnumFacing.UP && BedAura.mc.player.getDistanceSq(position = pos.offset(facing)) <= MathUtil.square(this.placeRange.getValue()) && BedAura.mc.world.getBlockState(position).getMaterial().isReplaceable() && !BedAura.mc.world.getBlockState(position.down()).getMaterial().isReplaceable()) {
                positions.add(position);
                facings.put(position, facing.getOpposite());
            }
        }
        if (positions.isEmpty()) {
            if (firstCheck && this.oneDot15.getValue()) {
                this.placeBed(pos.up(), false);
            }
            return;
        }
        positions.sort(Comparator.comparingDouble(pos2 -> BedAura.mc.player.getDistanceSq(pos2)));
        this.finalPos = positions.get(0);
        this.finalFacing = facings.get(this.finalPos);
        final float[] rotation = RotationUtil.simpleFacing(this.finalFacing);
        if (!this.sendRotationPacket && this.extraPacket.getValue()) {
            RotationUtil.faceYawAndPitch(rotation[0], rotation[1]);
            this.sendRotationPacket = true;
        }
        this.yaw.set((double)rotation[0]);
        this.pitch.set((double)rotation[1]);
        this.shouldRotate.set(true);
        OyVey.rotationManager.setPlayerRotations(rotation[0], rotation[1]);
    }
    
    @Override
    public String getDisplayInfo() {
        if (this.target != null) {
            return this.target.getName();
        }
        return null;
    }
    
    @Override
    public void onToggle() {
        this.lastHotbarSlot = -1;
        this.bedSlot = -1;
        this.sendRotationPacket = false;
        this.target = null;
        this.yaw.set(-1.0);
        this.pitch.set(-1.0);
        this.shouldRotate.set(false);
    }
    
    private int findBedSlot() {
        for (int i = 0; i < 9; ++i) {
            final ItemStack stack = BedAura.mc.player.inventory.getStackInSlot(i);
            if (stack != ItemStack.EMPTY && stack.getItem() == Items.BED) {
                return i;
            }
        }
        return -1;
    }
    
    private int safety(final BlockPos pos) {
        int safety = 0;
        for (final EnumFacing facing : EnumFacing.values()) {
            if (!BedAura.mc.world.getBlockState(pos.offset(facing)).getMaterial().isReplaceable()) {
                ++safety;
            }
        }
        return safety;
    }
    
    public enum SwitchModes
    {
        SILENT, 
        NORMAL;
    }
    
    public enum BreakLogic
    {
        ALL, 
        CALC;
    }
    
    public enum Logic
    {
        BREAKPLACE, 
        PLACEBREAK;
    }
    
    public static class BedData
    {
        private final BlockPos pos;
        private final IBlockState state;
        private final boolean isHeadPiece;
        private final TileEntityBed entity;
        
        public BedData(final BlockPos pos, final IBlockState state, final TileEntityBed bed, final boolean isHeadPiece) {
            this.pos = pos;
            this.state = state;
            this.entity = bed;
            this.isHeadPiece = isHeadPiece;
        }
        
        public BlockPos getPos() {
            return this.pos;
        }
        
        public IBlockState getState() {
            return this.state;
        }
        
        public boolean isHeadPiece() {
            return this.isHeadPiece;
        }
        
        public TileEntityBed getEntity() {
            return this.entity;
        }
    }
}
