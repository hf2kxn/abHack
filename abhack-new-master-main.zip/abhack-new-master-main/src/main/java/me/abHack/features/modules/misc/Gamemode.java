

package me.abHack.features.modules.misc;

import me.abHack.features.modules.*;
import net.minecraft.world.*;

public class Gamemode extends Module
{
    public Gamemode() {
        super("Gamemode", "fake gamemode", Category.MISC, true, false, false);
    }
    
    @Override
    public void onTick() {
        if (Gamemode.mc.player == null) {
            return;
        }
        Gamemode.mc.playerController.setGameType(GameType.CREATIVE);
    }
    
    @Override
    public void onDisable() {
        if (Gamemode.mc.player == null) {
            return;
        }
        Gamemode.mc.playerController.setGameType(GameType.SURVIVAL);
    }
}
