

package me.abHack.features.command.commands;

import me.abHack.features.command.*;
import me.abHack.features.modules.misc.*;
import net.minecraft.entity.player.*;
import net.minecraft.item.*;
import java.util.*;

public class PeekCommand extends Command
{
    public PeekCommand() {
        super("peek", new String[] { "<player>" });
    }
    
    public void execute(final String[] commands) {
        if (commands.length == 1) {
            final ItemStack stack = PeekCommand.mc.player.getHeldItemMainhand();
            if (stack == null || !(stack.getItem() instanceof ItemShulkerBox)) {
                Command.sendMessage("��cYou need to hold a Shulker in your mainhand.");
                return;
            }
            ShulkerViewer.displayInv(stack, null);
        }
        if (commands.length > 1) {
            if (ShulkerViewer.getInstance().isOn()) {
                for (final Map.Entry<EntityPlayer, ItemStack> entry : ShulkerViewer.getInstance().spiedPlayers.entrySet()) {
                    if (!entry.getKey().getName().equalsIgnoreCase(commands[0])) {
                        continue;
                    }
                    final ItemStack stack2 = entry.getValue();
                    ShulkerViewer.displayInv(stack2, entry.getKey().getName());
                    break;
                }
            }
            else {
                Command.sendMessage("��cYou need to turn on ShulkerViewer Module");
            }
        }
    }
}
