

package me.abHack.features.gui.alts.ias.tools;

public class Reference
{
    public static final String MODID = "ias";
    public static final String MODNAME = "In-Game Account Switcher";
}
