

package me.abHack.features.modules.misc;

import me.abHack.features.modules.*;
import me.abHack.event.events.*;
import net.minecraft.network.play.server.*;
import net.minecraft.init.*;
import net.minecraftforge.fml.common.eventhandler.*;

public class AntiCrash extends Module
{
    public AntiCrash() {
        super("AntiCrash", "anti offhand crash", Category.MISC, true, false, false);
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Receive event) {
        if (event.getPacket() instanceof SPacketSoundEffect) {
            final SPacketSoundEffect packet = (SPacketSoundEffect)event.getPacket();
            if (packet.getSound() == SoundEvents.ITEM_ARMOR_EQUIP_GENERIC) {
                event.setCanceled(true);
            }
        }
    }
}
