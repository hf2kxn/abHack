!

package me.abHack.features.modules.misc;

import me.abHack.features.modules.*;
import me.abHack.features.setting.*;
import me.abHack.util.*;

public class Timer extends Module
{
    public Setting<Float> timer;
    
    public Timer() {
        super("Timer", "Timer", Category.MISC, true, false, false);
        this.timer = (Setting<Float>)this.register(new Setting("Timer", 1.1f, 1.0f, 5.0f));
    }
    
    @Override
    public void onTick() {
        if (fullNullCheck()) {
            return;
        }
        EntityUtil.setTimer(this.timer.getValue());
    }
    
    @Override
    public void onDisable() {
        EntityUtil.resetTimer();
    }
    
    @Override
    public String getDisplayInfo() {
        return this.timer.getValue() + "";
    }
}
