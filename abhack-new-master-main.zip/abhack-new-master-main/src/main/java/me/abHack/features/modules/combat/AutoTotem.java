

package me.abHack.features.modules.combat;

import me.abHack.features.modules.*;
import me.abHack.features.setting.*;
import net.minecraft.item.*;
import net.minecraft.client.gui.inventory.*;
import net.minecraft.init.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.player.*;
import me.abHack.util.*;
import net.minecraft.entity.*;

public class AutoTotem extends Module
{
    private final Setting<Boolean> strict;
    private final Setting<Integer> health;
    private final Setting<Integer> holehealth;
    private final Setting<Boolean> replenish;
    
    public AutoTotem() {
        super("AutoTotem", "Main Hand AutoTotem", Category.COMBAT, true, false, false);
        this.strict = (Setting<Boolean>)this.register(new Setting("Strict", true));
        this.health = (Setting<Integer>)this.register(new Setting("Health", 13, 0, 36, v -> this.strict.getValue()));
        this.holehealth = (Setting<Integer>)this.register(new Setting("Hole Health", 8, 0, 36, v -> this.strict.getValue()));
        this.replenish = (Setting<Boolean>)this.register(new Setting("Replenish Apple", true));
    }
    
    public static int getItemSlot(final Item item) {
        int itemSlot = -1;
        for (int i = 45; i > 0; --i) {
            if (AutoTotem.mc.player.inventory.getStackInSlot(i).getItem().equals(item)) {
                itemSlot = i;
                break;
            }
        }
        return itemSlot;
    }
    
    @Override
    public void onUpdate() {
        if (AutoTotem.mc.currentScreen instanceof GuiContainer && !(AutoTotem.mc.currentScreen instanceof GuiInventory)) {
            return;
        }
        if (AutoTotem.mc.player.getHeldItemOffhand().getItem() != Items.TOTEM_OF_UNDYING && AutoTotem.mc.player.getHeldItemMainhand().getItem() != Items.TOTEM_OF_UNDYING) {
            final int totemSlot = getItemSlot(Items.TOTEM_OF_UNDYING);
            final int slot = (totemSlot < 9) ? (totemSlot + 36) : totemSlot;
            if (totemSlot != -1) {
                AutoTotem.mc.playerController.windowClick(0, slot, 0, ClickType.PICKUP, (EntityPlayer)AutoTotem.mc.player);
                AutoTotem.mc.playerController.windowClick(0, 36, 0, ClickType.PICKUP, (EntityPlayer)AutoTotem.mc.player);
                AutoTotem.mc.playerController.windowClick(0, slot, 0, ClickType.PICKUP, (EntityPlayer)AutoTotem.mc.player);
            }
            int hotBarSlot = -1;
            for (int l = 0; l < 9; ++l) {
                if (AutoTotem.mc.player.inventory.getStackInSlot(l).getItem() == Items.TOTEM_OF_UNDYING) {
                    hotBarSlot = l;
                    break;
                }
            }
            if ((hotBarSlot != -1 && AutoTotem.mc.player.getHealth() <= ((EntityUtil.isInHole((Entity)AutoTotem.mc.player) && !AutoTotem.mc.player.isInWeb) ? this.holehealth.getValue() : this.health.getValue()) && this.strict.getValue()) || (hotBarSlot != -1 && !this.strict.getValue())) {
                AutoTotem.mc.player.inventory.currentItem = hotBarSlot;
            }
        }
        if (this.replenish.getValue() && AutoTotem.mc.player.getHeldItemOffhand().getItem() != Items.GOLDEN_APPLE) {
            final int appleSlot = getItemSlot(Items.GOLDEN_APPLE);
            final int slot = (appleSlot < 9) ? (appleSlot + 36) : appleSlot;
            if (appleSlot != -1) {
                AutoTotem.mc.playerController.windowClick(0, slot, 0, ClickType.PICKUP, (EntityPlayer)AutoTotem.mc.player);
                AutoTotem.mc.playerController.windowClick(0, 45, 0, ClickType.PICKUP, (EntityPlayer)AutoTotem.mc.player);
                AutoTotem.mc.playerController.windowClick(0, slot, 0, ClickType.PICKUP, (EntityPlayer)AutoTotem.mc.player);
            }
        }
    }
}
