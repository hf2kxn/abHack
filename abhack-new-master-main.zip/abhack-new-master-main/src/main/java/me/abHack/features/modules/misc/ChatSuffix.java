
package me.abHack.features.modules.misc;

import me.abHack.features.modules.*;
import me.abHack.event.events.*;
import net.minecraft.network.play.client.*;
import net.minecraftforge.fml.common.eventhandler.*;

public class ChatSuffix extends Module
{
    public ChatSuffix() {
        super("ChatSuffix", "suffix", Category.MISC, true, false, false);
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Send event) {
        if (event.getStage() == 0 && event.getPacket() instanceof CPacketChatMessage) {
            final CPacketChatMessage packet = (CPacketChatMessage)event.getPacket();
            final String message = packet.getMessage();
            if (!message.startsWith("/")) {
                String abHackChat = message + " | \u267f \u1d00\u0299\u029c\u1d00\u1d04\u1d0b \u267f";
                if (abHackChat.length() >= 256) {
                    abHackChat = abHackChat.substring(0, 256);
                }
                packet.message = abHackChat;
            }
        }
    }
}
