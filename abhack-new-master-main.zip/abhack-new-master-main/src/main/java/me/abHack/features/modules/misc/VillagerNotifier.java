

package me.abHack.features.modules.misc;

import me.abHack.features.modules.*;
import net.minecraft.entity.*;
import net.minecraft.entity.passive.*;
import me.abHack.features.command.*;
import java.util.*;

public class VillagerNotifier extends Module
{
    private static VillagerNotifier instance;
    private final Set<Entity> entities;
    
    public VillagerNotifier() {
        super("VillagerNotifier", "Notifies you when a Villager is discovered", Category.MISC, true, false, false);
        this.entities = new HashSet<Entity>();
        VillagerNotifier.instance = this;
    }
    
    @Override
    public void onEnable() {
        this.entities.clear();
    }
    
    @Override
    public void onUpdate() {
        for (final Entity entity : VillagerNotifier.mc.world.loadedEntityList) {
            if (entity instanceof EntityVillager) {
                if (this.entities.contains(entity)) {
                    continue;
                }
                Command.sendMessage("Villager Detected at: X:" + (int)entity.posX + " X: " + (int)entity.posY + " Z:" + (int)entity.posZ);
                this.entities.add(entity);
            }
        }
    }
}
