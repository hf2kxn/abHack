//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "E:\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package me.abHack.features.modules.render;

import me.abHack.features.modules.*;
import me.abHack.features.setting.*;
import net.minecraft.network.play.server.*;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraft.entity.item.*;
import net.minecraft.entity.*;
import java.util.function.*;
import net.minecraft.init.*;
import me.abHack.event.events.*;
import net.minecraftforge.client.event.*;

public class NoRender extends Module
{
    private static NoRender INSTANCE;
    public Setting<Boolean> armor;
    public Setting<Boolean> fire;
    public Setting<Boolean> blind;
    public Setting<Boolean> nausea;
    public Setting<Boolean> hurtCam;
    public Setting<Boolean> explosions;
    public Setting<Boolean> items;
    public Setting<Boolean> noWeather;
    public Setting<Boolean> skyLightUpdate;
    
    public NoRender() {
        super("NoRender", "Shield some particle effects", Module.Category.RENDER, true, false, false);
        this.armor = (Setting<Boolean>)this.register(new Setting("Armor", (T)true));
        this.fire = (Setting<Boolean>)this.register(new Setting("Frie", (T)true));
        this.blind = (Setting<Boolean>)this.register(new Setting("Blind", (T)true));
        this.nausea = (Setting<Boolean>)this.register(new Setting("Nausea", (T)true));
        this.hurtCam = (Setting<Boolean>)this.register(new Setting("HurtCam", (T)true));
        this.explosions = (Setting<Boolean>)this.register(new Setting("Explosions", (T)false));
        this.items = (Setting<Boolean>)this.register(new Setting("Items", (T)false, "Removes items on the ground."));
        this.noWeather = (Setting<Boolean>)this.register(new Setting("Weather", (T)false, "AntiWeather"));
        this.skyLightUpdate = (Setting<Boolean>)this.register(new Setting("SkyLightUpdate", (T)true));
        this.setInstance();
    }
    
    public static NoRender getInstance() {
        if (NoRender.INSTANCE == null) {
            NoRender.INSTANCE = new NoRender();
        }
        return NoRender.INSTANCE;
    }
    
    private void setInstance() {
        NoRender.INSTANCE = this;
    }
    
    @SubscribeEvent
    public void onPacketReceive(final PacketEvent.Receive event) {
        if (this.explosions.getValue() && event.getPacket() instanceof SPacketExplosion) {
            event.setCanceled(true);
        }
    }
    
    public void onUpdate() {
        if (this.items.getValue()) {
            NoRender.mc.world.loadedEntityList.stream().filter(EntityItem.class::isInstance).map(EntityItem.class::cast).forEach(Entity::setDead);
        }
        if (this.blind.getValue() && NoRender.mc.player.isPotionActive(MobEffects.BLINDNESS)) {
            NoRender.mc.player.removePotionEffect(MobEffects.BLINDNESS);
        }
        if (this.nausea.getValue() && NoRender.mc.player.isPotionActive(MobEffects.NAUSEA)) {
            NoRender.mc.player.removePotionEffect(MobEffects.NAUSEA);
        }
        if (this.noWeather.getValue() && NoRender.mc.world.isRaining()) {
            NoRender.mc.world.setRainStrength(0.0f);
        }
    }
    
    @SubscribeEvent
    public void NoRenderEventListener(final NoRenderEvent event) {
        if (event.getStage() == 0 && this.armor.getValue()) {
            event.setCanceled(true);
        }
        else if (event.getStage() == 1 && this.hurtCam.getValue()) {
            event.setCanceled(true);
        }
    }
    
    @SubscribeEvent
    public void blockOverlayEventListener(final RenderBlockOverlayEvent event) {
        if (this.fire.getValue() && event.getOverlayType() == RenderBlockOverlayEvent.OverlayType.FIRE) {
            event.setCanceled(true);
        }
    }
    
    static {
        NoRender.INSTANCE = new NoRender();
    }
}
