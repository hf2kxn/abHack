

package me.abHack.features.modules.client;

import me.abHack.features.modules.*;
import me.abHack.features.setting.*;
import net.minecraft.client.settings.*;
import me.abHack.*;
import com.mojang.realmsclient.gui.*;
import me.abHack.features.command.*;
import net.minecraftforge.fml.common.eventhandler.*;
import me.abHack.features.gui.*;
import net.minecraft.client.gui.*;
import me.abHack.event.events.*;
import me.abHack.util.*;

public class ClickGui extends Module
{
    private static ClickGui INSTANCE;
    private final Setting<Settings> setting;
    public Setting<String> prefix;
    public Setting<Boolean> customFov;
    public Setting<Float> fov;
    public Setting<Integer> red;
    public Setting<Integer> green;
    public Setting<Integer> blue;
    public Setting<Integer> hoverAlpha;
    public Setting<Integer> alphaBox;
    public Setting<Integer> alpha;
    public Setting<Boolean> rainbow;
    public Setting<rainbowMode> rainbowModeHud;
    public Setting<rainbowModeArray> rainbowModeA;
    public Setting<Integer> rainbowHue;
    public Setting<Float> rainbowBrightness;
    public Setting<Float> rainbowSaturation;
    public Setting<Boolean> outline;
    public Setting<Boolean> moduleDescription;
    public Setting<Boolean> snowing;
    public Setting<Boolean> particles;
    public Setting<Integer> particleLength;
    public Setting<Integer> particlered;
    public Setting<Integer> particlegreen;
    public Setting<Integer> particleblue;
    public Setting<Boolean> rbg;
    public Setting<Boolean> rainbowg;
    public Setting<Boolean> guiComponent;
    public Setting<Integer> g_red;
    public Setting<Integer> g_green;
    public Setting<Integer> g_blue;
    public Setting<Integer> g_red1;
    public Setting<Integer> g_green1;
    public Setting<Integer> g_blue1;
    public Setting<Integer> g_alpha;
    public Setting<Integer> g_alpha1;
    public Setting<Mode> mode;
    public Setting<Integer> backgroundAlpha;
    public Setting<Integer> gb_red;
    public Setting<Integer> gb_green;
    public Setting<Integer> gb_blue;
    private int color;
    
    public ClickGui() {
        super("ClickGui", "Opens the ClickGui", Category.CLIENT, true, false, false);
        this.setting = (Setting<Settings>)this.register(new Setting("Settings", Settings.Gui));
        this.prefix = (Setting<String>)this.register(new Setting("Prefix", ".", v -> this.setting.getValue() == Settings.Gui));
        this.customFov = (Setting<Boolean>)this.register(new Setting("CustomFov", Boolean.FALSE, v -> this.setting.getValue() == Settings.Gui));
        this.fov = (Setting<Float>)this.register(new Setting("Fov", 90.0f, (-180.0f), 180.0f, v -> this.setting.getValue() == Settings.Gui && this.customFov.getValue()));
        this.red = (Setting<Integer>)this.register(new Setting("Red", 100, 0, 255, v -> this.setting.getValue() == Settings.Gui));
        this.green = (Setting<Integer>)this.register(new Setting("Green", 24, 0, 255, v -> this.setting.getValue() == Settings.Gui));
        this.blue = (Setting<Integer>)this.register(new Setting("Blue", 250, 0, 255, v -> this.setting.getValue() == Settings.Gui));
        this.hoverAlpha = (Setting<Integer>)this.register(new Setting("Alpha", 225, 0, 255, v -> this.setting.getValue() == Settings.Gui));
        this.alphaBox = (Setting<Integer>)this.register(new Setting("AlphaBox", 0, 0, 255, v -> this.setting.getValue() == Settings.Gui));
        this.alpha = (Setting<Integer>)this.register(new Setting("HoverAlpha", 240, 0, 255, v -> this.setting.getValue() == Settings.Gui));
        this.rainbow = (Setting<Boolean>)this.register(new Setting("Rainbow", Boolean.TRUE, v -> this.setting.getValue() == Settings.Gui));
        this.rainbowModeHud = (Setting<rainbowMode>)this.register(new Setting("HUD", rainbowMode.Static, v -> this.rainbow.getValue() && this.setting.getValue() == Settings.Gui));
        this.rainbowModeA = (Setting<rainbowModeArray>)this.register(new Setting("ArrayList", rainbowModeArray.Up, v -> this.rainbow.getValue() && this.setting.getValue() == Settings.Gui));
        this.rainbowHue = (Setting<Integer>)this.register(new Setting("Delay", 600, 0, 600, v -> this.rainbow.getValue() && this.setting.getValue() == Settings.Gui));
        this.rainbowBrightness = (Setting<Float>)this.register(new Setting("Brightness ", 255.0f, 1.0f, 255.0f, v -> this.rainbow.getValue() && this.setting.getValue() == Settings.Gui));
        this.rainbowSaturation = (Setting<Float>)this.register(new Setting("Saturation", 255.0f, 1.0f, 255.0f, v -> this.rainbow.getValue() && this.setting.getValue() == Settings.Gui));
        this.outline = (Setting<Boolean>)this.register(new Setting("Outline", true, v -> this.setting.getValue() == Settings.Gui));
        this.moduleDescription = (Setting<Boolean>)this.register(new Setting("Description", true, v -> this.setting.getValue() == Settings.Gui));
        this.snowing = (Setting<Boolean>)this.register(new Setting("Snowing", true, v -> this.setting.getValue() == Settings.Gui));
        this.particles = (Setting<Boolean>)this.register(new Setting("Particles", true, v -> this.setting.getValue() == Settings.Gui));
        this.particleLength = (Setting<Integer>)this.register(new Setting("ParticleLength", 80, 0, 300, v -> this.setting.getValue() == Settings.Gui && this.particles.getValue()));
        this.particlered = (Setting<Integer>)this.register(new Setting("ParticleRed", 255, 0, 255, v -> this.setting.getValue() == Settings.Gui && this.particles.getValue()));
        this.particlegreen = (Setting<Integer>)this.register(new Setting("ParticleGreen", 255, 0, 255, v -> this.setting.getValue() == Settings.Gui && this.particles.getValue()));
        this.particleblue = (Setting<Integer>)this.register(new Setting("ParticleBlue", 255, 0, 255, v -> this.setting.getValue() == Settings.Gui && this.particles.getValue()));
        this.rbg = (Setting<Boolean>)this.register(new Setting("Rainbow", true, v -> this.setting.getValue() == Settings.Gui && this.particles.getValue()));
        this.rainbowg = (Setting<Boolean>)this.register(new Setting("Rainbow", Boolean.FALSE, v -> this.setting.getValue() == Settings.Gradient));
        this.guiComponent = (Setting<Boolean>)this.register(new Setting("Gui Component", Boolean.TRUE, v -> this.setting.getValue() == Settings.Gradient));
        this.g_red = (Setting<Integer>)this.register(new Setting("RedL", 105, 0, 255, v -> this.setting.getValue() == Settings.Gradient));
        this.g_green = (Setting<Integer>)this.register(new Setting("GreenL", 162, 0, 255, v -> this.setting.getValue() == Settings.Gradient));
        this.g_blue = (Setting<Integer>)this.register(new Setting("BlueL", 255, 0, 255, v -> this.setting.getValue() == Settings.Gradient));
        this.g_red1 = (Setting<Integer>)this.register(new Setting("RedR", 143, 0, 255, v -> this.setting.getValue() == Settings.Gradient));
        this.g_green1 = (Setting<Integer>)this.register(new Setting("GreenR", 140, 0, 255, v -> this.setting.getValue() == Settings.Gradient));
        this.g_blue1 = (Setting<Integer>)this.register(new Setting("BlueR", 213, 0, 255, v -> this.setting.getValue() == Settings.Gradient));
        this.g_alpha = (Setting<Integer>)this.register(new Setting("AlphaL", 0, 0, 255, v -> this.setting.getValue() == Settings.Gradient));
        this.g_alpha1 = (Setting<Integer>)this.register(new Setting("AlphaR", 0, 0, 255, v -> this.setting.getValue() == Settings.Gradient));
        this.mode = (Setting<Mode>)this.register(new Setting("Mode", Mode.BLUR, v -> this.setting.getValue() == Settings.Background));
        this.backgroundAlpha = (Setting<Integer>)this.register(new Setting("Background Alpha", 160, 0, 255, v -> this.mode.getValue() == Mode.COLOR && this.setting.getValue() == Settings.Background));
        this.gb_red = (Setting<Integer>)this.register(new Setting("RedBG", 20, 0, 255, v -> this.mode.getValue() == Mode.COLOR && this.setting.getValue() == Settings.Background));
        this.gb_green = (Setting<Integer>)this.register(new Setting("GreenBG", 20, 0, 255, v -> this.mode.getValue() == Mode.COLOR && this.setting.getValue() == Settings.Background));
        this.gb_blue = (Setting<Integer>)this.register(new Setting("BlueBG", 20, 0, 255, v -> this.mode.getValue() == Mode.COLOR && this.setting.getValue() == Settings.Background));
        this.setInstance();
    }
    
    public static ClickGui getInstance() {
        if (ClickGui.INSTANCE == null) {
            ClickGui.INSTANCE = new ClickGui();
        }
        return ClickGui.INSTANCE;
    }
    
    private void setInstance() {
        ClickGui.INSTANCE = this;
    }
    
    @Override
    public void onUpdate() {
        if (this.customFov.getValue()) {
            ClickGui.mc.gameSettings.setOptionFloatValue(GameSettings.Options.FOV, (float)this.fov.getValue());
        }
    }
    
    @SubscribeEvent
    public void onSettingChange(final ClientEvent event) {
        if (event.getStage() == 2 && event.getSetting().getFeature().equals(this)) {
            if (event.getSetting().equals(this.prefix)) {
                OyVey.commandManager.setPrefix(this.prefix.getPlannedValue());
                Command.sendMessage("Prefix set to " + ChatFormatting.DARK_GRAY + OyVey.commandManager.getPrefix());
            }
            OyVey.colorManager.setColor(this.red.getPlannedValue(), this.green.getPlannedValue(), this.blue.getPlannedValue(), this.hoverAlpha.getPlannedValue());
        }
    }
    
    @Override
    public void onEnable() {
        ClickGui.mc.displayGuiScreen((GuiScreen)OyVeyGui.getClickGui());
    }
    
    @Override
    public void onLoad() {
        OyVey.colorManager.setColor(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.hoverAlpha.getValue());
        OyVey.commandManager.setPrefix(this.prefix.getValue());
    }
    
    @Override
    public void onRender2D(final Render2DEvent event) {
        this.drawBackground();
    }
    
    public void drawBackground() {
        if (this.mode.getValue() == Mode.COLOR) {
            if (getInstance().isEnabled()) {
                RenderUtil.drawRectangleCorrectly(0, 0, 1920, 1080, ColorUtil.toRGBA(this.gb_red.getValue(), this.gb_green.getValue(), this.gb_blue.getValue(), this.backgroundAlpha.getValue()));
            }
            else {
                RenderUtil.drawRectangleCorrectly(0, 0, 1920, 1080, ColorUtil.toRGBA(0, 0, 0, 0));
            }
        }
        if (this.mode.getValue() == Mode.NONE) {
            if (getInstance().isEnabled()) {
                RenderUtil.drawRectangleCorrectly(0, 0, 1920, 1080, ColorUtil.toRGBA(this.gb_red.getValue(), this.gb_green.getValue(), this.gb_blue.getValue(), this.backgroundAlpha.getValue()));
            }
            else {
                RenderUtil.drawRectangleCorrectly(0, 0, 1920, 1080, ColorUtil.toRGBA(0, 0, 0, 0));
            }
        }
    }
    
    @Override
    public void onTick() {
        if (!(ClickGui.mc.currentScreen instanceof OyVeyGui)) {
            this.disable();
        }
    }
    
    @Override
    public void onDisable() {
        if (ClickGui.mc.currentScreen instanceof OyVeyGui) {
            Util.mc.displayGuiScreen((GuiScreen)null);
        }
    }
    
    public final int getColor() {
        return this.color;
    }
    
    static {
        ClickGui.INSTANCE = new ClickGui();
    }
    
    public enum Mode
    {
        COLOR, 
        BLUR, 
        NONE;
    }
    
    public enum Settings
    {
        Gui, 
        Gradient, 
        Background;
    }
    
    public enum rainbowMode
    {
        Static, 
        Sideway;
    }
    
    public enum rainbowModeArray
    {
        Static, 
        Up;
    }
}
