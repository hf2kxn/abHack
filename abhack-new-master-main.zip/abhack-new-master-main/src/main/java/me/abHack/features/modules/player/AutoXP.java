//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "E:\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package me.abHack.features.modules.player;

import me.abHack.features.modules.*;
import me.abHack.features.setting.*;
import net.minecraft.item.*;
import net.minecraft.entity.item.*;
import net.minecraft.entity.*;
import net.minecraft.init.*;
import me.abHack.util.*;
import net.minecraft.network.*;
import net.minecraft.util.*;
import net.minecraft.network.play.client.*;

public class AutoXP extends Module
{
    public static AutoXP INSTANCE;
    public final Setting<Bind> bind;
    private final Timer timer;
    private final Setting<Integer> delay;
    private final Setting<Integer> minDamage;
    private final Setting<Integer> maxHeal;
    private final Setting<Boolean> sneakOnly;
    private final Setting<Boolean> predict;
    char toMend;
    
    public AutoXP() {
        super("AutoXP", "AutoXP", Module.Category.PLAYER, true, false, false);
        this.toMend = '\0';
        this.timer = new Timer();
        this.delay = (Setting<Integer>)this.register(new Setting("XP Delay", (T)4, (T)0, (T)4));
        this.minDamage = (Setting<Integer>)this.register(new Setting("Min Damage", (T)50, (T)0, (T)100));
        this.maxHeal = (Setting<Integer>)this.register(new Setting("Repair To", (T)90, (T)0, (T)100));
        this.sneakOnly = (Setting<Boolean>)this.register(new Setting("Sneak Only", (T)false));
        this.predict = (Setting<Boolean>)this.register(new Setting("Predict", (T)false));
        this.bind = (Setting<Bind>)this.register(new Setting("PacketBind", (T)new Bind(-1)));
        AutoXP.INSTANCE = this;
    }
    
    public void onUpdate() {
        if (fullNullCheck()) {
            return;
        }
        if (this.bind.getValue().isDown()) {
            this.mendArmor();
        }
        int sumOfDamage = 0;
        final NonNullList<ItemStack> nonNullList = (NonNullList<ItemStack>)AutoXP.mc.player.inventory.armorInventory;
        for (int i = 0; i < nonNullList.size(); ++i) {
            final ItemStack itemStack = (ItemStack)nonNullList.get(i);
            if (!itemStack.isEmpty) {
                final float damageOnArmor = (float)(itemStack.getMaxDamage() - itemStack.getItemDamage());
                final float damagePercent = 100.0f - 100.0f * (1.0f - damageOnArmor / itemStack.getMaxDamage());
                if (damagePercent <= this.maxHeal.getValue()) {
                    if (damagePercent <= this.minDamage.getValue()) {
                        this.toMend |= (char)(1 << i);
                    }
                    if (this.predict.getValue()) {
                        sumOfDamage = (int)(sumOfDamage + itemStack.getMaxDamage() * this.maxHeal.getValue() / 100.0f - (itemStack.getMaxDamage() - itemStack.getItemDamage()));
                    }
                }
                else {
                    this.toMend &= (char)~(1 << i);
                }
            }
        }
        if (this.toMend > '\0' && this.timer.passedMs(this.delay.getValue() * 45)) {
            this.timer.reset();
            if (this.predict.getValue()) {
                final int totalXp = AutoXP.mc.world.loadedEntityList.stream().filter(entity -> entity instanceof EntityXPOrb).filter(entity -> entity.getDistanceSq((Entity)AutoXP.mc.player) <= 1.0).mapToInt(entity -> entity.xpValue).sum();
                if (totalXp * 2 < sumOfDamage) {
                    this.mendArmor();
                }
            }
            else if (this.sneakOnly.getValue() && AutoXP.mc.player.isSneaking()) {
                this.mendArmor();
            }
        }
    }
    
    private void mendArmor() {
        final int a = InventoryUtil.getItemHotbar(Items.EXPERIENCE_BOTTLE);
        final int b = AutoXP.mc.player.inventory.currentItem;
        if (a == -1) {
            return;
        }
        AutoXP.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(AutoXP.mc.player.rotationYaw, 90.0f, true));
        AutoXP.mc.player.inventory.currentItem = a;
        AutoXP.mc.playerController.updateController();
        AutoXP.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
        AutoXP.mc.player.inventory.currentItem = b;
        AutoXP.mc.playerController.updateController();
    }
}
