//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "E:\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package me.abHack.features.modules.client;

import me.abHack.features.modules.*;
import me.abHack.features.setting.*;
import me.abHack.event.events.*;
import me.abHack.util.*;

public class WaterMark extends Module
{
    private final Setting<Boolean> rainbow;
    public Setting<Integer> compactX;
    public Setting<Integer> compactY;
    public Setting<Integer> red;
    public Setting<Integer> green;
    public Setting<Integer> blue;
    private int color1;
    private int color2;
    
    public WaterMark() {
        super("WaterMark", "watermark", Category.CLIENT, true, false, false);
        this.rainbow = (Setting<Boolean>)this.register(new Setting("Rainbow", true));
        this.compactX = (Setting<Integer>)this.register(new Setting("WaterMarkX", 0, 0, 1080));
        this.compactY = (Setting<Integer>)this.register(new Setting("WaterMarkY", 0, 0, 530));
        this.red = (Setting<Integer>)this.register(new Setting("Red", 20, 0, 255));
        this.green = (Setting<Integer>)this.register(new Setting("Green", 20, 0, 255));
        this.blue = (Setting<Integer>)this.register(new Setting("Blue", 20, 0, 255));
    }
    
    @Override
    public void onRender2D(final Render2DEvent event) {
        if (this.rainbow.getValue()) {
            this.color1 = ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB();
            this.color2 = ColorUtil.rainbow(100).getRGB();
            RenderUtil.drawRectangleCorrectly(this.compactX.getValue(), this.compactY.getValue(), 200, 15, ColorUtil.toRGBA(20, 20, 20, 200));
            RenderUtil.drawGradientSideways(this.compactX.getValue(), 0.0 + this.compactY.getValue(), 200 + this.compactX.getValue(), 1.5 + this.compactY.getValue(), this.color1, this.color2);
            this.renderer.drawString("abHack v0.0.1 | " + HudUtil.getPingSatus() + "ms | " + HudUtil.getFpsStatus() + "fps | " + HudUtil.getTpsStatus() + "tps", this.compactX.getValue(), (float)(this.compactY.getValue() + 3), this.color1, true);
        }
        else {
            this.color1 = ColorUtil.toRGBA(this.red.getValue(), this.green.getValue(), this.blue.getValue(), 255);
            RenderUtil.drawRectangleCorrectly(this.compactX.getValue(), this.compactY.getValue(), 200, 15, ColorUtil.toRGBA(20, 20, 20, 200));
            RenderUtil.drawGradientSideways(this.compactX.getValue(), 0.0 + this.compactY.getValue(), 200 + this.compactX.getValue(), 1.5 + this.compactY.getValue(), this.color1, this.color1);
            this.renderer.drawString("abHack v0.0.1 | " + HudUtil.getPingSatus() + "ms | " + HudUtil.getFpsStatus() + "fps | " + HudUtil.getTpsStatus() + "tps", this.compactX.getValue(), (float)(this.compactY.getValue() + 3), this.color1, true);
        }
    }
}
