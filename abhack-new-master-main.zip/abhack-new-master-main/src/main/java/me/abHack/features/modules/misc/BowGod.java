

package me.abHack.features.modules.misc;

import me.abHack.features.modules.*;
import me.abHack.features.setting.*;
import me.abHack.event.events.*;
import net.minecraft.util.*;
import me.abHack.features.command.*;
import net.minecraft.item.*;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraft.entity.*;
import net.minecraft.network.*;
import net.minecraft.network.play.client.*;

public class BowGod extends Module
{
    private final Setting<String> spoofs;
    public Setting<Boolean> Bows;
    public Setting<Boolean> pearls;
    public Setting<Boolean> eggs;
    public Setting<Boolean> snowballs;
    public Setting<Integer> Timeout;
    public Setting<Boolean> bypass;
    public Setting<Boolean> debug;
    private boolean shooting;
    private long lastShootTime;
    
    public BowGod() {
        super("BowGod", "super bow", Category.MISC, true, false, false);
        this.spoofs = (Setting<String>)this.register(new Setting("Spoofs", "10"));
        this.Bows = (Setting<Boolean>)this.register(new Setting("Bows", true));
        this.pearls = (Setting<Boolean>)this.register(new Setting("Pearls", true));
        this.eggs = (Setting<Boolean>)this.register(new Setting("Eggs", true));
        this.snowballs = (Setting<Boolean>)this.register(new Setting("SnowBallz", true));
        this.Timeout = (Setting<Integer>)this.register(new Setting("Timeout", 500, 0, 2000));
        this.bypass = (Setting<Boolean>)this.register(new Setting("Bypass", false));
        this.debug = (Setting<Boolean>)this.register(new Setting("Debug", false));
    }
    
    @Override
    public void onEnable() {
        if (this.isEnabled()) {
            this.shooting = false;
            this.lastShootTime = System.currentTimeMillis();
        }
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Send event) {
        if (event.getStage() != 0) {
            return;
        }
        if (event.getPacket() instanceof CPacketPlayerDigging) {
            final CPacketPlayerDigging packet = (CPacketPlayerDigging)event.getPacket();
            if (packet.getAction() == CPacketPlayerDigging.Action.RELEASE_USE_ITEM) {
                final ItemStack handStack = BowGod.mc.player.getHeldItem(EnumHand.MAIN_HAND);
                if (!handStack.isEmpty() && handStack.getItem() != null && handStack.getItem() instanceof ItemBow && this.Bows.getValue()) {
                    this.doSpoofs();
                    if (this.debug.getValue()) {
                        Command.sendMessage("trying to spoof");
                    }
                }
            }
        }
        else if (event.getPacket() instanceof CPacketPlayerTryUseItem) {
            final CPacketPlayerTryUseItem packet2 = (CPacketPlayerTryUseItem)event.getPacket();
            if (packet2.getHand() == EnumHand.MAIN_HAND) {
                final ItemStack handStack = BowGod.mc.player.getHeldItem(EnumHand.MAIN_HAND);
                if (!handStack.isEmpty() && handStack.getItem() != null) {
                    if (handStack.getItem() instanceof ItemEgg && this.eggs.getValue()) {
                        this.doSpoofs();
                    }
                    else if (handStack.getItem() instanceof ItemEnderPearl && this.pearls.getValue()) {
                        this.doSpoofs();
                    }
                    else if (handStack.getItem() instanceof ItemSnowball && this.snowballs.getValue()) {
                        this.doSpoofs();
                    }
                }
            }
        }
    }
    
    private void doSpoofs() {
        if (System.currentTimeMillis() - this.lastShootTime >= this.Timeout.getValue()) {
            this.shooting = true;
            this.lastShootTime = System.currentTimeMillis();
            BowGod.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)BowGod.mc.player, CPacketEntityAction.Action.START_SPRINTING));
            for (int index = 0; index < Integer.valueOf(this.spoofs.getValue()); ++index) {
                if (this.bypass.getValue()) {
                    BowGod.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(BowGod.mc.player.posX, BowGod.mc.player.posY + 1.0E-10, BowGod.mc.player.posZ, false));
                    BowGod.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(BowGod.mc.player.posX, BowGod.mc.player.posY - 1.0E-10, BowGod.mc.player.posZ, true));
                }
                else {
                    BowGod.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(BowGod.mc.player.posX, BowGod.mc.player.posY - 1.0E-10, BowGod.mc.player.posZ, true));
                    BowGod.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(BowGod.mc.player.posX, BowGod.mc.player.posY + 1.0E-10, BowGod.mc.player.posZ, false));
                }
            }
            if (this.debug.getValue()) {
                Command.sendMessage("Spoofed");
            }
            this.shooting = false;
        }
    }
}
