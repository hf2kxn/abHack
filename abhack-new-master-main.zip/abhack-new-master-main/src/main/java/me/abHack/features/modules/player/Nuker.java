//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "E:\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package me.abHack.features.modules.player;

import me.abHack.features.modules.*;

public class Nuker extends Module
{
    public Nuker() {
        super("Nuker", "Nuker", Module.Category.PLAYER, true, false, false);
    }
}
