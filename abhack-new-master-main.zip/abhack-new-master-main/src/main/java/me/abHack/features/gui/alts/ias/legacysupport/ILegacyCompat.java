
package me.abHack.features.gui.alts.ias.legacysupport;

public interface ILegacyCompat
{
    int[] getDate();
    
    String getFormattedDate();
}
