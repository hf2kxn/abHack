

package me.abHack.features.command.commands;

import me.abHack.features.command.*;
import java.text.*;
import net.minecraft.client.*;
import java.awt.*;
import java.awt.datatransfer.*;

public class SpawnCommand extends Command
{
    public SpawnCommand() {
        super("spawnCoord", new String[0]);
    }
    
    public void execute(final String[] commands) {
        final DecimalFormat format = new DecimalFormat("#");
        final StringSelection contents = new StringSelection(Minecraft.getMinecraft().player.getBedLocation() + " !");
        final Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(contents, null);
        Command.sendMessage("Saved Spawn Coords to Clipboard, use CTRL + V to paste.");
    }
}
