

package me.abHack.features.modules.combat;

import me.abHack.features.modules.*;
import net.minecraft.entity.player.*;
import me.abHack.features.setting.*;
import net.minecraft.block.*;
import net.minecraft.init.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;
import net.minecraft.network.*;
import net.minecraft.entity.*;
import net.minecraft.entity.item.*;
import net.minecraft.network.play.client.*;
import me.abHack.util.*;
import me.abHack.*;
import java.util.*;
import net.minecraft.item.*;
import net.minecraft.block.state.*;

public class PistonCrystal extends Module
{
    public EntityPlayer target;
    private final Setting<Float> range;
    private final List<Block> godBlocks;
    
    public PistonCrystal() {
        super("PistonCrystal", "Trap Head", Category.COMBAT, true, false, false);
        this.range = (Setting<Float>)this.register(new Setting("Range", 5.0f, 1.0f, 6.0f));
        this.godBlocks = Arrays.asList(Blocks.OBSIDIAN, Blocks.BEDROCK);
    }
    
    @Override
    public void onTick() {
        if (fullNullCheck()) {
            return;
        }
        this.target = this.getTarget(this.range.getValue());
        if (this.target == null) {
            return;
        }
        final int reblock = this.findMaterials(Blocks.REDSTONE_BLOCK);
        final int piston = this.findMaterials((Block)Blocks.PISTON);
        final int crystal = InventoryUtil.getItemHotbar(Items.END_CRYSTAL);
        if (reblock == -1 || piston == -1 || crystal == -1) {
            return;
        }
        final BlockPos people = new BlockPos(this.target.posX, this.target.posY, this.target.posZ);
        final int oldslot = PistonCrystal.mc.player.inventory.currentItem;
        if (!this.godBlocks.contains(this.getBlock(people.add(2, 1, 0)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(2, 0, 0)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(1, 1, 0)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(1, 0, 0)).getBlock())) {
            if (this.getBlock(people.add(1, 1, 0)).getBlock() == Blocks.AIR && this.getBlock(people.add(2, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(people.add(1, 0, 0)).getBlock() != Blocks.AIR) {
                this.switchToSlot(reblock);
                BlockUtil.placeBlock2(people.add(2, 0, 0), EnumHand.MAIN_HAND, true, true, false);
            }
            if (this.getBlock(people.add(1, 1, 0)).getBlock() == Blocks.AIR && this.godBlocks.contains(this.getBlock(people.add(1, 0, 0)).getBlock()) && this.getBlock(people.add(2, 0, 0)).getBlock() == Blocks.REDSTONE_BLOCK) {
                this.switchToSlot(piston);
                BlockUtil.placeBlock2(people.add(2, 1, 0), EnumHand.MAIN_HAND, true, true, false);
                this.switchToSlot(crystal);
                PistonCrystal.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(people.add(1, 0, 0), EnumFacing.UP, (PistonCrystal.mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
            }
            this.switchToSlot(oldslot);
            if (this.getBlock(people.add(1, 1, 0)).getBlock() == Blocks.PISTON_HEAD) {
                PistonCrystal.mc.playerController.onPlayerDamageBlock(people.add(1, 1, 0), BlockUtil.getRayTraceFacing(people.add(1, 1, 0)));
            }
        }
        else if (!this.godBlocks.contains(this.getBlock(people.add(-2, 1, 0)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(-2, 0, 0)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(-1, 1, 0)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(-1, 0, 0)).getBlock())) {
            if (this.getBlock(people.add(-1, 1, 0)).getBlock() == Blocks.AIR && this.getBlock(people.add(-2, 0, 0)).getBlock() == Blocks.AIR && this.getBlock(people.add(-1, 0, 0)).getBlock() != Blocks.AIR) {
                this.switchToSlot(reblock);
                BlockUtil.placeBlock2(people.add(-2, 0, 0), EnumHand.MAIN_HAND, true, true, false);
            }
            if (this.getBlock(people.add(-1, 1, 0)).getBlock() == Blocks.AIR && this.godBlocks.contains(this.getBlock(people.add(-1, 0, 0)).getBlock()) && this.getBlock(people.add(-2, 0, 0)).getBlock() == Blocks.REDSTONE_BLOCK) {
                this.switchToSlot(piston);
                BlockUtil.placeBlock2(people.add(-2, 1, 0), EnumHand.MAIN_HAND, true, true, false);
                this.switchToSlot(crystal);
                PistonCrystal.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(people.add(-1, 0, 0), EnumFacing.UP, (PistonCrystal.mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
            }
            this.switchToSlot(oldslot);
            if (this.getBlock(people.add(-1, 1, 0)).getBlock() == Blocks.PISTON_HEAD) {
                PistonCrystal.mc.playerController.onPlayerDamageBlock(people.add(-1, 1, 0), BlockUtil.getRayTraceFacing(people.add(-1, 1, 0)));
            }
        }
        else if (!this.godBlocks.contains(this.getBlock(people.add(0, 1, 2)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(0, 0, 2)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(0, 1, 1)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(0, 0, 1)).getBlock())) {
            if (this.getBlock(people.add(0, 1, 1)).getBlock() == Blocks.AIR && this.getBlock(people.add(0, 0, 2)).getBlock() == Blocks.AIR && this.getBlock(people.add(0, 0, 1)).getBlock() != Blocks.AIR) {
                this.switchToSlot(reblock);
                BlockUtil.placeBlock2(people.add(0, 0, 2), EnumHand.MAIN_HAND, true, true, false);
            }
            if (this.getBlock(people.add(0, 1, 1)).getBlock() == Blocks.AIR && this.godBlocks.contains(this.getBlock(people.add(0, 0, 1)).getBlock()) && this.getBlock(people.add(0, 0, 2)).getBlock() == Blocks.REDSTONE_BLOCK) {
                this.switchToSlot(piston);
                BlockUtil.placeBlock2(people.add(0, 1, 2), EnumHand.MAIN_HAND, true, true, false);
                this.switchToSlot(crystal);
                PistonCrystal.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(people.add(0, 0, 1), EnumFacing.UP, (PistonCrystal.mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
            }
            this.switchToSlot(oldslot);
            if (this.getBlock(people.add(0, 1, 1)).getBlock() == Blocks.PISTON_HEAD) {
                PistonCrystal.mc.playerController.onPlayerDamageBlock(people.add(0, 1, 1), BlockUtil.getRayTraceFacing(people.add(0, 1, 1)));
            }
        }
        else if (!this.godBlocks.contains(this.getBlock(people.add(0, 1, -2)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(0, 0, -2)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(0, 1, -1)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(0, 0, -1)).getBlock())) {
            if (this.getBlock(people.add(0, 1, -1)).getBlock() == Blocks.AIR && this.getBlock(people.add(0, 0, -2)).getBlock() == Blocks.AIR && this.getBlock(people.add(0, 0, -1)).getBlock() != Blocks.AIR) {
                this.switchToSlot(reblock);
                BlockUtil.placeBlock2(people.add(0, 0, -2), EnumHand.MAIN_HAND, true, true, false);
            }
            if (this.getBlock(people.add(0, 1, -1)).getBlock() == Blocks.AIR && this.godBlocks.contains(this.getBlock(people.add(0, 0, -1)).getBlock()) && this.getBlock(people.add(0, 0, -2)).getBlock() == Blocks.REDSTONE_BLOCK) {
                this.switchToSlot(piston);
                BlockUtil.placeBlock2(people.add(0, 1, -2), EnumHand.MAIN_HAND, true, true, false);
                this.switchToSlot(crystal);
                PistonCrystal.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(people.add(0, 0, -1), EnumFacing.UP, (PistonCrystal.mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
            }
            this.switchToSlot(oldslot);
            if (this.getBlock(people.add(0, 1, -1)).getBlock() == Blocks.PISTON_HEAD) {
                PistonCrystal.mc.playerController.onPlayerDamageBlock(people.add(0, 1, -1), BlockUtil.getRayTraceFacing(people.add(0, 1, -1)));
            }
        }
        else if (!this.godBlocks.contains(this.getBlock(people.add(1, 2, 0)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(3, 2, 0)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(2, 2, 0)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(1, 1, 0)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(2, 1, 0)).getBlock())) {
            this.switchToSlot(piston);
            if (this.getBlock(people.add(3, 1, 0)).getBlock() == Blocks.AIR) {
                BlockUtil.placeBlock2(people.add(3, 1, 0), EnumHand.MAIN_HAND, true, true, false);
            }
            BlockUtil.placeBlock2(people.add(2, 2, 0), EnumHand.MAIN_HAND, true, true, false);
            this.switchToSlot(crystal);
            PistonCrystal.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(people.add(1, 1, 0), EnumFacing.UP, (PistonCrystal.mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
            this.switchToSlot(reblock);
            BlockUtil.placeBlock2(people.add(3, 2, 0), EnumHand.MAIN_HAND, true, true, false);
            this.switchToSlot(oldslot);
            if (this.getBlock(people.add(1, 2, 0)).getBlock() == Blocks.PISTON_HEAD) {
                PistonCrystal.mc.playerController.onPlayerDamageBlock(people.add(1, 2, 0), BlockUtil.getRayTraceFacing(people.add(1, 2, 0)));
            }
        }
        else if (!this.godBlocks.contains(this.getBlock(people.add(-1, 2, 0)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(-3, 2, 0)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(-2, 2, 0)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(-1, 1, 0)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(-2, 1, 0)).getBlock())) {
            this.switchToSlot(piston);
            if (this.getBlock(people.add(-3, 1, 0)).getBlock() == Blocks.AIR) {
                BlockUtil.placeBlock2(people.add(-3, 1, 0), EnumHand.MAIN_HAND, true, true, false);
            }
            BlockUtil.placeBlock2(people.add(-2, 2, 0), EnumHand.MAIN_HAND, true, true, false);
            this.switchToSlot(crystal);
            PistonCrystal.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(people.add(-1, 1, 0), EnumFacing.UP, (PistonCrystal.mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
            this.switchToSlot(reblock);
            BlockUtil.placeBlock2(people.add(-3, 2, 0), EnumHand.MAIN_HAND, true, true, false);
            this.switchToSlot(oldslot);
            if (this.getBlock(people.add(-1, 2, 0)).getBlock() == Blocks.PISTON_HEAD) {
                PistonCrystal.mc.playerController.onPlayerDamageBlock(people.add(-1, 2, 0), BlockUtil.getRayTraceFacing(people.add(-1, 2, 0)));
            }
        }
        else if (!this.godBlocks.contains(this.getBlock(people.add(0, 2, 1)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(0, 2, 3)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(0, 2, 2)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(0, 1, 1)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(0, 1, 2)).getBlock())) {
            this.switchToSlot(piston);
            if (this.getBlock(people.add(0, 1, 3)).getBlock() == Blocks.AIR) {
                BlockUtil.placeBlock2(people.add(0, 1, 3), EnumHand.MAIN_HAND, true, true, false);
            }
            BlockUtil.placeBlock2(people.add(0, 2, 2), EnumHand.MAIN_HAND, true, true, false);
            this.switchToSlot(crystal);
            PistonCrystal.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(people.add(0, 1, 1), EnumFacing.UP, (PistonCrystal.mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
            this.switchToSlot(reblock);
            BlockUtil.placeBlock2(people.add(0, 2, 3), EnumHand.MAIN_HAND, true, true, false);
            this.switchToSlot(oldslot);
            if (this.getBlock(people.add(0, 2, 1)).getBlock() == Blocks.PISTON_HEAD) {
                PistonCrystal.mc.playerController.onPlayerDamageBlock(people.add(0, 2, 1), BlockUtil.getRayTraceFacing(people.add(0, 2, 1)));
            }
        }
        else if (!this.godBlocks.contains(this.getBlock(people.add(0, 2, -1)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(0, 2, -3)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(0, 2, -2)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(0, 1, -1)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(0, 1, -2)).getBlock())) {
            this.switchToSlot(piston);
            if (this.getBlock(people.add(0, 1, -3)).getBlock() == Blocks.AIR) {
                BlockUtil.placeBlock2(people.add(0, 1, -3), EnumHand.MAIN_HAND, true, true, false);
            }
            BlockUtil.placeBlock2(people.add(0, 2, -2), EnumHand.MAIN_HAND, true, true, false);
            this.switchToSlot(crystal);
            PistonCrystal.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(people.add(0, 1, -1), EnumFacing.UP, (PistonCrystal.mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
            this.switchToSlot(reblock);
            BlockUtil.placeBlock2(people.add(0, 2, -3), EnumHand.MAIN_HAND, true, true, false);
            this.switchToSlot(oldslot);
            if (this.getBlock(people.add(0, 2, -1)).getBlock() == Blocks.PISTON_HEAD) {
                PistonCrystal.mc.playerController.onPlayerDamageBlock(people.add(0, 2, -1), BlockUtil.getRayTraceFacing(people.add(0, 2, -1)));
            }
        }
        else if (this.getBlock(people.add(0, 2, 0)).getBlock() == Blocks.AIR && !this.godBlocks.contains(this.getBlock(people.add(1, 3, 0)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(3, 3, 0)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(2, 3, 0)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(1, 2, 0)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(2, 2, 0)).getBlock())) {
            this.switchToSlot(piston);
            if (this.getBlock(people.add(3, 2, 0)).getBlock() == Blocks.AIR) {
                BlockUtil.placeBlock2(people.add(3, 2, 0), EnumHand.MAIN_HAND, true, true, false);
            }
            BlockUtil.placeBlock2(people.add(2, 3, 0), EnumHand.MAIN_HAND, true, true, false);
            this.switchToSlot(crystal);
            PistonCrystal.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(people.add(1, 2, 0), EnumFacing.UP, (PistonCrystal.mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
            this.switchToSlot(reblock);
            BlockUtil.placeBlock2(people.add(3, 3, 0), EnumHand.MAIN_HAND, true, true, false);
            this.switchToSlot(oldslot);
            if (this.getBlock(people.add(1, 3, 0)).getBlock() == Blocks.PISTON_HEAD) {
                PistonCrystal.mc.playerController.onPlayerDamageBlock(people.add(1, 3, 0), BlockUtil.getRayTraceFacing(people.add(1, 3, 0)));
            }
        }
        else if (this.getBlock(people.add(0, 2, 0)).getBlock() == Blocks.AIR && !this.godBlocks.contains(this.getBlock(people.add(-1, 3, 0)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(-3, 3, 0)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(-2, 3, 0)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(-1, 2, 0)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(-2, 2, 0)).getBlock())) {
            this.switchToSlot(piston);
            if (this.getBlock(people.add(-3, 2, 0)).getBlock() == Blocks.AIR) {
                BlockUtil.placeBlock2(people.add(-3, 2, 0), EnumHand.MAIN_HAND, true, true, false);
            }
            BlockUtil.placeBlock2(people.add(-2, 3, 0), EnumHand.MAIN_HAND, true, true, false);
            this.switchToSlot(crystal);
            PistonCrystal.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(people.add(-1, 2, 0), EnumFacing.UP, (PistonCrystal.mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
            this.switchToSlot(reblock);
            BlockUtil.placeBlock2(people.add(-3, 3, 0), EnumHand.MAIN_HAND, true, true, false);
            this.switchToSlot(oldslot);
            if (this.getBlock(people.add(-1, 3, 0)).getBlock() == Blocks.PISTON_HEAD) {
                PistonCrystal.mc.playerController.onPlayerDamageBlock(people.add(-1, 3, 0), BlockUtil.getRayTraceFacing(people.add(-1, 3, 0)));
            }
        }
        else if (this.getBlock(people.add(0, 2, 0)).getBlock() == Blocks.AIR && !this.godBlocks.contains(this.getBlock(people.add(0, 3, 1)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(0, 3, 3)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(0, 3, 2)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(0, 2, 1)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(0, 2, 2)).getBlock())) {
            this.switchToSlot(piston);
            if (this.getBlock(people.add(0, 2, 3)).getBlock() == Blocks.AIR) {
                BlockUtil.placeBlock2(people.add(0, 2, 3), EnumHand.MAIN_HAND, true, true, false);
            }
            BlockUtil.placeBlock2(people.add(0, 3, 2), EnumHand.MAIN_HAND, true, true, false);
            this.switchToSlot(crystal);
            PistonCrystal.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(people.add(0, 2, 1), EnumFacing.UP, (PistonCrystal.mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
            this.switchToSlot(reblock);
            BlockUtil.placeBlock2(people.add(0, 3, 3), EnumHand.MAIN_HAND, true, true, false);
            this.switchToSlot(oldslot);
            if (this.getBlock(people.add(0, 3, 1)).getBlock() == Blocks.PISTON_HEAD) {
                PistonCrystal.mc.playerController.onPlayerDamageBlock(people.add(0, 3, 1), BlockUtil.getRayTraceFacing(people.add(0, 3, 1)));
            }
        }
        else if (this.getBlock(people.add(0, 2, 0)).getBlock() == Blocks.AIR && !this.godBlocks.contains(this.getBlock(people.add(0, 3, -1)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(0, 3, -3)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(0, 3, -2)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(0, 2, -1)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(0, 2, -2)).getBlock())) {
            this.switchToSlot(piston);
            if (this.getBlock(people.add(0, 2, -3)).getBlock() == Blocks.AIR) {
                BlockUtil.placeBlock2(people.add(0, 2, -3), EnumHand.MAIN_HAND, true, true, false);
            }
            BlockUtil.placeBlock2(people.add(0, 3, -2), EnumHand.MAIN_HAND, true, true, false);
            this.switchToSlot(crystal);
            PistonCrystal.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(people.add(0, 2, -1), EnumFacing.UP, (PistonCrystal.mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
            this.switchToSlot(reblock);
            BlockUtil.placeBlock2(people.add(0, 3, -3), EnumHand.MAIN_HAND, true, true, false);
            this.switchToSlot(oldslot);
            if (this.getBlock(people.add(0, 3, -1)).getBlock() == Blocks.PISTON_HEAD) {
                PistonCrystal.mc.playerController.onPlayerDamageBlock(people.add(0, 3, -1), BlockUtil.getRayTraceFacing(people.add(0, 3, -1)));
            }
        }
        else if (this.godBlocks.contains(this.getBlock(people.add(1, 0, 0)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(2, 0, 0)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(3, 0, 0)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(1, 1, 0)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(2, 1, 0)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(3, 1, 0)).getBlock())) {
            this.switchToSlot(piston);
            BlockUtil.placeBlock2(people.add(2, 1, 0), EnumHand.MAIN_HAND, true, true, false);
            this.switchToSlot(crystal);
            PistonCrystal.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(people.add(1, 0, 0), EnumFacing.UP, (PistonCrystal.mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
            this.switchToSlot(reblock);
            BlockUtil.placeBlock2(people.add(3, 1, 0), EnumHand.MAIN_HAND, true, true, false);
            this.switchToSlot(oldslot);
            if (this.getBlock(people.add(1, 1, 0)).getBlock() == Blocks.PISTON_HEAD) {
                PistonCrystal.mc.playerController.onPlayerDamageBlock(people.add(1, 1, 0), BlockUtil.getRayTraceFacing(people.add(1, 1, 0)));
            }
        }
        else if (this.godBlocks.contains(this.getBlock(people.add(-1, 0, 0)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(-2, 0, 0)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(-3, 0, 0)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(-1, 1, 0)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(-2, 1, 0)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(-3, 1, 0)).getBlock())) {
            this.switchToSlot(piston);
            BlockUtil.placeBlock2(people.add(-2, 1, 0), EnumHand.MAIN_HAND, true, true, false);
            this.switchToSlot(crystal);
            PistonCrystal.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(people.add(-1, 0, 0), EnumFacing.UP, (PistonCrystal.mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
            this.switchToSlot(reblock);
            BlockUtil.placeBlock2(people.add(-3, 1, 0), EnumHand.MAIN_HAND, true, true, false);
            this.switchToSlot(oldslot);
            if (this.getBlock(people.add(-1, 1, 0)).getBlock() == Blocks.PISTON_HEAD) {
                PistonCrystal.mc.playerController.onPlayerDamageBlock(people.add(-1, 1, 0), BlockUtil.getRayTraceFacing(people.add(-1, 1, 0)));
            }
        }
        else if (this.godBlocks.contains(this.getBlock(people.add(0, 0, 1)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(0, 0, 2)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(0, 0, 3)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(0, 1, 1)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(0, 1, 2)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(0, 1, 3)).getBlock())) {
            this.switchToSlot(piston);
            BlockUtil.placeBlock2(people.add(0, 1, 2), EnumHand.MAIN_HAND, true, true, false);
            this.switchToSlot(crystal);
            PistonCrystal.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(people.add(0, 0, 1), EnumFacing.UP, (PistonCrystal.mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
            this.switchToSlot(reblock);
            BlockUtil.placeBlock2(people.add(0, 1, 3), EnumHand.MAIN_HAND, true, true, false);
            this.switchToSlot(oldslot);
            if (this.getBlock(people.add(0, 1, 1)).getBlock() == Blocks.PISTON_HEAD) {
                PistonCrystal.mc.playerController.onPlayerDamageBlock(people.add(0, 1, 1), BlockUtil.getRayTraceFacing(people.add(0, 1, 1)));
            }
        }
        else if (this.godBlocks.contains(this.getBlock(people.add(0, 0, -1)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(0, 0, -2)).getBlock()) && this.godBlocks.contains(this.getBlock(people.add(0, 0, -3)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(0, 1, -1)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(0, 1, -2)).getBlock()) && !this.godBlocks.contains(this.getBlock(people.add(0, 1, -3)).getBlock())) {
            this.switchToSlot(piston);
            BlockUtil.placeBlock2(people.add(0, 1, -2), EnumHand.MAIN_HAND, true, true, false);
            this.switchToSlot(crystal);
            PistonCrystal.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(people.add(0, 0, -1), EnumFacing.UP, (PistonCrystal.mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0f, 0.0f, 0.0f));
            this.switchToSlot(reblock);
            BlockUtil.placeBlock2(people.add(0, 1, -3), EnumHand.MAIN_HAND, true, true, false);
            this.switchToSlot(oldslot);
            if (this.getBlock(people.add(0, 1, -1)).getBlock() == Blocks.PISTON_HEAD) {
                PistonCrystal.mc.playerController.onPlayerDamageBlock(people.add(0, 1, -1), BlockUtil.getRayTraceFacing(people.add(0, 1, -1)));
            }
        }
        final Entity t_crystal = (Entity)PistonCrystal.mc.world.loadedEntityList.stream().filter(p -> p instanceof EntityEnderCrystal).min(Comparator.comparing(c -> this.target.getDistance(c))).orElse(null);
        if (t_crystal == null) {
            return;
        }
        PistonCrystal.mc.player.connection.sendPacket((Packet)new CPacketUseEntity(t_crystal));
    }
    
    private EntityPlayer getTarget(final double range) {
        EntityPlayer target = null;
        double distance = range;
        for (final EntityPlayer player : PistonCrystal.mc.world.playerEntities) {
            if (EntityUtil.isntValid((Entity)player, range)) {
                continue;
            }
            if (OyVey.friendManager.isFriend(player.getName())) {
                continue;
            }
            if (PistonCrystal.mc.player.posY - player.posY >= 5.0) {
                continue;
            }
            if (target == null) {
                target = player;
                distance = EntityUtil.mc.player.getDistanceSq((Entity)player);
            }
            else {
                if (EntityUtil.mc.player.getDistanceSq((Entity)player) >= distance) {
                    continue;
                }
                target = player;
                distance = EntityUtil.mc.player.getDistanceSq((Entity)player);
            }
        }
        return target;
    }
    
    private void switchToSlot(final int slot) {
        PistonCrystal.mc.player.inventory.currentItem = slot;
        PistonCrystal.mc.playerController.updateController();
    }
    
    private int findMaterials(final Block b) {
        for (int i = 0; i < 9; ++i) {
            if (PistonCrystal.mc.player.inventory.getStackInSlot(i).getItem() instanceof ItemBlock && ((ItemBlock)PistonCrystal.mc.player.inventory.getStackInSlot(i).getItem()).getBlock() == b) {
                return i;
            }
        }
        return -1;
    }
    
    private IBlockState getBlock(final BlockPos block) {
        return PistonCrystal.mc.world.getBlockState(block);
    }
}
