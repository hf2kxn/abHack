//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "E:\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package me.abHack.features.modules.movement;

import me.abHack.features.modules.*;

public class NoWeb extends Module
{
    public NoWeb() {
        super("NoWeb", "NoWeb", Module.Category.MOVEMENT, true, false, false);
    }
}
