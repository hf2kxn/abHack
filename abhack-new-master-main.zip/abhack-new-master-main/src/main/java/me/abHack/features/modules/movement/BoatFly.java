//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "E:\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package me.abHack.features.modules.movement;

import me.abHack.features.modules.*;
import me.abHack.features.setting.*;

public class BoatFly extends Module
{
    private final Setting<Double> speed;
    private final Setting<Double> yspeed;
    private final Setting<Boolean> glide;
    
    public BoatFly() {
        super("BoatFly", "BoatFly.", Module.Category.MOVEMENT, false, false, false);
        this.speed = (Setting<Double>)this.register(new Setting("Speed", (T)5.0, (T)0.1, (T)20.0));
        this.yspeed = (Setting<Double>)this.register(new Setting("YSpeed", (T)3.0, (T)0.1, (T)20.0));
        this.glide = (Setting<Boolean>)this.register(new Setting("Glide", (T)true));
    }
    
    public void onDisable() {
        if (BoatFly.mc.player.getRidingEntity() != null) {
            BoatFly.mc.player.getRidingEntity().setNoGravity(false);
        }
    }
    
    public void onUpdate() {
        if (BoatFly.mc.player == null || BoatFly.mc.player.getRidingEntity() == null || BoatFly.mc.world == null) {
            return;
        }
        if (BoatFly.mc.player.getRidingEntity() != null) {
            BoatFly.mc.player.getRidingEntity().setNoGravity(true);
            BoatFly.mc.player.getRidingEntity().motionY = 0.0;
            if (BoatFly.mc.gameSettings.keyBindJump.isKeyDown()) {
                BoatFly.mc.player.getRidingEntity().onGround = false;
                BoatFly.mc.player.getRidingEntity().motionY = this.yspeed.getValue();
            }
            if (BoatFly.mc.gameSettings.keyBindSprint.isKeyDown()) {
                BoatFly.mc.player.getRidingEntity().onGround = false;
                BoatFly.mc.player.getRidingEntity().motionY = -(this.speed.getValue() / 10.0);
            }
            final double[] normalDir = this.directionSpeed(this.speed.getValue() / 2.0);
            if (BoatFly.mc.player.movementInput.moveStrafe != 0.0f || BoatFly.mc.player.movementInput.moveForward != 0.0f) {
                BoatFly.mc.player.getRidingEntity().motionX = normalDir[0];
                BoatFly.mc.player.getRidingEntity().motionZ = normalDir[1];
            }
            else {
                BoatFly.mc.player.getRidingEntity().motionX = 0.0;
                BoatFly.mc.player.getRidingEntity().motionZ = 0.0;
            }
            if (this.glide.getValue()) {
                if (BoatFly.mc.gameSettings.keyBindJump.isKeyDown()) {
                    if (BoatFly.mc.player.ticksExisted % 8 < 2) {
                        BoatFly.mc.player.getRidingEntity().motionY = -0.03999999910593033;
                    }
                }
                else if (BoatFly.mc.player.ticksExisted % 8 < 4) {
                    BoatFly.mc.player.getRidingEntity().motionY = -0.03999999910593033;
                }
            }
        }
    }
    
    private double[] directionSpeed(final double speed) {
        float forward = BoatFly.mc.player.movementInput.moveForward;
        float side = BoatFly.mc.player.movementInput.moveStrafe;
        float yaw = BoatFly.mc.player.prevRotationYaw + (BoatFly.mc.player.rotationYaw - BoatFly.mc.player.prevRotationYaw) * BoatFly.mc.getRenderPartialTicks();
        if (forward != 0.0f) {
            if (side > 0.0f) {
                yaw += ((forward > 0.0f) ? -45 : 45);
            }
            else if (side < 0.0f) {
                yaw += ((forward > 0.0f) ? 45 : -45);
            }
            side = 0.0f;
            if (forward > 0.0f) {
                forward = 1.0f;
            }
            else if (forward < 0.0f) {
                forward = -1.0f;
            }
        }
        final double sin = Math.sin(Math.toRadians(yaw + 90.0f));
        final double cos = Math.cos(Math.toRadians(yaw + 90.0f));
        final double posX = forward * speed * cos + side * speed * sin;
        final double posZ = forward * speed * sin - side * speed * cos;
        return new double[] { posX, posZ };
    }
}
