
package me.abHack.features.modules.combat;

import me.abHack.features.modules.*;
import me.abHack.features.setting.*;
import me.abHack.event.events.*;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraft.entity.player.*;
import me.abHack.*;
import net.minecraft.init.*;
import net.minecraft.entity.*;
import me.abHack.util.*;
import java.util.*;

public class Killaura extends Module
{
    public static Entity target;
    private final Timer timer;
    public Setting<Float> range;
    public Setting<Boolean> delay;
    public Setting<Boolean> rotate;
    public Setting<Boolean> onlySharp;
    public Setting<Float> raytrace;
    public Setting<Boolean> players;
    public Setting<Boolean> mobs;
    public Setting<Boolean> animals;
    public Setting<Boolean> vehicles;
    public Setting<Boolean> projectiles;
    public Setting<Boolean> tps;
    public Setting<Boolean> silent;
    public Setting<Boolean> packet;
    
    public Killaura() {
        super("KillAura", "Attacks entities automatically.", Category.COMBAT, true, false, false);
        this.timer = new Timer();
        this.range = (Setting<Float>)this.register(new Setting("Range", 6.0f, 0.1f, 7.0f));
        this.delay = (Setting<Boolean>)this.register(new Setting("HitDelay", true));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", true));
        this.onlySharp = (Setting<Boolean>)this.register(new Setting("SwordOnly", true));
        this.raytrace = (Setting<Float>)this.register(new Setting("Raytrace", 3.0f, 0.1f, 3.0f, "Wall Range."));
        this.players = (Setting<Boolean>)this.register(new Setting("Players", true));
        this.mobs = (Setting<Boolean>)this.register(new Setting("Mobs", false));
        this.animals = (Setting<Boolean>)this.register(new Setting("Animals", false));
        this.vehicles = (Setting<Boolean>)this.register(new Setting("Entities", false));
        this.projectiles = (Setting<Boolean>)this.register(new Setting("Projectiles", false));
        this.tps = (Setting<Boolean>)this.register(new Setting("TpsSync", true));
        this.silent = (Setting<Boolean>)this.register(new Setting("Silent", false));
        this.packet = (Setting<Boolean>)this.register(new Setting("Packet", false));
    }
    
    @Override
    public void onTick() {
        if (!this.rotate.getValue()) {
            this.doKillaura();
        }
    }
    
    @SubscribeEvent
    public void onUpdateWalkingPlayerEvent(final UpdateWalkingPlayerEvent event) {
        if (event.getStage() == 0 && this.rotate.getValue()) {
            this.doKillaura();
        }
    }
    
    private void doKillaura() {
        if (this.onlySharp.getValue() && !EntityUtil.holdingWeapon((EntityPlayer)Killaura.mc.player) && !this.silent.getValue()) {
            Killaura.target = null;
            return;
        }
        int wait = this.delay.getValue() ? ((int)(DamageUtil.getCooldownByWeapon((EntityPlayer)Killaura.mc.player) * (this.tps.getValue() ? OyVey.serverManager.getTpsFactor() : 1.0f))) : 0;
        if (this.silent.getValue() && InventoryUtil.getItemHotbar(Items.DIAMOND_SWORD) != -1) {
            wait = 600;
        }
        if (!this.timer.passedMs(wait)) {
            return;
        }
        Killaura.target = this.getTarget();
        if (Killaura.target == null) {
            return;
        }
        if (this.rotate.getValue()) {
            OyVey.rotationManager.lookAtEntity(Killaura.target);
        }
        if (this.silent.getValue() && InventoryUtil.getItemHotbar(Items.DIAMOND_SWORD) != -1) {
            final int old = Killaura.mc.player.inventory.currentItem;
            final int sword = InventoryUtil.getItemHotbar(Items.DIAMOND_SWORD);
            this.switchToSlot(sword);
            EntityUtil.attackEntity(Killaura.target, this.packet.getValue(), true);
            this.switchToSlot(old);
        }
        else {
            EntityUtil.attackEntity(Killaura.target, this.packet.getValue(), true);
        }
        this.timer.reset();
    }
    
    private Entity getTarget() {
        Entity closestEntity = null;
        for (final Entity entity : Killaura.mc.world.loadedEntityList) {
            if ((this.players.getValue() && entity instanceof EntityPlayer) || (this.mobs.getValue() && EntityUtil.isMobAggressive(entity)) || (this.animals.getValue() && EntityUtil.isPassive(entity)) || (this.vehicles.getValue() && EntityUtil.isVehicle(entity)) || (this.projectiles.getValue() && EntityUtil.isProjectile(entity))) {
                if (entity instanceof EntityLivingBase && EntityUtil.isntValid(entity, this.range.getValue())) {
                    continue;
                }
                if (!Killaura.mc.player.canEntityBeSeen(entity) && Killaura.mc.player.getDistanceSq(entity) > MathUtil.square(this.raytrace.getValue())) {
                    continue;
                }
                if (closestEntity == null) {
                    closestEntity = entity;
                }
                else {
                    if (closestEntity.getDistance((Entity)Killaura.mc.player) <= entity.getDistance((Entity)Killaura.mc.player)) {
                        continue;
                    }
                    closestEntity = entity;
                }
            }
        }
        return closestEntity;
    }
    
    private void switchToSlot(final int slot) {
        Killaura.mc.player.inventory.currentItem = slot;
        Killaura.mc.playerController.updateController();
    }
    
    @Override
    public String getDisplayInfo() {
        if (Killaura.target instanceof EntityPlayer) {
            return Killaura.target.getName();
        }
        return null;
    }
}
