

package me.abHack.features.gui.components.items;

import me.abHack.*;
import me.abHack.util.*;

public class DescriptionDisplay extends Item
{
    private String description;
    private boolean draw;
    
    public DescriptionDisplay(final String description, final float x, final float y) {
        super("DescriptionDisplay");
        this.description = description;
        this.setLocation(x, y);
        this.width = OyVey.textManager.getStringWidth(this.description) + 4;
        this.height = OyVey.textManager.getFontHeight() + 4;
        this.draw = false;
    }
    
    @Override
    public void drawScreen(final int mouseX, final int mouseY, final float partialTicks) {
        this.width = OyVey.textManager.getStringWidth(this.description) + 4;
        this.height = OyVey.textManager.getFontHeight() + 4;
        RenderUtil.drawRect(this.x, this.y, this.x + this.width, this.y + this.height, -704643072);
        OyVey.textManager.drawString(this.description, this.x + 2.0f, this.y + 2.0f, 16777215, true);
    }
    
    public boolean shouldDraw() {
        return this.draw;
    }
    
    public String getDescription() {
        return this.description;
    }
    
    public void setDescription(final String description) {
        this.description = description;
    }
    
    public void setDraw(final boolean draw) {
        this.draw = draw;
    }
}
