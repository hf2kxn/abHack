//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "E:\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package me.abHack.features.modules.render;

import me.abHack.features.modules.*;
import me.abHack.features.setting.*;
import net.minecraft.entity.player.*;
import me.abHack.*;
import net.minecraft.client.network.*;
import java.util.*;
import me.abHack.features.modules.combat.*;
import net.minecraft.client.gui.inventory.*;
import net.minecraft.entity.*;
import com.mojang.realmsclient.gui.*;
import java.text.*;
import me.abHack.features.modules.client.*;
import net.minecraft.item.*;
import net.minecraft.init.*;
import net.minecraft.block.*;
import me.abHack.util.*;
import net.minecraft.util.math.*;
import net.minecraft.client.renderer.*;
import me.abHack.event.events.*;
import net.minecraftforge.fml.common.eventhandler.*;

public class Target extends Module
{
    private static Target INSTANCE;
    public Setting<Boolean> targetHudBackground;
    public Setting<Integer> backgroundAlpha;
    public Setting<Integer> targetHudX;
    public Setting<Integer> targetHudY;
    public Setting<Integer> red;
    public Setting<Integer> green;
    public Setting<Integer> blue;
    private int startcolor1;
    private int endcolor1;
    
    public Target() {
        super("Target", "Displays Target", Module.Category.RENDER, false, false, true);
        this.targetHudBackground = (Setting<Boolean>)this.register(new Setting("TargetHudBackground", (T)true));
        this.backgroundAlpha = (Setting<Integer>)this.register(new Setting("Background Alpha", (T)160, (T)0, (T)255, v -> this.targetHudBackground.getValue()));
        this.targetHudX = (Setting<Integer>)this.register(new Setting("TargetHudX", (T)0, (T)0, (T)1000));
        this.targetHudY = (Setting<Integer>)this.register(new Setting("TargetHudY", (T)0, (T)0, (T)1000));
        this.red = (Setting<Integer>)this.register(new Setting("Background-Red", (T)20, (T)0, (T)255));
        this.green = (Setting<Integer>)this.register(new Setting("Background-Green", (T)20, (T)0, (T)255));
        this.blue = (Setting<Integer>)this.register(new Setting("Background-Blue", (T)20, (T)0, (T)255));
        this.setInstance();
    }
    
    public static Target getInstance() {
        if (Target.INSTANCE == null) {
            Target.INSTANCE = new Target();
        }
        return Target.INSTANCE;
    }
    
    public static EntityPlayer getClosestEnemy() {
        EntityPlayer closestPlayer = null;
        for (final EntityPlayer player : Target.mc.world.playerEntities) {
            if (player != Target.mc.player) {
                if (OyVey.friendManager.isFriend(player)) {
                    continue;
                }
                if (closestPlayer == null) {
                    closestPlayer = player;
                }
                else {
                    if (Target.mc.player.getDistanceSq((Entity)player) >= Target.mc.player.getDistanceSq((Entity)closestPlayer)) {
                        continue;
                    }
                    closestPlayer = player;
                }
            }
        }
        return closestPlayer;
    }
    
    private void setInstance() {
        Target.INSTANCE = this;
    }
    
    public void onRender2D(final Render2DEvent event) {
        if (fullNullCheck()) {
            return;
        }
        this.drawTargetHud(event.partialTicks, (EntityPlayer)Target.mc.player);
    }
    
    public void drawTargetHud(final float partialTicks, final EntityPlayer player) {
        String pingStr = "";
        try {
            final int responseTime = Objects.requireNonNull(Target.mc.getConnection()).getPlayerInfo(Target.mc.player.getUniqueID()).getResponseTime();
            pingStr = pingStr + responseTime + "";
        }
        catch (Exception ex) {}
        EntityPlayer target = (AutoCrystal.target != null) ? AutoCrystal.target : ((Killaura.target instanceof EntityPlayer) ? Killaura.target : getClosestEnemy());
        if (target == null) {
            return;
        }
        if (target.isDead) {
            target = null;
        }
        if (target != null) {
            if (this.targetHudBackground.getValue()) {
                final float f = target.getHealth() + target.getAbsorptionAmount();
                final int j = (f >= 33.0f) ? ColorUtil.toRGBA(0, 255, 0, 255) : ((f >= 30.0f) ? ColorUtil.toRGBA(150, 255, 0, 255) : ((f > 25.0f) ? ColorUtil.toRGBA(75, 255, 0, 255) : ((f > 20.0f) ? ColorUtil.toRGBA(255, 255, 0, 255) : ((f > 15.0f) ? ColorUtil.toRGBA(255, 200, 0, 255) : ((f > 10.0f) ? ColorUtil.toRGBA(255, 150, 0, 255) : ((f > 5.0f) ? ColorUtil.toRGBA(255, 50, 0, 255) : ColorUtil.toRGBA(255, 0, 0, 255)))))));
                RenderUtil.drawRectangleCorrectly(this.targetHudX.getValue(), this.targetHudY.getValue(), 170, 90, ColorUtil.toRGBA(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.backgroundAlpha.getValue()));
                this.startcolor1 = j;
                this.endcolor1 = j;
                RenderUtil.drawGradientSideways(this.targetHudX.getValue(), this.targetHudY.getValue() + 84.0, this.targetHudX.getValue() + f * 4.722222, this.targetHudY.getValue() + 86.8, this.startcolor1, this.endcolor1);
            }
            GlStateManager.disableRescaleNormal();
            GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
            GlStateManager.disableTexture2D();
            GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            try {
                GuiInventory.drawEntityOnScreen(this.targetHudX.getValue() + 30, this.targetHudY.getValue() + 60, 30, 0.0f, 0.0f, (EntityLivingBase)target);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            final int distance = (int)target.getDistance((Entity)Target.mc.player);
            GlStateManager.enableRescaleNormal();
            GlStateManager.enableTexture2D();
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            this.renderer.drawStringWithShadow(target.getName(), (float)(this.targetHudX.getValue() + 60), (float)(this.targetHudY.getValue() + 10), ColorUtil.toRGBA(255, 255, 255, 255));
            if (!EntityUtil.isInHole((Entity)target)) {
                final String hole = "Vunerable";
                final int i = ColorUtil.toRGBA(255, 0, 0, 255);
                this.renderer.drawStringWithShadow("" + ChatFormatting.BOLD + hole, (float)(this.targetHudX.getValue() + 60), (float)(this.targetHudY.getValue() + this.renderer.getFontHeight() + 40), i);
            }
            else {
                final String hole = "Safe";
                final int i = ColorUtil.toRGBA(0, 255, 0, 255);
                this.renderer.drawStringWithShadow("" + ChatFormatting.BOLD + hole, (float)(this.targetHudX.getValue() + 60), (float)(this.targetHudY.getValue() + this.renderer.getFontHeight() + 40), i);
            }
            final float healthLine = target.getHealth() + target.getAbsorptionAmount();
            final int lineColor = (healthLine >= 33.0f) ? ColorUtil.toRGBA(0, 255, 0, 255) : ((healthLine >= 30.0f) ? ColorUtil.toRGBA(150, 255, 0, 255) : ((healthLine > 25.0f) ? ColorUtil.toRGBA(75, 255, 0, 255) : ((healthLine > 20.0f) ? ColorUtil.toRGBA(255, 255, 0, 255) : ((healthLine > 15.0f) ? ColorUtil.toRGBA(255, 200, 0, 255) : ((healthLine > 10.0f) ? ColorUtil.toRGBA(255, 150, 0, 255) : ((healthLine > 5.0f) ? ColorUtil.toRGBA(255, 50, 0, 255) : ColorUtil.toRGBA(255, 0, 0, 255)))))));
            final DecimalFormat df = new DecimalFormat("##.#");
            this.renderer.drawStringWithShadow("", (float)(this.targetHudX.getValue() + 60 + this.renderer.getStringWidth("")), (float)(this.targetHudY.getValue() + 10), lineColor);
            final Integer ping = EntityUtil.isFakePlayer(target) ? 0 : ((Target.mc.getConnection().getPlayerInfo(target.getUniqueID()) == null) ? 0 : Target.mc.getConnection().getPlayerInfo(target.getUniqueID()).getResponseTime());
            final int color = (ping >= 100) ? ColorUtil.toRGBA(0, 255, 0, 255) : ((ping > 50) ? ColorUtil.toRGBA(255, 255, 0, 255) : ColorUtil.toRGBA(255, 255, 255, 255));
            final int distancecolor = (distance <= 5) ? ColorUtil.toRGBA(255, 0, 0, 255) : ((distance < 10) ? ColorUtil.toRGBA(255, 100, 0, 255) : ((distance < 20) ? ColorUtil.toRGBA(255, 150, 0, 255) : ((distance < 30) ? ColorUtil.toRGBA(255, 200, 0, 255) : ((distance < 50) ? ColorUtil.toRGBA(255, 255, 0, 255) : ((distance < 100) ? ColorUtil.toRGBA(150, 255, 0, 255) : ColorUtil.toRGBA(255, 255, 255, 255))))));
            if (FontMod.getInstance().isOn()) {
                this.renderer.drawStringWithShadow("Health: " + healthLine, (float)(this.targetHudX.getValue() + 60), (float)(this.targetHudY.getValue() + this.renderer.getFontHeight() + 12), lineColor);
            }
            else {
                this.renderer.drawStringWithShadow("Health: " + healthLine, (float)(this.targetHudX.getValue() + 60), (float)(this.targetHudY.getValue() + this.renderer.getFontHeight() + 10), lineColor);
            }
            this.renderer.drawStringWithShadow("Ping: " + pingStr, (float)(this.targetHudX.getValue() + 60), (float)(this.targetHudY.getValue() + this.renderer.getFontHeight() + 20), color);
            this.renderer.drawStringWithShadow("Distance: " + distance, (float)(this.targetHudX.getValue() + 60), (float)(this.targetHudY.getValue() + this.renderer.getFontHeight() + 30), distancecolor);
            this.drawOverlay(partialTicks, (Entity)target, this.targetHudX.getValue() + 120, this.targetHudY.getValue() + 35);
            GlStateManager.enableTexture2D();
            int iteration = 0;
            final int k = this.targetHudX.getValue() + 50;
            final int y = this.targetHudY.getValue() + this.renderer.getFontHeight() * 3 + 44;
            for (final ItemStack is : target.inventory.armorInventory) {
                ++iteration;
                if (is.isEmpty()) {
                    continue;
                }
                final int x = k - 90 + (9 - iteration) * 20 + 2;
                GlStateManager.enableDepth();
                RenderUtil.itemRender.zLevel = 200.0f;
                if (FontMod.getInstance().isOn()) {
                    RenderUtil.itemRender.renderItemAndEffectIntoGUI(is, k - 150 + (9 - iteration) * 20 + 2, y + 4);
                    RenderUtil.itemRender.renderItemOverlayIntoGUI(Target.mc.fontRenderer, is, k - 150 + (9 - iteration) * 20 + 2, y + 4, "");
                }
                else {
                    RenderUtil.itemRender.renderItemAndEffectIntoGUI(is, k - 150 + (9 - iteration) * 20 + 2, y - 2);
                    RenderUtil.itemRender.renderItemOverlayIntoGUI(Target.mc.fontRenderer, is, k - 150 + (9 - iteration) * 20 + 2, y - 2, "");
                }
                RenderUtil.itemRender.zLevel = 0.0f;
                GlStateManager.enableTexture2D();
                GlStateManager.disableLighting();
                GlStateManager.disableDepth();
                final String s = (is.getCount() > 1) ? (is.getCount() + "") : "";
                this.renderer.drawStringWithShadow(s, (float)(x - 50 - this.renderer.getStringWidth(s)), (float)(y + 9), 16777215);
                int dmg = 0;
                final int itemDurability = is.getMaxDamage() - is.getItemDamage();
                final float green = (is.getMaxDamage() - (float)is.getItemDamage()) / is.getMaxDamage();
                final float red = 1.0f - green;
                dmg = 100 - (int)(red * 100.0f);
                if (FontMod.getInstance().isOn()) {
                    this.renderer.drawStringWithShadow(dmg + "", (float)(x - 47 - this.renderer.getStringWidth(dmg + "")), (float)(y - 2), ColorUtil.toRGBA((int)(red * 255.0f), (int)(green * 255.0f), 0));
                }
                else {
                    this.renderer.drawStringWithShadow(dmg + "", (float)(x - 47 - this.renderer.getStringWidth(dmg + "")), (float)(y - 8), ColorUtil.toRGBA((int)(red * 255.0f), (int)(green * 255.0f), 0));
                }
            }
        }
    }
    
    public void drawOverlay(final float partialTicks, final Entity player, final int x, final int y) {
        float yaw = 0.0f;
        final int dir = MathHelper.floor(player.rotationYaw * 4.0f / 360.0f + 0.5) & 0x3;
        switch (dir) {
            case 1: {
                yaw = 90.0f;
                break;
            }
            case 2: {
                yaw = -180.0f;
                break;
            }
            case 3: {
                yaw = -90.0f;
                break;
            }
        }
        final BlockPos northPos = this.traceToBlock(partialTicks, yaw, player);
        final Block north = this.getBlock(northPos);
        if (north != null && north != Blocks.AIR) {
            final int damage = this.getBlockDamage(northPos);
            if (damage != 0) {
                RenderUtil.drawRect((float)(x + 16), (float)y, (float)(x + 32), (float)(y + 16), 1627324416);
            }
            this.drawBlock(north, (float)(x + 16), (float)y);
        }
        final BlockPos southPos;
        final Block south;
        if ((south = this.getBlock(southPos = this.traceToBlock(partialTicks, yaw - 180.0f, player))) != null && south != Blocks.AIR) {
            final int damage2 = this.getBlockDamage(southPos);
            if (damage2 != 0) {
                RenderUtil.drawRect((float)(x + 16), (float)(y + 32), (float)(x + 32), (float)(y + 48), 1627324416);
            }
            this.drawBlock(south, (float)(x + 16), (float)(y + 32));
        }
        final BlockPos eastPos;
        final Block east;
        if ((east = this.getBlock(eastPos = this.traceToBlock(partialTicks, yaw + 90.0f, player))) != null && east != Blocks.AIR) {
            final int damage3 = this.getBlockDamage(eastPos);
            if (damage3 != 0) {
                RenderUtil.drawRect((float)(x + 32), (float)(y + 16), (float)(x + 48), (float)(y + 32), 1627324416);
            }
            this.drawBlock(east, (float)(x + 32), (float)(y + 16));
        }
        final BlockPos westPos;
        final Block west;
        if ((west = this.getBlock(westPos = this.traceToBlock(partialTicks, yaw - 90.0f, player))) != null && west != Blocks.AIR) {
            final int damage4 = this.getBlockDamage(westPos);
            if (damage4 != 0) {
                RenderUtil.drawRect((float)x, (float)(y + 16), (float)(x + 16), (float)(y + 32), 1627324416);
            }
            this.drawBlock(west, (float)x, (float)(y + 16));
        }
    }
    
    private int getBlockDamage(final BlockPos pos) {
        for (final DestroyBlockProgress destBlockProgress : Target.mc.renderGlobal.damagedBlocks.values()) {
            if (destBlockProgress.getPosition().getX() == pos.getX() && destBlockProgress.getPosition().getY() == pos.getY()) {
                if (destBlockProgress.getPosition().getZ() != pos.getZ()) {
                    continue;
                }
                return destBlockProgress.getPartialBlockDamage();
            }
        }
        return 0;
    }
    
    private BlockPos traceToBlock(final float partialTicks, final float yaw, final Entity player) {
        final Vec3d pos = EntityUtil.interpolateEntity(player, partialTicks);
        final Vec3d dir = MathUtil.direction(yaw);
        return new BlockPos(pos.x + dir.x, pos.y, pos.z + dir.z);
    }
    
    private Block getBlock(final BlockPos pos) {
        final Block block = Target.mc.world.getBlockState(pos).getBlock();
        if (block == Blocks.BEDROCK || block == Blocks.OBSIDIAN) {
            return block;
        }
        return Blocks.AIR;
    }
    
    private void drawBlock(final Block block, final float x, final float y) {
        final ItemStack stack = new ItemStack(block);
        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        RenderHelper.enableGUIStandardItemLighting();
        GlStateManager.translate(x, y, 0.0f);
        Target.mc.getRenderItem().zLevel = 501.0f;
        Target.mc.getRenderItem().renderItemAndEffectIntoGUI(stack, 0, 0);
        Target.mc.getRenderItem().zLevel = 0.0f;
        RenderHelper.disableStandardItemLighting();
        GlStateManager.disableBlend();
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.popMatrix();
    }
    
    @SubscribeEvent
    public void onReceivePacket(final PacketEvent.Receive event) {
    }
    
    static {
        Target.INSTANCE = new Target();
    }
}
