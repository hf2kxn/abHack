//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "E:\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package me.abHack.features.modules.render;

import me.abHack.features.modules.*;

public class BedCityRender extends Module
{
    public BedCityRender() {
        super("BedCityRender", "BedCityRender", Module.Category.RENDER, true, false, false);
    }
}
