
package me.abHack.features.modules.combat;

import me.abHack.features.modules.*;
import me.abHack.features.setting.*;
import net.minecraft.block.*;
import net.minecraft.util.math.*;
import net.minecraft.entity.*;
import net.minecraft.entity.item.*;
import java.util.*;
import net.minecraft.client.entity.*;
import net.minecraft.util.*;
import me.abHack.util.*;
import net.minecraft.block.state.*;
import net.minecraft.init.*;

public class AntiCev extends Module
{
    public Setting<Boolean> rotate;
    public Setting<Boolean> packet;
    
    public AntiCev() {
        super("AntiCev", "AntiCev", Category.COMBAT, true, false, false);
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", true));
        this.packet = (Setting<Boolean>)this.register(new Setting("Packet", true));
    }
    
    @Override
    public void onTick() {
        if (InventoryUtil.findHotbarBlock(BlockObsidian.class) == -1) {
            return;
        }
        final BlockPos player = new BlockPos(AntiCev.mc.player.posX, AntiCev.mc.player.posY, AntiCev.mc.player.posZ);
        for (final Entity crystal : AntiCev.mc.world.loadedEntityList) {
            if (crystal instanceof EntityEnderCrystal && !crystal.isDead) {
                final BlockPos crystalPos = new BlockPos(crystal.posX, crystal.posY, crystal.posZ);
                if (crystalPos.equals((Object)player.add(0, 3, 0))) {
                    final EntityPlayerSP player = AntiCev.mc.player;
                    ++player.motionY;
                    EntityUtil.attackEntity(crystal, true);
                    this.place(player.add(0, 3, 0));
                }
                if (this.isAir(player.add(1, 1, 0)) && this.isAir(player.add(1, 2, 0)) && crystalPos.equals((Object)player.add(1, 3, 0))) {
                    this.place(player.add(1, 1, 0));
                }
                if (this.isAir(player.add(-1, 1, 0)) && this.isAir(player.add(-1, 2, 0)) && crystalPos.equals((Object)player.add(-1, 3, 0))) {
                    this.place(player.add(-1, 1, 0));
                }
                if (this.isAir(player.add(0, 1, 1)) && this.isAir(player.add(0, 2, 1)) && crystalPos.equals((Object)player.add(0, 3, 1))) {
                    this.place(player.add(0, 1, 1));
                }
                if (this.isAir(player.add(0, 1, -1)) && this.isAir(player.add(0, 2, -1)) && crystalPos.equals((Object)player.add(0, 3, -1))) {
                    this.place(player.add(0, 1, -1));
                }
                if (this.isobs(player.add(1, 1, 1)) && crystalPos.equals((Object)player.add(1, 2, 1))) {
                    EntityUtil.attackEntity(crystal, true);
                    this.place(player.add(1, 2, 1));
                }
                if (this.isAir(player.add(1, 1, 1)) && this.isAir(player.add(1, 2, 1)) && crystalPos.equals((Object)player.add(1, 3, 1))) {
                    EntityUtil.attackEntity(crystal, true);
                    this.place(player.add(1, 1, 1));
                }
                if (this.isobs(player.add(1, 1, -1)) && crystalPos.equals((Object)player.add(1, 2, -1))) {
                    EntityUtil.attackEntity(crystal, true);
                    this.place(player.add(1, 2, -1));
                }
                if (this.isAir(player.add(1, 1, -1)) && this.isAir(player.add(1, 2, -1)) && crystalPos.equals((Object)player.add(1, 3, -1))) {
                    EntityUtil.attackEntity(crystal, true);
                    this.place(player.add(1, 1, -1));
                }
                if (this.isobs(player.add(-1, 1, -1)) && crystalPos.equals((Object)player.add(-1, 2, -1))) {
                    EntityUtil.attackEntity(crystal, true);
                    this.place(player.add(-1, 2, -1));
                }
                if (this.isAir(player.add(-1, 1, -1)) && this.isAir(player.add(-1, 2, -1)) && crystalPos.equals((Object)player.add(-1, 3, -1))) {
                    EntityUtil.attackEntity(crystal, true);
                    this.place(player.add(-1, 1, -1));
                }
                if (this.isobs(player.add(-1, 1, 1)) && crystalPos.equals((Object)player.add(-1, 2, 1))) {
                    EntityUtil.attackEntity(crystal, true);
                    this.place(player.add(-1, 2, 1));
                }
                if (this.isAir(player.add(-1, 1, 1)) && this.isAir(player.add(-1, 2, 1)) && crystalPos.equals((Object)player.add(-1, 3, 1))) {
                    EntityUtil.attackEntity(crystal, true);
                    this.place(player.add(-1, 1, 1));
                }
                if (this.isAir(player.add(0, 5, 0)) && this.isAir(player.add(0, 3, 0)) && this.isobs(player.add(0, 4, 0)) && crystalPos.equals((Object)player.add(0, 5, 0))) {
                    this.place(player.add(0, 2, 0));
                }
                if (this.isAir(player.add(0, 3, 0)) && this.isAir(player.add(0, 3, 0)) && this.isobs(player.add(0, 5, 0)) && crystalPos.equals((Object)player.add(0, 6, 0))) {
                    this.place(player.add(0, 2, 0));
                }
                if (this.isAir(player.add(0, 3, 0)) && this.isAir(player.add(0, 2, 0)) && this.isobs(player.add(1, 3, 0)) && crystalPos.equals((Object)player.add(0, 4, 0))) {
                    this.place(player.add(0, 2, 0));
                }
                if (this.isAir(player.add(0, 3, 0)) && this.isAir(player.add(0, 2, 0)) && this.isobs(player.add(-1, 3, 0)) && crystalPos.equals((Object)player.add(0, 4, 0))) {
                    this.place(player.add(0, 2, 0));
                }
                if (this.isAir(player.add(0, 3, 0)) && this.isAir(player.add(0, 2, 0)) && this.isobs(player.add(0, 3, 1)) && crystalPos.equals((Object)player.add(0, 4, 0))) {
                    this.place(player.add(0, 2, 0));
                }
                if (this.isAir(player.add(0, 3, 0)) && this.isAir(player.add(0, 2, 0)) && this.isobs(player.add(0, 3, -1)) && crystalPos.equals((Object)player.add(0, 4, 0))) {
                    this.place(player.add(0, 2, 0));
                }
                if (this.isAir(player.add(0, 2, 0)) && this.isAir(player.add(1, 1, 0)) && this.isobs(player.add(1, 2, 0)) && crystalPos.equals((Object)player.add(1, 3, 0))) {
                    this.place(player.add(0, 2, 0));
                }
                if (this.isAir(player.add(0, 2, 0)) && this.isAir(player.add(-1, 1, 0)) && this.isobs(player.add(-1, 2, 0)) && crystalPos.equals((Object)player.add(-1, 3, 0))) {
                    this.place(player.add(0, 2, 0));
                }
                if (this.isAir(player.add(0, 2, 0)) && this.isAir(player.add(0, 1, 1)) && this.isobs(player.add(0, 2, 1)) && crystalPos.equals((Object)player.add(0, 3, 1))) {
                    this.place(player.add(0, 2, 0));
                }
                if (this.isAir(player.add(0, 2, 0)) && this.isAir(player.add(0, 1, -1)) && this.isobs(player.add(0, 2, -1)) && crystalPos.equals((Object)player.add(0, 3, -1))) {
                    this.place(player.add(0, 2, 0));
                }
                if (crystalPos.equals((Object)player.add(1, 2, 0))) {
                    EntityUtil.attackEntity(crystal, true);
                    this.place(player.add(1, 2, 0));
                }
                if (crystalPos.equals((Object)player.add(-1, 2, 0))) {
                    EntityUtil.attackEntity(crystal, true);
                    this.place(player.add(-1, 2, 0));
                }
                if (crystalPos.equals((Object)player.add(0, 2, 1))) {
                    EntityUtil.attackEntity(crystal, true);
                    this.place(player.add(0, 2, 1));
                }
                if (crystalPos.equals((Object)player.add(0, 2, -1))) {
                    EntityUtil.attackEntity(crystal, true);
                    this.place(player.add(0, 2, -1));
                }
                if (crystalPos.equals((Object)player.add(1, 1, 0))) {
                    EntityUtil.attackEntity(crystal, true);
                    this.place(player.add(1, 1, 0));
                }
                if (crystalPos.equals((Object)player.add(-1, 1, 0))) {
                    EntityUtil.attackEntity(crystal, true);
                    this.place(player.add(-1, 1, 0));
                }
                if (crystalPos.equals((Object)player.add(0, 1, 1))) {
                    EntityUtil.attackEntity(crystal, true);
                    this.place(player.add(0, 1, 1));
                }
                if (crystalPos.equals((Object)player.add(0, 1, -1))) {
                    EntityUtil.attackEntity(crystal, true);
                    this.place(player.add(0, 1, -1));
                }
                if (crystalPos.equals((Object)player.add(1, 0, 0))) {
                    EntityUtil.attackEntity(crystal, true);
                    this.place(player.add(1, 0, 0));
                }
                if (crystalPos.equals((Object)player.add(-1, 0, 0))) {
                    EntityUtil.attackEntity(crystal, true);
                    this.place(player.add(-1, 0, 0));
                }
                if (crystalPos.equals((Object)player.add(0, 0, 1))) {
                    EntityUtil.attackEntity(crystal, true);
                    this.place(player.add(0, 0, 1));
                }
                if (crystalPos.equals((Object)player.add(0, 0, -1))) {
                    EntityUtil.attackEntity(crystal, true);
                    this.place(player.add(0, 0, -1));
                }
                if (crystalPos.equals((Object)player.add(2, 0, 0))) {
                    EntityUtil.attackEntity(crystal, true);
                    this.place(player.add(2, 0, 0));
                    this.place(player.add(1, 0, 0));
                }
                if (crystalPos.equals((Object)player.add(-2, 0, 0))) {
                    EntityUtil.attackEntity(crystal, true);
                    this.place(player.add(-2, 0, 0));
                    this.place(player.add(-1, 0, 0));
                }
                if (crystalPos.equals((Object)player.add(0, 0, 2))) {
                    EntityUtil.attackEntity(crystal, true);
                    this.place(player.add(0, 0, 2));
                    this.place(player.add(0, 0, 1));
                }
                if (!crystalPos.equals((Object)player.add(0, 0, -2))) {
                    continue;
                }
                EntityUtil.attackEntity(crystal, true);
                this.place(player.add(0, 0, -2));
                this.place(player.add(0, 0, -1));
            }
        }
    }
    
    private void place(final BlockPos pos) {
        if (!this.isAir(pos)) {
            return;
        }
        final int old = AntiCev.mc.player.inventory.currentItem;
        AntiCev.mc.player.inventory.currentItem = InventoryUtil.findHotbarBlock(BlockObsidian.class);
        AntiCev.mc.playerController.updateController();
        BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue(), false);
        AntiCev.mc.player.inventory.currentItem = old;
        AntiCev.mc.playerController.updateController();
    }
    
    private IBlockState getBlock(final BlockPos block) {
        return AntiCev.mc.world.getBlockState(block);
    }
    
    private boolean isAir(final BlockPos pos) {
        return this.getBlock(pos).getBlock() == Blocks.AIR;
    }
    
    private boolean isobs(final BlockPos pos) {
        return this.getBlock(pos).getBlock() == Blocks.OBSIDIAN;
    }
}
