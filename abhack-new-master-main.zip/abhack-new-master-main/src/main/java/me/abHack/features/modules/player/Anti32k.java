//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "E:\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package me.abHack.features.modules.player;

import me.abHack.features.modules.*;
import me.abHack.features.setting.*;
import net.minecraft.init.*;
import net.minecraft.block.*;
import me.abHack.util.*;
import net.minecraft.util.math.*;
import net.minecraft.util.*;
import java.util.*;

public class Anti32k extends Module
{
    private static Anti32k INSTANCE;
    private final Setting<Integer> range;
    
    public Anti32k() {
        super("Anti32k", "Anti32k", Module.Category.PLAYER, true, false, false);
        this.range = (Setting<Integer>)this.register(new Setting("Range", (T)5, (T)3, (T)5));
        this.setInstance();
    }
    
    public static Anti32k getInstance() {
        if (Anti32k.INSTANCE == null) {
            Anti32k.INSTANCE = new Anti32k();
        }
        return Anti32k.INSTANCE;
    }
    
    private void setInstance() {
        Anti32k.INSTANCE = this;
    }
    
    public void onTick() {
        if (fullNullCheck()) {
            return;
        }
        final int mainSlot = Anti32k.mc.player.inventory.currentItem;
        if (InstantMine.getInstance().isOff()) {
            InstantMine.getInstance().enable();
        }
        for (final BlockPos blockPos : this.breakPos(this.range.getValue())) {
            final int slotPick = InventoryUtil.getItemHotbar(Items.DIAMOND_PICKAXE);
            if (slotPick == -1) {
                return;
            }
            if (blockPos == null) {
                continue;
            }
            if (Anti32k.mc.world.getBlockState(blockPos).getBlock() instanceof BlockHopper && Anti32k.mc.world.getBlockState(blockPos.add(0, 1, 0)).getBlock() instanceof BlockShulkerBox) {
                Anti32k.mc.player.inventory.currentItem = slotPick;
                Anti32k.mc.player.swingArm(EnumHand.MAIN_HAND);
                Anti32k.mc.playerController.processRightClickBlock(Anti32k.mc.player, Anti32k.mc.world, blockPos.add(0, 1, 0), BlockUtil.getRayTraceFacing(blockPos.add(0, 1, 0)), new Vec3d((Vec3i)blockPos.add(0, 1, 0)), EnumHand.MAIN_HAND);
                Anti32k.mc.playerController.onPlayerDamageBlock(blockPos, BlockUtil.getRayTraceFacing(blockPos));
            }
            else {
                Anti32k.mc.player.inventory.currentItem = mainSlot;
            }
        }
    }
    
    private NonNullList<BlockPos> breakPos(final float placeRange) {
        final NonNullList<BlockPos> positions = (NonNullList<BlockPos>)NonNullList.create();
        positions.addAll((Collection)BlockUtil.getSphere(new BlockPos(Math.floor(Anti32k.mc.player.posX), Math.floor(Anti32k.mc.player.posY), Math.floor(Anti32k.mc.player.posZ)), placeRange, 0, false, true, 0));
        return positions;
    }
    
    static {
        Anti32k.INSTANCE = new Anti32k();
    }
}
