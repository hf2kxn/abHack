

package me.abHack.features.command.commands;

import me.abHack.features.command.*;
import net.minecraft.client.*;
import java.awt.*;
import java.awt.datatransfer.*;

public final class IpCommand extends Command
{
    public IpCommand() {
        super("IP", new String[0]);
    }
    
    public void execute(final String[] commands) {
        final Minecraft mc = Minecraft.getMinecraft();
        if (mc.getCurrentServerData() != null) {
            final StringSelection contents = new StringSelection(mc.getCurrentServerData().serverIP);
            final Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            clipboard.setContents(contents, null);
            Command.sendMessage("Copied IP to clipboard");
        }
        else {
            Command.sendMessage("Error, Join a server");
        }
    }
}
