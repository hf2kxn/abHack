//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "E:\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package me.abHack.features.modules.player;

import me.abHack.features.modules.*;

public class AutoTool extends Module
{
    public AutoTool() {
        super("AutoTool", "AutoTool", Module.Category.PLAYER, true, false, false);
    }
}
