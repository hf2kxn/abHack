

package me.abHack.features.command.commands;

import me.abHack.features.command.*;
import org.lwjgl.opengl.*;
import com.mojang.realmsclient.gui.*;

public class ClientCommand extends Command
{
    public ClientCommand() {
        super("Client", new String[] { "<name>" });
    }
    
    public void execute(final String[] commands) {
        if (commands.length == 1 || commands[0] == null) {
            Display.setTitle("ab-Hack 0.0.1");
            Command.sendMessage(ChatFormatting.DARK_RED + ".Client <Client Name>");
            return;
        }
        String name = "ab-Hack 0.0.1";
        if (commands[0] != null) {
            name = commands[0];
        }
        if (commands[0] != null && commands[1] != null) {
            name = commands[0] + " " + commands[1];
        }
        Display.setTitle(name);
        Command.sendMessage("new Client Name.");
    }
}
