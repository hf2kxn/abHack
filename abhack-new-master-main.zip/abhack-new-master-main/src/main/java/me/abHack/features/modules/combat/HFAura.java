

package me.abHack.features.modules.combat;

import me.abHack.features.modules.*;
import me.abHack.features.setting.*;
import net.minecraft.entity.item.*;
import net.minecraft.entity.player.*;
import net.minecraft.client.gui.inventory.*;
import net.minecraft.client.gui.*;
import java.util.function.*;
import net.minecraft.entity.*;
import net.minecraft.util.math.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;
import net.minecraft.network.play.server.*;
import net.minecraft.init.*;
import net.minecraftforge.fml.common.eventhandler.*;
import me.abHack.event.events.*;
import me.abHack.features.modules.client.*;
import java.awt.*;
import me.abHack.util.*;
import me.abHack.*;
import net.minecraft.util.*;
import java.util.stream.*;
import java.util.*;

public class HFAura extends Module
{
    private final Timer placeTimer;
    private final Timer breakTimer;
    private final Setting<Settings> setting;
    private final Setting<Boolean> place;
    private final Setting<Double> placeDelay;
    private final Setting<Double> placeRange;
    private final Setting<Boolean> slient;
    private final Setting<Boolean> explode;
    private final Setting<Boolean> packetBreak;
    private final Setting<Double> breakDelay;
    private final Setting<Double> breakRange;
    private final Setting<Boolean> predictsBreak;
    private final Setting<Boolean> fastUpdate;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> antiSuicide;
    private final Setting<Double> raytrace;
    private final Setting<Double> targetRange;
    private final Setting<Double> minPlaceDmg;
    private final Setting<Double> minBreakDmg;
    private final Setting<Double> maxSelfDmg;
    private final Setting<SwingMode> breakSwing;
    private final Setting<Boolean> render;
    private final Setting<Boolean> renderDmg;
    private final Setting<Boolean> box;
    private final Setting<Integer> red;
    private final Setting<Integer> green;
    private final Setting<Integer> blue;
    private final Setting<Integer> alpha;
    private final Setting<Integer> boxAlpha;
    private final Setting<Float> lineWidth;
    private final Setting<Boolean> outline;
    private final Setting<Integer> cRed;
    private final Setting<Integer> cGreen;
    private final Setting<Integer> cBlue;
    private final Setting<Integer> cAlpha;
    private EntityEnderCrystal crystal;
    private boolean rotating;
    private String displaytarget;
    private EntityPlayer target;
    private float pitch;
    private float yaw;
    private BlockPos pos;
    
    public HFAura() {
        super("HFAura", "HF Ez xxs", Category.COMBAT, true, false, false);
        this.placeTimer = new Timer();
        this.breakTimer = new Timer();
        this.setting = (Setting<Settings>)this.register(new Setting("Settings", Settings.PLACE));
        this.place = (Setting<Boolean>)this.register(new Setting("Place", true, v -> this.setting.getValue() == Settings.PLACE));
        this.placeDelay = (Setting<Double>)this.register(new Setting("PlaceDelay", 0.0, 0.0, 500.0, v -> this.place.getValue() && this.setting.getValue() == Settings.PLACE));
        this.placeRange = (Setting<Double>)this.register(new Setting("PlaceRange", 6.0, 0.0, 6.0, v -> this.place.getValue() && this.setting.getValue() == Settings.PLACE));
        this.slient = (Setting<Boolean>)this.register(new Setting("Slient", true, v -> this.place.getValue() && this.setting.getValue() == Settings.PLACE));
        this.explode = (Setting<Boolean>)this.register(new Setting("Break", true, v -> this.setting.getValue() == Settings.BREAK));
        this.packetBreak = (Setting<Boolean>)this.register(new Setting("PacketBreak", true, v -> this.explode.getValue() && this.setting.getValue() == Settings.BREAK));
        this.breakDelay = (Setting<Double>)this.register(new Setting("BreakDelay", 0.0, 0.0, 500.0, v -> this.explode.getValue() && this.setting.getValue() == Settings.BREAK));
        this.breakRange = (Setting<Double>)this.register(new Setting("BreakRange", 6.0, 0.0, 6.0, v -> this.explode.getValue() && this.setting.getValue() == Settings.BREAK));
        this.predictsBreak = (Setting<Boolean>)this.register(new Setting("PredictsBreak", true, v -> this.setting.getValue() == Settings.BREAK));
        this.fastUpdate = (Setting<Boolean>)this.register(new Setting("FastUpDate", true, v -> this.setting.getValue() == Settings.BREAK));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", false, v -> this.setting.getValue() == Settings.MISC));
        this.antiSuicide = (Setting<Boolean>)this.register(new Setting("AntiSuicide", true, v -> this.setting.getValue() == Settings.MISC));
        this.raytrace = (Setting<Double>)this.register(new Setting("Raytrace", 3.0, 0.0, 3.0, v -> this.setting.getValue() == Settings.MISC));
        this.targetRange = (Setting<Double>)this.register(new Setting("TargetRange", 12.0, 0.0, 12.0, v -> this.setting.getValue() == Settings.MISC));
        this.minPlaceDmg = (Setting<Double>)this.register(new Setting("MinPlaceDmg", 5.0, 0.0, 24.0, v -> this.setting.getValue() == Settings.MISC));
        this.minBreakDmg = (Setting<Double>)this.register(new Setting("MinBreakDmg", 5.0, 0.0, 24.0, v -> this.setting.getValue() == Settings.MISC));
        this.maxSelfDmg = (Setting<Double>)this.register(new Setting("MaxSelfDmg", 6.0, 0.0, 12.0, v -> this.setting.getValue() == Settings.MISC));
        this.breakSwing = (Setting<SwingMode>)this.register(new Setting("BreakSwing", SwingMode.MainHand, v -> this.setting.getValue() == Settings.MISC));
        this.render = (Setting<Boolean>)this.register(new Setting("Render", true, v -> this.setting.getValue() == Settings.RENDER));
        this.renderDmg = (Setting<Boolean>)this.register(new Setting("RenderDmg", true, v -> this.render.getValue() && this.setting.getValue() == Settings.RENDER));
        this.box = (Setting<Boolean>)this.register(new Setting("Box", true, v -> this.render.getValue() && this.setting.getValue() == Settings.RENDER));
        this.red = (Setting<Integer>)this.register(new Setting("Red", 255, 0, 255, v -> this.render.getValue() && this.box.getValue() && this.setting.getValue() == Settings.RENDER));
        this.green = (Setting<Integer>)this.register(new Setting("Green", 255, 0, 255, v -> this.render.getValue() && this.box.getValue() && this.setting.getValue() == Settings.RENDER));
        this.blue = (Setting<Integer>)this.register(new Setting("Blue", 255, 0, 255, v -> this.render.getValue() && this.box.getValue() && this.setting.getValue() == Settings.RENDER));
        this.alpha = (Setting<Integer>)this.register(new Setting("Alpha", 200, 0, 255, v -> this.render.getValue() && this.box.getValue() && this.setting.getValue() == Settings.RENDER));
        this.boxAlpha = (Setting<Integer>)this.register(new Setting("BoxAlpha", 100, 0, 255, v -> this.render.getValue() && this.box.getValue() && this.setting.getValue() == Settings.RENDER));
        this.lineWidth = (Setting<Float>)this.register(new Setting("LineWidth", 1.0f, 0.1f, 5.0f, v -> this.render.getValue() && this.box.getValue() && this.setting.getValue() == Settings.RENDER));
        this.outline = (Setting<Boolean>)this.register(new Setting("Outline", true, v -> this.render.getValue() && this.setting.getValue() == Settings.RENDER));
        this.cRed = (Setting<Integer>)this.register(new Setting("OL-Red", 255, 0, 255, v -> this.render.getValue() && this.outline.getValue() && this.setting.getValue() == Settings.RENDER));
        this.cGreen = (Setting<Integer>)this.register(new Setting("OL-Green", 255, 0, 255, v -> this.render.getValue() && this.outline.getValue() && this.setting.getValue() == Settings.RENDER));
        this.cBlue = (Setting<Integer>)this.register(new Setting("OL-Blue", 255, 0, 255, v -> this.render.getValue() && this.outline.getValue() && this.setting.getValue() == Settings.RENDER));
        this.cAlpha = (Setting<Integer>)this.register(new Setting("OL-Alpha", 200, 0, 255, v -> this.render.getValue() && this.outline.getValue() && this.setting.getValue() == Settings.RENDER));
        this.rotating = false;
        this.pitch = 0.0f;
        this.yaw = 0.0f;
    }
    
    @Override
    public void onEnable() {
        this.placeTimer.reset();
        this.breakTimer.reset();
        this.target = null;
        this.displaytarget = null;
        this.crystal = null;
        this.pos = null;
    }
    
    @Override
    public void onDisable() {
        this.rotating = false;
    }
    
    private void switchToSlot(final int slot) {
        HFAura.mc.player.inventory.currentItem = slot;
        HFAura.mc.playerController.updateController();
    }
    
    @Override
    public void onTick() {
        if (fullNullCheck()) {
            return;
        }
        if (HFAura.mc.currentScreen instanceof GuiChest && HFAura.mc.world.getBlockState(HFAura.mc.player.rayTrace(4.5, HFAura.mc.getRenderPartialTicks()).getBlockPos()).getBlock() == Blocks.ENDER_CHEST) {
            HFAura.mc.displayGuiScreen((GuiScreen)null);
        }
        if (HFAura.mc.player.getHeldItemOffhand().getItem() != Items.END_CRYSTAL && HFAura.mc.player.getHeldItemMainhand().getItem() != Items.END_CRYSTAL && !this.slient.getValue()) {
            this.target = null;
            this.pos = null;
            return;
        }
        if (this.target == null) {
            this.target = this.getTarget();
        }
        if (this.target == null) {
            this.crystal = null;
            return;
        }
        this.crystal = (EntityEnderCrystal)HFAura.mc.world.loadedEntityList.stream().filter(this::Hit1).map(crystal -> crystal).min(Comparator.comparing(crystal -> this.target.getDistance(crystal))).orElse(null);
        if (this.crystal != null && this.explode.getValue() && this.breakTimer.passedMs(this.breakDelay.getValue().longValue())) {
            this.breakTimer.reset();
            if (this.packetBreak.getValue()) {
                this.rotateTo((Entity)this.crystal);
                EntityUtil.attackEntity((Entity)this.crystal, true, (this.breakSwing.getValue() == SwingMode.MainHand) ? EnumHand.MAIN_HAND : EnumHand.OFF_HAND);
            }
            else {
                this.rotateTo((Entity)this.crystal);
                EntityUtil.attackEntity((Entity)this.crystal, false, (this.breakSwing.getValue() == SwingMode.MainHand) ? EnumHand.MAIN_HAND : EnumHand.OFF_HAND);
                HFAura.mc.player.resetCooldown();
            }
        }
        if (this.place.getValue() && this.placeTimer.passedMs(this.placeDelay.getValue().longValue())) {
            this.placeTimer.reset();
            double damage = 1.5;
            for (final BlockPos blockPos : this.possiblePlacePositions(this.placeRange.getValue().floatValue())) {
                if (this.target != null && blockPos != null && !this.target.isDead) {
                    if (this.target.getHealth() + this.target.getAbsorptionAmount() <= 0.0f) {
                        continue;
                    }
                    final double targetDamage = DamageUtil.calculateDamage(blockPos.getX() + 0.5, blockPos.getY() + 1.0, blockPos.getZ() + 0.5, (Entity)this.target);
                    if (targetDamage < this.minPlaceDmg.getValue()) {
                        continue;
                    }
                    if (damage >= targetDamage) {
                        continue;
                    }
                    this.pos = blockPos;
                    damage = targetDamage;
                }
            }
            if (damage == 1.5) {
                this.target = null;
                this.pos = null;
                return;
            }
            if (this.pos != null) {
                this.rotateToPos(this.pos);
                if (this.slient.getValue() && InventoryUtil.getItemHotbar(Items.END_CRYSTAL) != -1) {
                    final int end = InventoryUtil.getItemHotbar(Items.END_CRYSTAL);
                    final int old = HFAura.mc.player.inventory.currentItem;
                    this.switchToSlot(end);
                    BlockUtil.placeCrystalOnBlock(this.pos, (HFAura.mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND);
                    this.switchToSlot(old);
                }
                else {
                    BlockUtil.placeCrystalOnBlock(this.pos, (HFAura.mc.player.getHeldItemOffhand().getItem() == Items.END_CRYSTAL) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND);
                }
            }
        }
    }
    
    private void rotateTo(final Entity entity) {
        if (this.rotate.getValue()) {
            final float[] angle = MathUtil.calcAngle(HFAura.mc.player.getPositionEyes(HFAura.mc.getRenderPartialTicks()), entity.getPositionVector());
            this.yaw = angle[0];
            this.pitch = angle[1];
            this.rotating = true;
        }
    }
    
    private void rotateToPos(final BlockPos pos) {
        if (this.rotate.getValue()) {
            final float[] angle = MathUtil.calcAngle(HFAura.mc.player.getPositionEyes(HFAura.mc.getRenderPartialTicks()), new Vec3d((double)(pos.getX() + 0.5f), (double)(pos.getY() - 0.5f), (double)(pos.getZ() + 0.5f)));
            this.yaw = angle[0];
            this.pitch = angle[1];
            this.rotating = true;
        }
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Send event) {
        if (this.rotate.getValue() && this.rotating && event.getPacket() instanceof CPacketPlayer) {
            final CPacketPlayer packet = (CPacketPlayer)event.getPacket();
            packet.yaw = this.yaw;
            packet.pitch = this.pitch;
            this.rotating = false;
        }
    }
    
    @SubscribeEvent(priority = EventPriority.HIGHEST, receiveCanceled = true)
    public void onPacketReceive(final PacketEvent.Receive event) {
        try {
            if (this.predictsBreak.getValue() && event.getPacket() instanceof SPacketSpawnObject) {
                final SPacketSpawnObject packet = (SPacketSpawnObject)event.getPacket();
                if (packet.getType() == 51 && this.Hit2(new BlockPos(packet.getX(), packet.getY(), packet.getZ()))) {
                    final CPacketUseEntity predict = new CPacketUseEntity();
                    predict.entityId = packet.getEntityID();
                    predict.action = CPacketUseEntity.Action.ATTACK;
                    HFAura.mc.player.connection.sendPacket((Packet)predict);
                }
            }
            if (event.getPacket() instanceof SPacketSoundEffect) {
                final SPacketSoundEffect packet2 = (SPacketSoundEffect)event.getPacket();
                if (this.fastUpdate.getValue() && this.crystal != null && packet2.getCategory() == SoundCategory.BLOCKS && packet2.getSound() == SoundEvents.ENTITY_GENERIC_EXPLODE && this.Hit2(new BlockPos(packet2.getX(), packet2.getY(), packet2.getZ()))) {
                    this.crystal.setDead();
                }
            }
        }
        catch (NullPointerException ex) {}
    }
    
    @Override
    public void onRender3D(final Render3DEvent event) {
        if (this.pos != null && this.target != null) {
            RenderUtil.drawBoxESP(this.pos, ((boolean)ClickGui.getInstance().rainbow.getValue()) ? ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()) : new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha.getValue()), this.outline.getValue(), ((boolean)ClickGui.getInstance().rainbow.getValue()) ? ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()) : new Color(this.cRed.getValue(), this.cGreen.getValue(), this.cBlue.getValue(), this.cAlpha.getValue()), this.lineWidth.getValue(), this.outline.getValue(), this.box.getValue(), this.boxAlpha.getValue(), true);
            final double renderDamage = DamageUtil.calculateDamage(this.pos.getX() + 0.5, this.pos.getY() + 1.0, this.pos.getZ() + 0.5, (Entity)this.target);
            final int color = (renderDamage > 18.0) ? 16711680 : ((renderDamage > 16.0) ? 16720896 : ((renderDamage > 12.0) ? 16744192 : ((renderDamage > 8.0) ? 16776960 : ((renderDamage > 5.0) ? 65535 : 65280))));
            if (this.renderDmg.getValue()) {
                RenderUtil.drawText(this.pos, ((Math.floor(renderDamage) == renderDamage) ? Integer.valueOf((int)renderDamage) : String.format("%.1f", renderDamage)) + "", color);
            }
        }
    }
    
    @Override
    public String getDisplayInfo() {
        if (this.target != null) {
            this.displaytarget = this.target.getName();
        }
        if (this.displaytarget != null) {
            return this.displaytarget;
        }
        return null;
    }
    
    private EntityPlayer getTarget() {
        EntityPlayer closestPlayer = null;
        for (final EntityPlayer entity : HFAura.mc.world.playerEntities) {
            if (HFAura.mc.player != null && !HFAura.mc.player.isDead && !entity.isDead && entity.getHealth() + entity.getAbsorptionAmount() > 0.0f && !entity.getName().equals(HFAura.mc.player.getName()) && !OyVey.friendManager.isFriend(entity.getName()) && !entity.isCreative() && !EntityUtil.isInHole((Entity)entity)) {
                if (entity.getDistance((Entity)HFAura.mc.player) > this.targetRange.getValue()) {
                    continue;
                }
                if (closestPlayer == null) {
                    closestPlayer = entity;
                }
                else {
                    if (closestPlayer.getDistance((Entity)HFAura.mc.player) <= entity.getDistance((Entity)HFAura.mc.player)) {
                        continue;
                    }
                    closestPlayer = entity;
                }
            }
        }
        return closestPlayer;
    }
    
    private boolean Hit1(final Entity p_Entity) {
        if (p_Entity == null) {
            return false;
        }
        if (!(p_Entity instanceof EntityEnderCrystal)) {
            return false;
        }
        if (p_Entity.isDead) {
            return false;
        }
        if (this.target == null) {
            return false;
        }
        if (Math.sqrt(HFAura.mc.player.getDistanceSq(p_Entity.posX, p_Entity.posY, p_Entity.posZ)) > this.breakRange.getValue()) {
            return false;
        }
        if (!HFAura.mc.player.canEntityBeSeen(p_Entity) && Math.sqrt(HFAura.mc.player.getDistanceSq(p_Entity.posX, p_Entity.posY, p_Entity.posZ)) > this.raytrace.getValue()) {
            return false;
        }
        if (this.target.isDead || this.target.getHealth() + this.target.getAbsorptionAmount() <= 0.0f) {
            return false;
        }
        final double selfDamage = DamageUtil.calculateDamage(p_Entity.posX, p_Entity.posY, p_Entity.posZ, (Entity)HFAura.mc.player);
        final double targetDamage = DamageUtil.calculateDamage(p_Entity.posX, p_Entity.posY, p_Entity.posZ, (Entity)this.target);
        return selfDamage + (this.antiSuicide.getValue() ? 2.0 : 0.5) < HFAura.mc.player.getHealth() + HFAura.mc.player.getAbsorptionAmount() && selfDamage - 0.5 <= this.maxSelfDmg.getValue() && (targetDamage >= this.target.getHealth() + this.target.getAbsorptionAmount() || targetDamage >= this.minBreakDmg.getValue());
    }
    
    private boolean Hit2(final BlockPos packet) {
        if (packet == null) {
            return false;
        }
        if (this.target == null) {
            return false;
        }
        if (Math.sqrt(HFAura.mc.player.getDistanceSq((double)packet.getX(), (double)packet.getY(), (double)packet.getZ())) > this.breakRange.getValue()) {
            return false;
        }
        if (!BlockUtil.canBlockBeSeen(packet.getX(), packet.getY(), packet.getZ()) && Math.sqrt(HFAura.mc.player.getDistanceSq((double)packet.getX(), (double)packet.getY(), (double)packet.getZ())) > this.raytrace.getValue()) {
            return false;
        }
        if (this.target.isDead || this.target.getHealth() + this.target.getAbsorptionAmount() <= 0.0f) {
            return false;
        }
        final double selfDamage = DamageUtil.calculateDamage(packet.getX(), packet.getY(), packet.getZ(), (Entity)HFAura.mc.player);
        final double targetDamage = DamageUtil.calculateDamage(packet.getX(), packet.getY(), packet.getZ(), (Entity)this.target);
        return selfDamage + (this.antiSuicide.getValue() ? 2.0 : 0.5) < HFAura.mc.player.getHealth() + HFAura.mc.player.getAbsorptionAmount() && selfDamage - 0.5 <= this.maxSelfDmg.getValue() && (targetDamage >= this.target.getHealth() + this.target.getAbsorptionAmount() || targetDamage >= this.minBreakDmg.getValue());
    }
    
    private List<BlockPos> possiblePlacePositions(final float placeRange) {
        final NonNullList<BlockPos> positions = (NonNullList<BlockPos>)NonNullList.create();
        positions.addAll((Collection)BlockUtil.getSphere(new BlockPos(Math.floor(HFAura.mc.player.posX), Math.floor(HFAura.mc.player.posY), Math.floor(HFAura.mc.player.posZ)), placeRange, (int)placeRange, false, true, 0).stream().filter(pos -> BlockUtil.canPlaceCrystal(pos)).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList()));
        double selfDamage;
        positions.removeIf(blockPos -> {
            if (!BlockUtil.canBlockBeSeen(blockPos.getX() + 0.5, blockPos.getY() + 1, blockPos.getZ() + 0.5) && Math.sqrt(HFAura.mc.player.getDistanceSq(blockPos.getX() + 0.5, (double)(blockPos.getY() + 1), blockPos.getZ() + 0.5)) > this.raytrace.getValue()) {
                return true;
            }
            else {
                selfDamage = DamageUtil.calculateDamage(blockPos.getX() + 0.5, blockPos.getY() + 1.0, blockPos.getZ() + 0.5, (Entity)HFAura.mc.player);
                return selfDamage + (this.antiSuicide.getValue() ? 2.0 : 0.5) >= HFAura.mc.player.getHealth() + HFAura.mc.player.getAbsorptionAmount() || selfDamage - 0.5 > this.maxSelfDmg.getValue();
            }
        });
        return (List<BlockPos>)positions;
    }
    
    public enum SwingMode
    {
        MainHand, 
        OffHand;
    }
    
    public enum Settings
    {
        PLACE, 
        BREAK, 
        MISC, 
        RENDER;
    }
}
