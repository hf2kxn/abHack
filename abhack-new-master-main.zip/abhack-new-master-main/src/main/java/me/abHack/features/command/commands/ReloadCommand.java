

package me.abHack.features.command.commands;

import me.abHack.features.command.*;
import me.abHack.*;

public class ReloadCommand extends Command
{
    public ReloadCommand() {
        super("reload", new String[0]);
    }
    
    public void execute(final String[] commands) {
        OyVey.reload();
    }
}
