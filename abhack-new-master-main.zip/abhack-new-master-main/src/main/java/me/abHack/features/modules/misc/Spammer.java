

package me.abHack.features.modules.misc;

import me.abHack.features.modules.*;
import me.abHack.features.setting.*;
import me.abHack.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;
import me.abHack.util.*;
import java.util.*;

public class Spammer extends Module
{
    private static final String fileName = "ab-Hack/Spammer.txt";
    private static final String defaultMessage = "Welcome to use abHack";
    private static final List<String> spamMessages;
    private static final Random rnd;
    private final Setting<Boolean> escoff;
    private final Timer timer;
    private final List<String> sendPlayers;
    public Setting<Mode> mode;
    public Setting<Integer> delay;
    public Setting<String> custom;
    public Setting<String> msgTarget;
    public Setting<Boolean> greentext;
    public Setting<Boolean> random;
    public Setting<Boolean> loadFile;
    
    public Spammer() {
        super("Spammer", "Spams stuff.", Category.MISC, true, false, false);
        this.escoff = (Setting<Boolean>)this.register(new Setting("EscOff", true));
        this.timer = new Timer();
        this.sendPlayers = new ArrayList<String>();
        this.mode = (Setting<Mode>)this.register(new Setting("Mode", Mode.FILE));
        this.delay = (Setting<Integer>)this.register(new Setting("Delay", 5, 0, 20));
        this.custom = (Setting<String>)this.register(new Setting("Custom", "String", v -> this.mode.getValue() == Mode.MSG));
        this.msgTarget = (Setting<String>)this.register(new Setting("MsgTarget", "Target...", v -> this.mode.getValue() == Mode.MSG));
        this.greentext = (Setting<Boolean>)this.register(new Setting("Greentext", false, v -> this.mode.getValue() == Mode.FILE));
        this.random = (Setting<Boolean>)this.register(new Setting("Random", false, v -> this.mode.getValue() == Mode.FILE));
        this.loadFile = (Setting<Boolean>)this.register(new Setting("LoadFile", false, v -> this.mode.getValue() == Mode.FILE));
    }
    
    @Override
    public void onEnable() {
        if (fullNullCheck()) {
            this.disable();
            return;
        }
        this.readSpamFile();
    }
    
    @Override
    public void onLogin() {
        if (this.escoff.getValue() && OyVey.moduleManager.isModuleEnabled("Spammer")) {
            this.disable();
        }
    }
    
    @Override
    public void onLogout() {
        if (this.escoff.getValue() && OyVey.moduleManager.isModuleEnabled("Spammer")) {
            this.disable();
        }
    }
    
    @Override
    public void onDisable() {
        Spammer.spamMessages.clear();
        this.timer.reset();
    }
    
    @Override
    public void onUpdate() {
        if (fullNullCheck()) {
            this.disable();
            return;
        }
        if (this.loadFile.getValue()) {
            this.readSpamFile();
            this.loadFile.setValue(false);
        }
        if (this.timer.passedS(this.delay.getValue())) {
            if (this.mode.getValue() == Mode.MSG) {
                String msg = this.custom.getValue();
                msg = "/msg " + this.msgTarget.getValue() + " " + msg;
                Spammer.mc.player.sendChatMessage(msg);
            }
            else if (Spammer.spamMessages.size() > 0) {
                String messageOut;
                if (this.random.getValue()) {
                    final int index = Spammer.rnd.nextInt(Spammer.spamMessages.size());
                    messageOut = Spammer.spamMessages.get(index);
                    Spammer.spamMessages.remove(index);
                }
                else {
                    messageOut = Spammer.spamMessages.get(0);
                    Spammer.spamMessages.remove(0);
                }
                Spammer.spamMessages.add(messageOut);
                if (this.greentext.getValue()) {
                    messageOut = "> " + messageOut;
                }
                Spammer.mc.player.connection.sendPacket((Packet)new CPacketChatMessage(messageOut.replaceAll("��", "")));
            }
            this.timer.reset();
        }
    }
    
    private void readSpamFile() {
        final List<String> fileInput = FileUtil.readTextFileAllLines("ab-Hack/Spammer.txt");
        final Iterator<String> i = fileInput.iterator();
        Spammer.spamMessages.clear();
        while (i.hasNext()) {
            final String s = i.next();
            if (s.replaceAll("\\s", "").isEmpty()) {
                continue;
            }
            Spammer.spamMessages.add(s);
        }
        if (Spammer.spamMessages.size() == 0) {
            Spammer.spamMessages.add("Welcome to use abHack");
        }
    }
    
    static {
        spamMessages = new ArrayList<String>();
        rnd = new Random();
    }
    
    public enum Mode
    {
        FILE, 
        MSG;
    }
}
