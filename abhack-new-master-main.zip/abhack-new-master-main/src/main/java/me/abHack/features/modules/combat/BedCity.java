
package me.abHack.features.modules.combat;

import me.abHack.features.modules.*;

public class BedCity extends Module
{
    public BedCity() {
        super("BedCity", "BedCity", Category.COMBAT, true, false, false);
    }
}
