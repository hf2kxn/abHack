
package me.abHack.features.modules.combat;

import me.abHack.features.modules.*;

public class AutoPush extends Module
{
    public AutoPush() {
        super("Autopush", "autopush", Category.COMBAT, true, false, false);
    }
}
