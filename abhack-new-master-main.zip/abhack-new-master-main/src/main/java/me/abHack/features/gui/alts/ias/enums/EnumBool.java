

package me.abHack.features.gui.alts.ias.enums;

public enum EnumBool
{
    TRUE, 
    FALSE, 
    UNKNOWN;
}
