
package me.abHack.features.command.commands;

import me.abHack.features.command.*;
import com.mojang.realmsclient.gui.*;

public class VclipCommand extends Command
{
    public VclipCommand() {
        super("vclip", new String[] { "<y>" });
    }
    
    public void execute(final String[] commands) {
        if (commands.length == 1) {
            Command.sendMessage(ChatFormatting.DARK_RED + ".Vclip <Highly>");
            return;
        }
        final int y = Integer.parseInt(commands[0]);
        Command.sendMessage("Vclip to " + ChatFormatting.GRAY + y);
        VclipCommand.mc.player.setPosition(VclipCommand.mc.player.posX, VclipCommand.mc.player.posY + y, VclipCommand.mc.player.posZ);
    }
}
