
package me.abHack.features.modules.misc;

import me.abHack.features.modules.*;

public class ColorSigns extends Module
{
    public ColorSigns() {
        super("ColorSigns", "ColorSigns", Category.MISC, true, false, false);
    }
}
