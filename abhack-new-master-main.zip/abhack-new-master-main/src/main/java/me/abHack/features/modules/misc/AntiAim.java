

package me.abHack.features.modules.misc;

import me.abHack.features.modules.*;

public class AntiAim extends Module
{
    public AntiAim() {
        super("AntiAim", "AntiAim", Category.MISC, true, false, false);
    }
}
