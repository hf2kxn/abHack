//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "E:\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package me.abHack.features.modules.player;

import me.abHack.features.modules.*;
import me.abHack.features.setting.*;
import net.minecraft.block.*;
import net.minecraft.util.*;
import me.abHack.features.modules.combat.*;
import net.minecraft.world.*;
import net.minecraft.inventory.*;
import net.minecraft.entity.player.*;
import net.minecraft.network.*;
import net.minecraft.block.state.*;
import net.minecraft.init.*;
import net.minecraft.enchantment.*;
import net.minecraft.item.*;
import net.minecraft.entity.item.*;
import java.util.stream.*;
import net.minecraft.entity.*;
import net.minecraft.network.play.client.*;
import java.util.*;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraftforge.client.event.*;
import net.minecraft.util.math.*;
import me.abHack.features.modules.client.*;
import java.awt.*;
import me.abHack.util.*;
import me.abHack.event.events.*;

public class InstantMine extends Module
{
    public static BlockPos breakPos2;
    public static BlockPos breakPos;
    private static InstantMine INSTANCE;
    private final Timer breakSuccess;
    public final Timer Rendertimer;
    private final Setting<Boolean> creativeMode;
    private final Setting<Float> range;
    private final Setting<Boolean> ghostHand;
    private final Setting<Boolean> superghost;
    private final Setting<Boolean> doubleBreak;
    private final Setting<Boolean> crystal;
    public final Setting<Boolean> attackcrystal;
    public final Setting<Bind> bind;
    private final Setting<Boolean> instant;
    private final Setting<Boolean> render;
    public Setting<Mode> rendermode;
    private final Setting<Integer> fillAlpha;
    private final Setting<Integer> boxAlpha;
    private final Setting<Boolean> rainbow;
    private final List<Block> godBlocks;
    public Block block;
    private boolean cancelStart;
    private boolean empty;
    private EnumFacing facing;
    double manxi;
    
    public InstantMine() {
        super("InstantMine", "Instant Mine", Module.Category.PLAYER, true, false, false);
        this.breakSuccess = new Timer();
        this.Rendertimer = new Timer();
        this.creativeMode = (Setting<Boolean>)this.register(new Setting("CreativeMode", (T)true));
        this.range = (Setting<Float>)this.register(new Setting("Range", (T)256.0f, (T)1.0f, (T)256.0f));
        this.ghostHand = (Setting<Boolean>)this.register(new Setting("GhostHand", (T)true, v -> this.creativeMode.getValue()));
        this.superghost = (Setting<Boolean>)this.register(new Setting("Super GhostHand", (T)Boolean.FALSE, v -> this.ghostHand.getValue()));
        this.doubleBreak = (Setting<Boolean>)this.register(new Setting("Double Break", (T)Boolean.FALSE, v -> this.ghostHand.getValue()));
        this.crystal = (Setting<Boolean>)this.register(new Setting("Crystal", (T)Boolean.FALSE));
        this.attackcrystal = (Setting<Boolean>)this.register(new Setting("Attack Crystal", (T)Boolean.FALSE, v -> this.crystal.getValue()));
        this.bind = (Setting<Bind>)this.register(new Setting("ObsidianBind", (T)new Bind(-1), v -> this.crystal.getValue()));
        this.instant = (Setting<Boolean>)this.register(new Setting("Instant", (T)true));
        this.render = (Setting<Boolean>)this.register(new Setting("Render", (T)true));
        this.rendermode = (Setting<Mode>)this.register(new Setting("Render Mode", (T)Mode.Fill, v -> this.render.getValue()));
        this.fillAlpha = (Setting<Integer>)this.register(new Setting("Fill Alpha", (T)80, (T)0, (T)255, v -> this.render.getValue() && this.rendermode.getValue() == Mode.Fill));
        this.boxAlpha = (Setting<Integer>)this.register(new Setting("Box Alpha", (T)255, (T)0, (T)255, v -> this.render.getValue() && this.rendermode.getValue() == Mode.Box));
        this.rainbow = (Setting<Boolean>)this.register(new Setting("Rainbow", (T)true, v -> this.render.getValue()));
        this.godBlocks = Arrays.asList(Blocks.AIR, (Block)Blocks.FLOWING_LAVA, (Block)Blocks.LAVA, (Block)Blocks.FLOWING_WATER, (Block)Blocks.WATER, Blocks.BEDROCK);
        this.cancelStart = false;
        this.empty = false;
        this.setInstance();
    }
    
    public static InstantMine getInstance() {
        if (InstantMine.INSTANCE == null) {
            InstantMine.INSTANCE = new InstantMine();
        }
        return InstantMine.INSTANCE;
    }
    
    private void setInstance() {
        InstantMine.INSTANCE = this;
    }
    
    public void onUpdate() {
        if (fullNullCheck()) {
            return;
        }
        if (InstantMine.mc.player.capabilities.isCreativeMode) {
            return;
        }
        if (!this.cancelStart) {
            return;
        }
        if (this.crystal.getValue() && this.attackcrystal.getValue() && InstantMine.mc.world.getBlockState(InstantMine.breakPos).getBlock() == Blocks.AIR) {
            attackcrystal();
        }
        if (this.bind.getValue().isDown() && this.crystal.getValue() && InventoryUtil.findHotbarBlock(BlockObsidian.class) != -1 && InstantMine.mc.world.getBlockState(InstantMine.breakPos).getBlock() == Blocks.AIR) {
            final int obbySlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
            final int old = InstantMine.mc.player.inventory.currentItem;
            this.switchToSlot(obbySlot);
            BlockUtil.placeBlock(InstantMine.breakPos, EnumHand.MAIN_HAND, false, true, false);
            this.switchToSlot(old);
        }
        if (InstantMine.breakPos != null && InstantMine.mc.player != null && InstantMine.mc.player.getDistanceSq(InstantMine.breakPos) > MathUtil.square(this.range.getValue())) {
            InstantMine.breakPos = null;
            InstantMine.breakPos2 = null;
            this.cancelStart = false;
            return;
        }
        if (InstantMine.mc.world.getBlockState(InstantMine.breakPos).getBlock() == Blocks.AIR && !this.instant.getValue()) {
            InstantMine.breakPos = null;
            InstantMine.breakPos2 = null;
            this.cancelStart = false;
            return;
        }
        if (this.godBlocks.contains(InstantMine.mc.world.getBlockState(InstantMine.breakPos).getBlock())) {
            return;
        }
        if (InventoryUtil.getItemHotbar(Items.END_CRYSTAL) != -1 && this.crystal.getValue() && InstantMine.mc.world.getBlockState(InstantMine.breakPos).getBlock() == Blocks.OBSIDIAN && !this.check() && !InstantMine.breakPos.equals((Object)AntiBurrow.pos)) {
            BlockUtil.placeCrystalOnBlock(InstantMine.breakPos, EnumHand.MAIN_HAND, true, false, true);
        }
        if (this.ghostHand.getValue() || (this.ghostHand.getValue() && this.superghost.getValue())) {
            final float breakTime = InstantMine.mc.world.getBlockState(InstantMine.breakPos).getBlockHardness((World)InstantMine.mc.world, InstantMine.breakPos);
            final int slotMain = InstantMine.mc.player.inventory.currentItem;
            if (!this.breakSuccess.passedMs((int)breakTime)) {
                return;
            }
            if (this.superghost.getValue() && InventoryUtil.getItemHotbar(Items.DIAMOND_PICKAXE) == -1) {
                for (int i = 9; i < 36; ++i) {
                    if (InstantMine.mc.player.inventory.getStackInSlot(i).getItem() == Items.DIAMOND_PICKAXE) {
                        InstantMine.mc.playerController.windowClick(InstantMine.mc.player.inventoryContainer.windowId, i, InstantMine.mc.player.inventory.currentItem, ClickType.SWAP, (EntityPlayer)InstantMine.mc.player);
                        InstantMine.mc.playerController.updateController();
                        InstantMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, InstantMine.breakPos, this.facing));
                        InstantMine.mc.playerController.windowClick(InstantMine.mc.player.inventoryContainer.windowId, i, InstantMine.mc.player.inventory.currentItem, ClickType.SWAP, (EntityPlayer)InstantMine.mc.player);
                        InstantMine.mc.playerController.updateController();
                        return;
                    }
                }
            }
            try {
                this.block = InstantMine.mc.world.getBlockState(InstantMine.breakPos).getBlock();
            }
            catch (Exception ex) {}
            final int toolSlot = this.getBestAvailableToolSlot(this.block.getBlockState().getBaseState());
            if (InstantMine.mc.player.inventory.currentItem != toolSlot && toolSlot != -1) {
                InstantMine.mc.player.inventory.currentItem = toolSlot;
                InstantMine.mc.playerController.updateController();
                InstantMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, InstantMine.breakPos, this.facing));
                InstantMine.mc.player.inventory.currentItem = slotMain;
                InstantMine.mc.playerController.updateController();
                return;
            }
        }
        InstantMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, InstantMine.breakPos, this.facing));
    }
    
    public void onRender3D(final Render3DEvent event) {
        if (fullNullCheck()) {
            return;
        }
        if (!this.cancelStart) {
            return;
        }
        if ((InstantMine.breakPos != null || (this.instant.getValue() && InstantMine.mc.world.getBlockState(InstantMine.breakPos).getBlock() == Blocks.AIR)) && InstantMine.mc.player != null && InstantMine.mc.player.getDistanceSq(InstantMine.breakPos) > MathUtil.square(this.range.getValue())) {
            InstantMine.breakPos = null;
            InstantMine.breakPos2 = null;
            this.cancelStart = false;
            return;
        }
        if (this.doubleBreak.getValue() && this.ghostHand.getValue() && InstantMine.breakPos2 != null) {
            final int slotMains = InstantMine.mc.player.inventory.currentItem;
            if (InstantMine.mc.world.getBlockState(InstantMine.breakPos2).getBlock() != Blocks.AIR) {
                if (InstantMine.mc.world.getBlockState(InstantMine.breakPos2).getBlock() == Blocks.OBSIDIAN && !this.breakSuccess.passedMs(1234L)) {
                    return;
                }
                InstantMine.breakPos2 = InstantMine.breakPos;
                try {
                    this.block = InstantMine.mc.world.getBlockState(InstantMine.breakPos2).getBlock();
                }
                catch (Exception ex) {}
                final int toolSlot = this.getBestAvailableToolSlot(this.block.getBlockState().getBaseState());
                if (InstantMine.mc.player.inventory.currentItem != toolSlot && toolSlot != -1) {
                    InstantMine.mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(toolSlot));
                    InstantMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, InstantMine.breakPos2, this.facing));
                }
            }
            if (InstantMine.mc.world.getBlockState(InstantMine.breakPos2).getBlock() == Blocks.AIR) {
                InstantMine.breakPos2 = null;
                InstantMine.mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slotMains));
            }
        }
    }
    
    public int getBestAvailableToolSlot(final IBlockState blockState) {
        int toolSlot = -1;
        double max = 0.0;
        for (int i = 0; i < 9; ++i) {
            final ItemStack stack = InstantMine.mc.player.inventory.getStackInSlot(i);
            float speed;
            final int eff;
            if (!stack.isEmpty && (speed = stack.getDestroySpeed(blockState)) > 1.0f && (speed += (float)(((eff = EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, stack)) > 0) ? (Math.pow(eff, 2.0) + 1.0) : 0.0)) > max) {
                max = speed;
                toolSlot = i;
            }
        }
        return toolSlot;
    }
    
    public static void attackcrystal() {
        for (final Entity crystal : (List)InstantMine.mc.world.loadedEntityList.stream().filter(e -> e instanceof EntityEnderCrystal && !e.isDead).sorted(Comparator.comparing(e -> InstantMine.mc.player.getDistance(e))).collect(Collectors.toList())) {
            if (crystal instanceof EntityEnderCrystal && crystal.getDistanceSq(InstantMine.breakPos) <= 2.0) {
                InstantMine.mc.player.connection.sendPacket((Packet)new CPacketUseEntity(crystal));
                InstantMine.mc.player.connection.sendPacket((Packet)new CPacketAnimation(EnumHand.OFF_HAND));
            }
        }
    }
    
    public boolean check() {
        return InstantMine.breakPos.equals((Object)new BlockPos(InstantMine.mc.player.posX, InstantMine.mc.player.posY + 2.0, InstantMine.mc.player.posZ)) || InstantMine.breakPos.equals((Object)new BlockPos(InstantMine.mc.player.posX, InstantMine.mc.player.posY + 3.0, InstantMine.mc.player.posZ)) || InstantMine.breakPos.equals((Object)new BlockPos(InstantMine.mc.player.posX, InstantMine.mc.player.posY - 1.0, InstantMine.mc.player.posZ)) || InstantMine.breakPos.equals((Object)new BlockPos(InstantMine.mc.player.posX + 1.0, InstantMine.mc.player.posY, InstantMine.mc.player.posZ)) || InstantMine.breakPos.equals((Object)new BlockPos(InstantMine.mc.player.posX - 1.0, InstantMine.mc.player.posY, InstantMine.mc.player.posZ)) || InstantMine.breakPos.equals((Object)new BlockPos(InstantMine.mc.player.posX, InstantMine.mc.player.posY, InstantMine.mc.player.posZ + 1.0)) || InstantMine.breakPos.equals((Object)new BlockPos(InstantMine.mc.player.posX, InstantMine.mc.player.posY, InstantMine.mc.player.posZ - 1.0)) || InstantMine.breakPos.equals((Object)new BlockPos(InstantMine.mc.player.posX + 1.0, InstantMine.mc.player.posY + 1.0, InstantMine.mc.player.posZ)) || InstantMine.breakPos.equals((Object)new BlockPos(InstantMine.mc.player.posX - 1.0, InstantMine.mc.player.posY + 1.0, InstantMine.mc.player.posZ)) || InstantMine.breakPos.equals((Object)new BlockPos(InstantMine.mc.player.posX, InstantMine.mc.player.posY + 1.0, InstantMine.mc.player.posZ + 1.0)) || InstantMine.breakPos.equals((Object)new BlockPos(InstantMine.mc.player.posX, InstantMine.mc.player.posY + 1.0, InstantMine.mc.player.posZ - 1.0));
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Send event) {
        if (fullNullCheck()) {
            return;
        }
        if (InstantMine.mc.player.capabilities.isCreativeMode) {
            return;
        }
        if (event.getPacket() instanceof CPacketPlayerDigging) {
            final CPacketPlayerDigging packet = (CPacketPlayerDigging)event.getPacket();
            if (packet.getAction() == CPacketPlayerDigging.Action.START_DESTROY_BLOCK) {
                event.setCanceled(this.cancelStart);
            }
        }
    }
    
    @SubscribeEvent
    public void onRender(final RenderWorldLastEvent e) {
        if (fullNullCheck()) {
            return;
        }
        if (this.render.getValue() && this.creativeMode.getValue() && this.cancelStart) {
            if (this.godBlocks.contains(InstantMine.mc.world.getBlockState(InstantMine.breakPos).getBlock())) {
                this.empty = true;
            }
            float RenderTime = InstantMine.mc.world.getBlockState(InstantMine.breakPos).getBlockHardness((World)InstantMine.mc.world, InstantMine.breakPos) / 5.0f;
            if (InstantMine.mc.world.getBlockState(InstantMine.breakPos).getBlock() == Blocks.OBSIDIAN) {
                RenderTime = 11.0f;
            }
            if (this.Rendertimer.passedMs((int)RenderTime)) {
                if (this.manxi <= 10.0) {
                    this.manxi += 0.11;
                }
                this.Rendertimer.reset();
            }
            final AxisAlignedBB axisAlignedBB = InstantMine.mc.world.getBlockState(InstantMine.breakPos).getSelectedBoundingBox((World)InstantMine.mc.world, InstantMine.breakPos);
            final double centerX = axisAlignedBB.minX + (axisAlignedBB.maxX - axisAlignedBB.minX) / 2.0;
            final double centerY = axisAlignedBB.minY + (axisAlignedBB.maxY - axisAlignedBB.minY) / 2.0;
            final double centerZ = axisAlignedBB.minZ + (axisAlignedBB.maxZ - axisAlignedBB.minZ) / 2.0;
            final double progressValX = this.manxi * (axisAlignedBB.maxX - centerX) / 10.0;
            final double progressValY = this.manxi * (axisAlignedBB.maxY - centerY) / 10.0;
            final double progressValZ = this.manxi * (axisAlignedBB.maxZ - centerZ) / 10.0;
            final AxisAlignedBB axisAlignedBB2 = new AxisAlignedBB(centerX - progressValX, centerY - progressValY, centerZ - progressValZ, centerX + progressValX, centerY + progressValY, centerZ + progressValZ);
            final Color color = this.rainbow.getValue() ? ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()) : new Color(this.empty ? 0 : 255, this.empty ? 255 : 0, 0, 255);
            if (this.rendermode.getValue() == Mode.Fill) {
                RenderUtil.drawBBFill(axisAlignedBB2, color, this.fillAlpha.getValue());
            }
            else {
                RenderUtil.drawBBBox(axisAlignedBB2, color, this.boxAlpha.getValue());
            }
        }
    }
    
    @SubscribeEvent
    public void onBlockEvent(final PlayerDamageBlockEvent event) {
        if (fullNullCheck()) {
            return;
        }
        if (InstantMine.breakPos != null && InstantMine.breakPos.getX() == event.getPos().getX() && InstantMine.breakPos.getY() == event.getPos().getY() && InstantMine.breakPos.getZ() == event.getPos().getZ()) {
            return;
        }
        if (InstantMine.breakPos2 != null && InstantMine.breakPos2.getX() == event.getPos().getX() && InstantMine.breakPos2.getY() == event.getPos().getY() && InstantMine.breakPos2.getZ() == event.getPos().getZ() && this.doubleBreak.getValue()) {
            return;
        }
        if (InstantMine.mc.player.capabilities.isCreativeMode) {
            return;
        }
        if (BlockUtil.canBreak(event.pos)) {
            this.manxi = 0.0;
            InstantMine.breakPos2 = InstantMine.breakPos;
            this.empty = false;
            this.cancelStart = false;
            InstantMine.breakPos = event.pos;
            this.breakSuccess.reset();
            this.facing = event.facing;
            if (InstantMine.breakPos != null) {
                InstantMine.mc.player.swingArm(EnumHand.MAIN_HAND);
                InstantMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, InstantMine.breakPos, this.facing));
                this.cancelStart = true;
                InstantMine.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, InstantMine.breakPos, this.facing));
                event.setCanceled(true);
            }
        }
    }
    
    private void switchToSlot(final int slot) {
        InstantMine.mc.player.inventory.currentItem = slot;
        InstantMine.mc.playerController.updateController();
    }
    
    public String getDisplayInfo() {
        return this.ghostHand.getValue() ? "Ghost" : "Normal";
    }
    
    static {
        InstantMine.INSTANCE = new InstantMine();
    }
    
    public enum Mode
    {
        Fill, 
        Box;
    }
}
