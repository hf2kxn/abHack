

package me.abHack.features.command.commands;

import me.abHack.features.command.*;
import com.mojang.realmsclient.gui.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;

public class TpCommand extends Command
{
    public TpCommand() {
        super("tp", new String[] { "<x> <y> <z>" });
    }
    
    public void execute(final String[] commands) {
        if (commands.length == 1 || commands.length == 2 || commands.length > 4) {
            Command.sendMessage(ChatFormatting.DARK_RED + "You is sb?");
            return;
        }
        if (commands.length == 4) {
            final int x = Integer.parseInt(commands[0]);
            final int y = Integer.parseInt(commands[1]);
            final int z = Integer.parseInt(commands[2]);
            TpCommand.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(TpCommand.mc.player.posX, TpCommand.mc.player.posY + 0.001, TpCommand.mc.player.posZ, false));
            TpCommand.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(TpCommand.mc.player.posX + x, TpCommand.mc.player.posY + y, TpCommand.mc.player.posZ + z, false));
        }
    }
}
