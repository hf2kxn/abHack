

package me.abHack.features.modules.misc;

import me.abHack.features.modules.*;

public class Ghost extends Module
{
    public Ghost() {
        super("Ghost", "Ghost", Category.MISC, true, false, false);
    }
}
