

package me.abHack.features.command.commands;

import me.abHack.features.command.*;

public class ClearRamCommand extends Command
{
    public ClearRamCommand() {
        super("clearram");
    }
    
    public void execute(final String[] commands) {
        System.gc();
        Command.sendMessage("Finished clearing the ram.");
    }
}
