

package me.abHack.features.command.commands;

import me.abHack.features.command.*;
import net.minecraft.item.*;
import io.netty.buffer.*;
import net.minecraft.network.*;
import net.minecraft.client.*;

public class ItemSizeCommand extends Command
{
    public ItemSizeCommand() {
        super("size", new String[0]);
    }
    
    public static int getItemSize(final ItemStack stack) {
        final PacketBuffer buff = new PacketBuffer(Unpooled.buffer());
        buff.writeItemStack(stack);
        final int size = buff.writerIndex();
        buff.release();
        return size;
    }
    
    public void execute(final String[] commands) {
        final ItemStack stack = Minecraft.getMinecraft().player.getHeldItemMainhand();
        if (stack.isEmpty()) {
            Command.sendMessage("You are not holding any item");
        }
        Command.sendMessage("Item weights " + getItemSize(stack) + " bytes");
    }
}
