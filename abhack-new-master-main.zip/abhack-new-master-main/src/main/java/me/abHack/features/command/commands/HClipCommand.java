

package me.abHack.features.command.commands;

import me.abHack.features.command.*;
import com.mojang.realmsclient.gui.*;
import net.minecraft.util.math.*;
import net.minecraft.entity.*;

public class HClipCommand extends Command
{
    public HClipCommand() {
        super("hclip", new String[] { "<distance>" });
    }
    
    public void execute(final String[] commands) {
        if (commands.length == 1) {
            Command.sendMessage(ChatFormatting.DARK_RED + ".Hclip <distance>");
            return;
        }
        final double weight = Double.parseDouble(commands[0]);
        final Vec3d direction = new Vec3d(Math.cos((HClipCommand.mc.player.rotationYaw + 90.0f) * 0.017453292f), 0.0, Math.sin((HClipCommand.mc.player.rotationYaw + 90.0f) * 0.017453292f));
        final Entity target = (Entity)(HClipCommand.mc.player.isRiding() ? HClipCommand.mc.player.getRidingEntity() : HClipCommand.mc.player);
        target.setPosition(target.posX + direction.x * weight, target.posY, target.posZ + direction.z * weight);
        Command.sendMessage("Hclip to " + weight);
    }
}
