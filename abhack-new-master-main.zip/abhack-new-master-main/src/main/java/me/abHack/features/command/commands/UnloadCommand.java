
package me.abHack.features.command.commands;

import me.abHack.features.command.*;
import me.abHack.*;

public class UnloadCommand extends Command
{
    public UnloadCommand() {
        super("unload", new String[0]);
    }
    
    public void execute(final String[] commands) {
        OyVey.unload(true);
    }
}
