//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "E:\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package me.abHack.features.modules.player;

import me.abHack.features.modules.*;

public class PacketEat extends Module
{
    private static PacketEat INSTANCE;
    
    public PacketEat() {
        super("PacketEat", "PacketEat", Module.Category.PLAYER, true, false, false);
        this.setInstance();
    }
    
    public static PacketEat getInstance() {
        if (PacketEat.INSTANCE == null) {
            PacketEat.INSTANCE = new PacketEat();
        }
        return PacketEat.INSTANCE;
    }
    
    private void setInstance() {
        PacketEat.INSTANCE = this;
    }
    
    static {
        PacketEat.INSTANCE = new PacketEat();
    }
}
