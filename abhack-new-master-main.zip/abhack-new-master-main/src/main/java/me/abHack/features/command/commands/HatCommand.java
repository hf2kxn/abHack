

package me.abHack.features.command.commands;

import me.abHack.features.command.*;
import com.mojang.realmsclient.gui.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;

public class HatCommand extends Command
{
    public HatCommand() {
        super("Hat", new String[0]);
    }
    
    public void execute(final String[] commands) {
        if (commands.length == 1) {
            Command.sendMessage(ChatFormatting.DARK_RED + ".Hat <item> <count> <data> <nbt>");
            return;
        }
        if (commands.length == 2) {
            HatCommand.mc.player.connection.sendPacket((Packet)new CPacketChatMessage("/replaceitem entity @p slot.armor.head " + commands[0]));
            Command.sendMessage("New Hat.");
        }
        if (commands.length == 3) {
            HatCommand.mc.player.connection.sendPacket((Packet)new CPacketChatMessage("/replaceitem entity @p slot.armor.head " + commands[0] + " " + commands[1]));
            Command.sendMessage("New Hat.");
        }
        if (commands.length == 4) {
            HatCommand.mc.player.connection.sendPacket((Packet)new CPacketChatMessage("/replaceitem entity @p slot.armor.head " + commands[0] + " " + commands[1] + " " + commands[2]));
            Command.sendMessage("New Hat.");
        }
        if (commands.length == 5) {
            HatCommand.mc.player.connection.sendPacket((Packet)new CPacketChatMessage("/replaceitem entity @p slot.armor.head " + commands[0] + " " + commands[1] + " " + commands[2] + " " + commands[3]));
            Command.sendMessage("New Hat.");
        }
    }
}
