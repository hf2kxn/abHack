

package me.abHack.features.modules.misc;

import me.abHack.features.modules.*;
import me.abHack.features.setting.*;
import me.abHack.event.events.*;
import net.minecraft.network.play.client.*;
import net.minecraft.util.*;
import net.minecraftforge.fml.common.eventhandler.*;
import net.minecraft.client.*;

public class Interact extends Module
{
    private static Interact INSTANCE;
    public Setting<Boolean> buildHeight;
    public Setting<Boolean> liquid;
    public Setting<Boolean> portalgui;
    
    public Interact() {
        super("Interact", "ForceInteract", Category.MISC, true, false, false);
        this.buildHeight = (Setting<Boolean>)this.register(new Setting("BuildHeight", true));
        this.liquid = (Setting<Boolean>)this.register(new Setting("Liquid", true));
        this.portalgui = (Setting<Boolean>)this.register(new Setting("PortalGui", true));
        this.setInstance();
    }
    
    public static Interact getInstance() {
        if (Interact.INSTANCE == null) {
            Interact.INSTANCE = new Interact();
        }
        return Interact.INSTANCE;
    }
    
    private void setInstance() {
        Interact.INSTANCE = this;
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Send event) {
        if (this.buildHeight.getValue() && event.getPacket() instanceof CPacketPlayerTryUseItemOnBlock) {
            final CPacketPlayerTryUseItemOnBlock packet = (CPacketPlayerTryUseItemOnBlock)event.getPacket();
            if (packet.getPos().getY() >= 255 && packet.getDirection() == EnumFacing.UP) {
                packet.placedBlockDirection = EnumFacing.DOWN;
            }
        }
    }
    
    @Override
    public void onUpdate() {
        if (Minecraft.getMinecraft().player.inPortal && this.portalgui.getValue()) {
            Minecraft.getMinecraft().player.inPortal = false;
        }
    }
    
    static {
        Interact.INSTANCE = new Interact();
    }
}
