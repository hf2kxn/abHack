

package me.abHack.features.modules.misc;

import me.abHack.features.modules.*;
import me.abHack.util.*;
import me.abHack.features.setting.*;
import me.abHack.*;
import org.apache.commons.lang3.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;

public class Message extends Module
{
    private final Timer timer;
    private final Setting<String> custom;
    private final Setting<Integer> random;
    private final Setting<Integer> delay;
    private final Setting<Boolean> toggle;
    private final Setting<Boolean> escoff;
    
    public Message() {
        super("Message", "Message", Category.MISC, true, false, false);
        this.timer = new Timer();
        this.custom = (Setting<String>)this.register(new Setting("Custom", "/kit ab "));
        this.random = (Setting<Integer>)this.register(new Setting("Random", 0, 0, 20));
        this.delay = (Setting<Integer>)this.register(new Setting("Delay", 5, 0, 20));
        this.toggle = (Setting<Boolean>)this.register(new Setting("Toggle", true));
        this.escoff = (Setting<Boolean>)this.register(new Setting("EscOff", true));
    }
    
    @Override
    public void onLogout() {
        if (this.escoff.getValue() && OyVey.moduleManager.isModuleEnabled("Message")) {
            this.disable();
        }
    }
    
    @Override
    public void onLogin() {
        if (this.escoff.getValue() && OyVey.moduleManager.isModuleEnabled("Message")) {
            this.disable();
        }
    }
    
    @Override
    public void onUpdate() {
        if (fullNullCheck()) {
            return;
        }
        if (this.timer.passedS(this.delay.getValue())) {
            Message.mc.player.connection.sendPacket((Packet)new CPacketChatMessage(this.custom.getValue() + RandomStringUtils.randomAlphanumeric((int)this.random.getValue())));
            this.timer.reset();
        }
        if (this.toggle.getValue()) {
            this.toggle();
        }
    }
}
