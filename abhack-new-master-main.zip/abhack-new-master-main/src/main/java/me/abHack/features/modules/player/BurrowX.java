//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "E:\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package me.abHack.features.modules.player;

import me.abHack.features.modules.*;
import me.abHack.features.setting.*;
import net.minecraft.init.*;
import net.minecraft.network.*;
import net.minecraft.util.*;
import net.minecraft.block.state.*;
import me.abHack.util.*;
import net.minecraft.entity.*;
import java.util.*;
import net.minecraft.block.*;
import net.minecraft.entity.item.*;
import net.minecraft.util.math.*;
import net.minecraft.item.*;
import net.minecraft.network.play.client.*;

public class BurrowX extends Module
{
    private int oldSlot;
    private BlockPos originalPos;
    public Setting<Boolean> rotate;
    private final Setting<Double> offset;
    
    public BurrowX() {
        super("BurrowX", "Rubberbands you into a block", Module.Category.PLAYER, true, false, false);
        this.oldSlot = -1;
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)true));
        this.offset = (Setting<Double>)this.register(new Setting("Offset", (T)(-5.0), (T)(-5.0), (T)(-10.0)));
    }
    
    public void onEnable() {
        this.originalPos = new BlockPos(BurrowX.mc.player.posX, BurrowX.mc.player.posY, BurrowX.mc.player.posZ);
        if (BurrowX.mc.world.getBlockState(new BlockPos(BurrowX.mc.player.posX, BurrowX.mc.player.posY, BurrowX.mc.player.posZ)).getBlock().equals(Blocks.OBSIDIAN) || BurrowX.mc.world.getBlockState(new BlockPos(BurrowX.mc.player.posX, BurrowX.mc.player.posY, BurrowX.mc.player.posZ)).getBlock().equals(Blocks.ENDER_CHEST) || this.intersectsWithEntity(this.originalPos)) {
            this.toggle();
            return;
        }
        this.oldSlot = BurrowX.mc.player.inventory.currentItem;
    }
    
    public void onUpdate() {
        if (getBlockSlot(Blocks.OBSIDIAN) == -1 && getBlockSlot(Blocks.ENDER_CHEST) == -1) {
            this.toggle();
            return;
        }
        if (getBlockSlot(Blocks.OBSIDIAN) != -1) {
            this.switchToSlot(getBlockSlot(Blocks.OBSIDIAN), false);
        }
        else {
            this.switchToSlot(getBlockSlot(Blocks.ENDER_CHEST), false);
        }
        BurrowX.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(BurrowX.mc.player.posX, BurrowX.mc.player.posY + 0.41999998688698, BurrowX.mc.player.posZ, true));
        BurrowX.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(BurrowX.mc.player.posX, BurrowX.mc.player.posY + 0.7531999805211997, BurrowX.mc.player.posZ, true));
        BurrowX.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(BurrowX.mc.player.posX, BurrowX.mc.player.posY + 1.00133597911214, BurrowX.mc.player.posZ, true));
        BurrowX.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(BurrowX.mc.player.posX, BurrowX.mc.player.posY + 1.06610926093821, BurrowX.mc.player.posZ, true));
        this.placeBlock(this.originalPos, EnumHand.MAIN_HAND, this.rotate.getValue(), false);
        BurrowX.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(BurrowX.mc.player.posX, BurrowX.mc.player.posY + this.offset.getValue(), BurrowX.mc.player.posZ, false));
        this.switchToSlot(this.oldSlot, false);
        this.toggle();
    }
    
    public List<EnumFacing> getPossibleSides(final BlockPos pos) {
        final ArrayList<EnumFacing> facings = new ArrayList<EnumFacing>();
        if (BurrowX.mc.world == null || pos == null) {
            return facings;
        }
        for (final EnumFacing side : EnumFacing.values()) {
            final BlockPos neighbour = pos.offset(side);
            final IBlockState blockState = BurrowX.mc.world.getBlockState(neighbour);
            if (blockState != null && blockState.getBlock().canCollideCheck(blockState, false) && !blockState.getMaterial().isReplaceable()) {
                facings.add(side);
            }
        }
        return facings;
    }
    
    public void rightClickBlock(final BlockPos pos, final Vec3d vec, final EnumHand hand, final EnumFacing direction, final boolean packet) {
        if (packet) {
            final float f = (float)(vec.x - pos.getX());
            final float f2 = (float)(vec.y - pos.getY());
            final float f3 = (float)(vec.z - pos.getZ());
            BurrowX.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(pos, direction, hand, f, f2, f3));
        }
        else {
            BurrowX.mc.playerController.processRightClickBlock(BurrowX.mc.player, BurrowX.mc.world, pos, direction, vec, hand);
        }
        BurrowX.mc.player.swingArm(EnumHand.MAIN_HAND);
        BurrowX.mc.rightClickDelayTimer = 4;
    }
    
    public boolean placeBlock(final BlockPos pos, final EnumHand hand, final boolean rotate, final boolean isSneaking) {
        boolean sneaking = false;
        EnumFacing side = null;
        final Iterator<EnumFacing> iterator = this.getPossibleSides(pos).iterator();
        if (iterator.hasNext()) {
            side = iterator.next();
        }
        if (side == null) {
            return isSneaking;
        }
        final BlockPos neighbour = pos.offset(side);
        final EnumFacing opposite = side.getOpposite();
        final Vec3d hitVec = new Vec3d((Vec3i)neighbour).add(0.5, 0.5, 0.5).add(new Vec3d(opposite.getDirectionVec()).scale(0.5));
        final Block neighbourBlock = BurrowX.mc.world.getBlockState(neighbour).getBlock();
        if (!BurrowX.mc.player.isSneaking() && (BlockUtil.blackList.contains(neighbourBlock) || BlockUtil.shulkerList.contains(neighbourBlock))) {
            BurrowX.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)BurrowX.mc.player, CPacketEntityAction.Action.START_SNEAKING));
            BurrowX.mc.player.setSneaking(true);
            sneaking = true;
        }
        this.rightClickBlock(neighbour, hitVec, hand, opposite, true);
        BurrowX.mc.player.swingArm(EnumHand.MAIN_HAND);
        BurrowX.mc.rightClickDelayTimer = 4;
        return sneaking || isSneaking;
    }
    
    private boolean intersectsWithEntity(final BlockPos pos) {
        for (final Entity entity : BurrowX.mc.world.loadedEntityList) {
            if (!entity.equals((Object)BurrowX.mc.player) && !(entity instanceof EntityItem) && new AxisAlignedBB(pos).intersects(entity.getEntityBoundingBox())) {
                return true;
            }
        }
        return false;
    }
    
    public static int getBlockSlot(final Block block) {
        for (int i = 0; i < 9; ++i) {
            final ItemStack itemStack = BurrowX.mc.player.inventory.getStackInSlot(i);
            if (itemStack == ItemStack.EMPTY) {
                return -1;
            }
            if (itemStack.getItem() instanceof ItemBlock) {
                final ItemBlock itemBlock = (ItemBlock)itemStack.getItem();
                if (itemBlock.getBlock() == block) {
                    return i;
                }
            }
        }
        return -1;
    }
    
    public void switchToSlot(final int Slot, final boolean packet) {
        if (packet) {
            BurrowX.mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(Slot));
            BurrowX.mc.playerController.updateController();
        }
        else {
            BurrowX.mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(Slot));
            BurrowX.mc.player.inventory.currentItem = Slot;
            BurrowX.mc.playerController.updateController();
        }
    }
}
