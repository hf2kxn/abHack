

package me.abHack.features.modules.combat;

import me.abHack.features.modules.*;

public class KeyCity extends Module
{
    public KeyCity() {
        super("KeyCity", "KeyCity", Category.COMBAT, true, false, false);
    }
}
