//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "E:\cn��ǿ��������\1.12 stable mappings"!

//Decompiled by Procyon!

package me.abHack.features.modules.player;

import me.abHack.features.modules.*;
import me.abHack.features.setting.*;
import net.minecraft.util.math.*;
import net.minecraft.init.*;
import net.minecraft.util.*;
import me.abHack.util.*;
import net.minecraft.block.state.*;
import net.minecraft.item.*;

public class AutoDupe extends Module
{
    private final Setting<Integer> delay;
    private final Timer timer;
    private BlockPos pos;
    int box;
    
    public AutoDupe() {
        super("AutoDupe", "Automatically places Shulker", Module.Category.PLAYER, true, false, false);
        this.delay = (Setting<Integer>)this.register(new Setting("Delay", (T)0, (T)0, (T)2000));
        this.timer = new Timer();
    }
    
    public void onUpdate() {
        if (InstantMine.breakPos == null) {
            return;
        }
        this.pos = InstantMine.breakPos;
        final IBlockState blockState = AutoDupe.mc.world.getBlockState(this.pos);
        this.box = this.getItemShulkerBox();
        if (blockState.getBlock() == Blocks.AIR && this.box != -1) {
            AutoDupe.mc.player.inventory.currentItem = this.box;
            BlockUtil.placeBlock(this.pos, EnumHand.MAIN_HAND, false, false, false);
            this.timer.passedDms(this.delay.getValue());
        }
    }
    
    public int getItemShulkerBox() {
        int box = -1;
        for (int x = 0; x <= 8; ++x) {
            final Item item = AutoDupe.mc.player.inventory.getStackInSlot(x).getItem();
            if (item instanceof ItemShulkerBox) {
                box = x;
            }
        }
        return box;
    }
}
