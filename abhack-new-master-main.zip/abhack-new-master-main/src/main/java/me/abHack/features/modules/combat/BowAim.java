

package me.abHack.features.modules.combat;

import me.abHack.features.modules.*;
import me.abHack.features.setting.*;
import net.minecraft.entity.*;
import net.minecraft.item.*;
import net.minecraft.entity.player.*;
import net.minecraft.client.entity.*;
import me.abHack.*;
import net.minecraft.network.*;
import net.minecraft.util.math.*;
import net.minecraft.network.play.client.*;
import java.util.*;

public class BowAim extends Module
{
    public final Setting<Boolean> packet;
    public final Setting<Boolean> fastbow;
    
    public BowAim() {
        super("BowAim", "Automatically aims your bow at your opponent", Category.COMBAT, true, false, false);
        this.packet = (Setting<Boolean>)this.register(new Setting("PacketRotate", true));
        this.fastbow = (Setting<Boolean>)this.register(new Setting("FastBow", true));
    }
    
    public static Vec3d interpolateEntity(final Entity entity, final float time) {
        return new Vec3d(entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * time, entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * time, entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * time);
    }
    
    public static float[] calcAngle(final Vec3d from, final Vec3d to) {
        final double difX = to.x - from.x;
        final double difY = (to.y - from.y) * -1.0;
        final double difZ = to.z - from.z;
        final double dist = MathHelper.sqrt(difX * difX + difZ * difZ);
        return new float[] { (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(difZ, difX)) - 90.0), (float)MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(difY, dist))) };
    }
    
    @Override
    public void onUpdate() {
        if (BowAim.mc.player.getHeldItemMainhand().getItem() instanceof ItemBow && BowAim.mc.player.isHandActive() && BowAim.mc.player.getItemInUseMaxCount() >= 3) {
            EntityPlayer player = null;
            float tickDis = 100.0f;
            for (final EntityPlayer p : BowAim.mc.world.playerEntities) {
                if (!(p instanceof EntityPlayerSP) && !OyVey.friendManager.isFriend(p.getName())) {
                    final float dis;
                    if ((dis = p.getDistance((Entity)BowAim.mc.player)) >= tickDis) {
                        continue;
                    }
                    tickDis = dis;
                    player = p;
                }
            }
            if (player != null) {
                final Vec3d pos = interpolateEntity((Entity)player, BowAim.mc.getRenderPartialTicks());
                final float[] angels = calcAngle(interpolateEntity((Entity)BowAim.mc.player, BowAim.mc.getRenderPartialTicks()), pos);
                if (this.packet.getValue()) {
                    BowAim.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(angels[0], angels[1], BowAim.mc.player.onGround));
                }
                else {
                    BowAim.mc.player.rotationYaw = angels[0];
                    BowAim.mc.player.rotationPitch = angels[1];
                }
            }
        }
        if (BowAim.mc.player.inventory.getCurrentItem().getItem() instanceof ItemBow && BowAim.mc.player.isHandActive() && BowAim.mc.player.getItemInUseMaxCount() >= 3 && this.fastbow.getValue()) {
            BowAim.mc.player.connection.sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, BowAim.mc.player.getHorizontalFacing()));
            BowAim.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItem(BowAim.mc.player.getActiveHand()));
            BowAim.mc.player.stopActiveHand();
        }
    }
}
