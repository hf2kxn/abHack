##  abhack-master new 0.0.1
![unknown](https://i.postimg.cc/nLkWZXcq/L-18-YF-3-VLZ-HVADXATZV.jpg)

### 经过我看了这个shitcoder之后发现
- AutoPush和KeyCity均为空白的java文件
- 这就是我们ab大神给user用的abhack吗？
- 真的是乐飞我了

# 我想说的话：
>- 这个东西纯纯看看就行了 实在是我们ab大佐写的太烂了
>- 如果你想拿这个当base的话那就当我没说，但是我相信也没人拿这个当base吧
>- ![unknown](https://i.postimg.cc/MTbmWVFw/FZ-UM8-JGRW-3-3-FHCOWBR.jpg)

# 搭建环境
1. 克隆此代码仓库
2. 在IDEA中运行

在根目录控制台输入:
```
./gradlew setupDevWorkspace idea genIntellijRuns build
```
3. 打开IDEA.
4. 打开此项目目录
5. 点击导入Gradle项目



### 注意的一些事：
1. 这个东西没反编译好
2. 构建肯定是有问题的
3. 反正你们也不会拿这个当壳子的对吧
